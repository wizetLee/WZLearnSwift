//
//  INPCameraFilterModel.m
//  POCONewCamera
//
//  Created by 陈弢 on 2017/5/22.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import "INPCameraFilterModel.h"
//#import "FilterDownloadManager.h"

#define OpenGLFilterType @"filter_type"
#define OpenGLTablePic @"table_pic"

#define OpenGLBlend @"blend"
#define OpenGLBlendPic @"blend_pic"
#define OpenGLBlendAlpha @"blend_alpha"
#define OpenGLBlendType @"blend_type"

@interface INPCameraFilterModel ()

@end

@implementation INPCameraFilterModel

#pragma mark - Public Method

+ (OIFilter *)getFilterWithFilterColorDic:(NSDictionary *)filterColorDic {
    NSInteger type = [[filterColorDic objectForKey:OpenGLFilterType] integerValue];
    switch (type) {
        case kINPCameraFilterTypeLookUpTable:{
            UIImage *lutImage = [self getImageWithLink:[filterColorDic objectForKey:OpenGLTablePic]];
            if (lutImage) {
                OILookUpTableFilter *lutFilter = [[OILookUpTableFilter alloc] initWithLutImage:lutImage];
                return lutFilter;
            }
        }
            break;
        case kINPCameraFilterTypeMultipleBlend:{
            OIMultipleBlendFilter *blendFilter = [[OIMultipleBlendFilter alloc] init];
            NSArray *blends = [filterColorDic objectForKey:OpenGLBlend];
            
            NSDictionary *blendDic1 = blends[0];
            UIImage *blendImage1 = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:[blendDic1 objectForKey:OpenGLBlendPic] ofType:nil]];
            int blendType1 = [[blendDic1 objectForKey:OpenGLBlendType] intValue];
            CGFloat blendAlpha1 = [[blendDic1 objectForKey:OpenGLBlendAlpha] floatValue];
            
            if (blends.count > 1) {
                NSDictionary *blendDic2 = blends[1];
                UIImage *blendImage2 = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:[blendDic2 objectForKey:OpenGLBlendPic] ofType:nil]];
                int blendType2 = [[blendDic2 objectForKey:OpenGLBlendType] intValue];
                CGFloat blendAlpha2 = [[blendDic2 objectForKey:OpenGLBlendAlpha] floatValue];
                
                [blendFilter setMask1Image:blendImage1];
                [blendFilter setMask2Image:blendImage2];
                blendFilter.alphaArray = @[@(blendAlpha1), @(blendAlpha2), @0.0];
                blendFilter.blendTypeArray = @[@(blendType1), @(blendType2), @0];
                blendFilter.numbersOfTexture = 2;
            } else {
                [blendFilter setMask1Image:blendImage1];
                blendFilter.alphaArray = @[@(blendAlpha1), @0.0, @0.0];
                blendFilter.blendTypeArray = @[@(blendType1), @0, @0];
                blendFilter.numbersOfTexture = 1;
            }
            return blendFilter;
        }
            break;
        case kINPCameraFilterTypeLookUpTableAndMultipleBlend:{
//            OIMultipleBlendFilter *blendFilter = [[OIMultipleBlendFilter alloc] init];
//            NSArray *blends = [filterColorDic objectForKey:OpenGLBlend];
//            
//            NSDictionary *blendDic1 = blends[0];
//            UIImage *blendImage1 = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:[blendDic1 objectForKey:OpenGLBlendPic] ofType:nil]];
//            int blendType1 = [[blendDic1 objectForKey:OpenGLBlendType] intValue];
//            CGFloat blendAlpha1 = [[blendDic1 objectForKey:OpenGLBlendAlpha] floatValue];
//            
//            if (blends.count > 1) {
//                NSDictionary *blendDic2 = blends[1];
//                UIImage *blendImage2 = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:[blendDic2 objectForKey:OpenGLBlendPic] ofType:nil]];
//                int blendType2 = [[blendDic2 objectForKey:OpenGLBlendType] intValue];
//                CGFloat blendAlpha2 = [[blendDic2 objectForKey:OpenGLBlendAlpha] floatValue];
//                
//                [blendFilter setMask1Image:blendImage1];
//                [blendFilter setMask2Image:blendImage2];
//                blendFilter.alphaArray = @[@(blendAlpha1), @(blendAlpha2), @0.0];
//                blendFilter.blendTypeArray = @[@(blendType1), @(blendType2), @0];
//                blendFilter.numbersOfTexture = 2;
//            } else {
//                [blendFilter setMask1Image:blendImage1];
//                blendFilter.alphaArray = @[@(blendAlpha1), @0.0, @0.0];
//                blendFilter.blendTypeArray = @[@(blendType1), @0, @0];
//                blendFilter.numbersOfTexture = 1;
//            }
//            return blendFilter;
            
            OILookUpMultipleBlendFilter *lookupBlendFilter = [[OILookUpMultipleBlendFilter alloc] init];
            UIImage *lutImage = [self getImageWithLink:[filterColorDic objectForKey:OpenGLTablePic]];
            [lookupBlendFilter setTableImage:lutImage];
            
            NSArray *blends = [filterColorDic objectForKey:OpenGLBlend];
            
            NSDictionary *blendDic1 = blends[0];
            UIImage *blendImage1 = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:[blendDic1 objectForKey:OpenGLBlendPic] ofType:nil]];
            int blendType1 = [[blendDic1 objectForKey:OpenGLBlendType] intValue];
            CGFloat blendAlpha1 = [[blendDic1 objectForKey:OpenGLBlendAlpha] floatValue];
            
//            if (blends.count > 1) {
//                NSDictionary *blendDic2 = blends[1];
//                UIImage *blendImage2 = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:[blendDic2 objectForKey:OpenGLBlendPic] ofType:nil]];
//                int blendType2 = [[blendDic2 objectForKey:OpenGLBlendType] intValue];
//                CGFloat blendAlpha2 = [[blendDic2 objectForKey:OpenGLBlendAlpha] floatValue];
//                
//                [lookupBlendFilter setMask1Image:blendImage1];
//                [lookupBlendFilter setMask2Image:blendImage2];
//                lookupBlendFilter.alphaArray = @[@(blendAlpha1), @(blendAlpha2), @0.0];
//                lookupBlendFilter.blendTypeArray = @[@(blendType1), @(blendType2), @0];
//                lookupBlendFilter.numbersOfTexture = 2;
//            } else {
                [lookupBlendFilter setMask1Image:blendImage1];
                lookupBlendFilter.alphaArray = @[@(blendAlpha1), @0.0, @0.0];
                lookupBlendFilter.blendTypeArray = @[@(blendType1), @0, @0];
                lookupBlendFilter.numbersOfTexture = 1;
//            }
            return lookupBlendFilter;
        }
            break;
    }
    return nil;
}


+ (UIImage *)getImageWithLink:(NSString *)link {
    UIImage *image = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:link ofType:nil]];
    if (!image) {
//        NSString *path = [FilterDownloadManager pathWithLink:link];
//        image = [UIImage imageWithContentsOfFile:path];
    }
    return image;
}



#pragma mark - Private Method


#pragma mark - Getter

#pragma mark - Setter


@end
