//
//  INPCameraFilterModel.h
//  POCONewCamera
//
//  Created by 陈弢 on 2017/5/22.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <OpenGLESImage/OpenGLESImage.h>
#import "OILookUpTableFilter.h"
#import "OIMultipleBlendFilter.h"
#import "OILookUpMultipleBlendFilter.h"

typedef NS_ENUM(NSInteger, INPCameraFilterType) {
    kINPCameraFilterTypeLookUpTable = 0,
    kINPCameraFilterTypeMultipleBlend,
    kINPCameraFilterTypeLookUpTableAndMultipleBlend
};

@interface INPCameraFilterModel : NSObject

+ (OIFilter *)getFilterWithFilterColorDic:(NSDictionary *)filterColorDic;

@end
