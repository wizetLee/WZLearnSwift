//
//  INPCamera.h
//  POCONewCamera
//
//  Created by 陈弢 on 2017/5/25.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import <OpenGLESImage/OpenGLESImage.h>

// 添加了audio
@class INPCamera;

@protocol INPCameraDelegate <OIVideoCaptorDelegate>

@optional

- (void)camera:(INPCamera *)camera didReceiveAudioSampleBuffer:(CMSampleBufferRef)sampleBuffer;
- (void)camera:(INPCamera *)camera didGetStringFromQRCode:(NSString *)result;

@end


@interface INPCamera : OIStillImageCamera  <AVCaptureAudioDataOutputSampleBufferDelegate, AVCaptureMetadataOutputObjectsDelegate>

// 单例
+ (INPCamera *)shareINPCamera;

@property (weak, nonatomic) id <INPCameraDelegate> delegate;

@property (readwrite, getter=microphoneIsEnabled, nonatomic) BOOL microphoneEnabled;
@property (readwrite, getter=QRCodeDetectionIsEnabled, nonatomic) BOOL QRCodeDetectionEnabled;

- (NSDictionary *)recommendedAudioSettingsForWriterWithOutputFileType:(NSString *)outputFileType;

- (AVCaptureDevice *)captureDevice;

@end
