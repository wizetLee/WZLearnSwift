//
//  OIDefaultFilter.m
//  POCONewCamera
//
//  Created by 陈弢 on 2017/5/18.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import "OIDefaultFilter.h"

@implementation OIDefaultFilter

@synthesize producers = producers_;
@synthesize contentSize = contentSize_;
@synthesize contentMode;


- (instancetype)init {
    self = [super init];
    if (self) {
        
    }
    return self;
}


@end
