//
//  OISobelEdgeFilter.h
//  POCONewCamera
//
//  Created by 陈弢 on 2017/5/18.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import <OpenGLESImage/OpenGLESImage.h>

// 索贝尔边缘检测滤镜
@interface OISobelEdgeFilter : OIFilter

@end
