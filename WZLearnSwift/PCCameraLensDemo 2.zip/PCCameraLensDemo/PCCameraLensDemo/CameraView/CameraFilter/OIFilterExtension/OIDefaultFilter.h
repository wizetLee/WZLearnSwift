//
//  OIDefaultFilter.h
//  POCONewCamera
//
//  Created by 陈弢 on 2017/5/18.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import <OpenGLESImage/OpenGLESImage.h>

@interface OIDefaultFilter : OIProducer<OIConsumer> {
    NSMutableArray *producers_;
    OIFrameBufferObject *filterFBO_;
    OIProgram *filterProgram_;
    OITexture *inputTexture_;
    CGSize contentSize_;
}

+ (NSString *)vertexShaderFilename;
+ (NSString *)fragmentShaderFilename;

- (instancetype)initWithContentSize:(CGSize)contentSize;
- (void)setProgramUniform;

- (UIImage *)imageFromCurrentFrame;

@end
