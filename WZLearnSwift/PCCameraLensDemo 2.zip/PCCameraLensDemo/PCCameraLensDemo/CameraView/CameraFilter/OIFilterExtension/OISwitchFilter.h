//
//  OISwitchFilter.h
//  POCONewCamera
//
//  Created by 陈弢 on 2017/6/12.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import <OpenGLESImage/OpenGLESImage.h>

@interface OISwitchFilter : OIFilter

@property (nonatomic, strong) OITexture *firstFilterTexture;
@property (nonatomic, strong) OITexture *secondFilterTexture;

@property (nonatomic, assign) CGFloat index; // 0 ~ 1
@property (nonatomic, assign) int closewise; // 0从左到右; 1从右到左， 2从下到上，3从上到下


@end
