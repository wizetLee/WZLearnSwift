 //
//  OIMultipleBlendFilter.m
//  POCONewCamera
//
//  Created by 陈弢 on 2017/5/18.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import "OIMultipleBlendFilter.h"

@implementation OIMultipleBlendFilter

#pragma mark - Shader

+ (NSString *)vertexShaderFilename {
    static NSString *OIBlendFilterVertex = @"OICameraBlendFilter";
    return OIBlendFilterVertex;
}

+ (NSString *)fragmentShaderFilename {
    static NSString *OIBlendFilterFragment = @"OICameraBlendFilter";
    return OIBlendFilterFragment;
}

#pragma mark - 初始化

- (instancetype)init {
    self = [super init];
    
    if (self) {
        [OIContext performSynchronouslyOnImageProcessingQueue:^{
            [[OIContext sharedContext] setAsCurrentContext];
            [filterProgram_ use];
            [filterProgram_ setTextureIndex:1 forTexture:@"maskImage1"];
            [filterProgram_ setTextureIndex:2 forTexture:@"maskImage2"];
            [filterProgram_ setTextureIndex:3 forTexture:@"maskImage3"];
            self.intensity = 1.0;
        }];
        self.mask1Texture = nil;
        self.mask2Texture = nil;
        self.mask3Texture = nil;
    }
    return self;
}

// setprogram

- (void)setIntensity:(float)intensity {
    _intensity = OIClampf(intensity, 0.0, 1.0);
    [filterProgram_ setFloat:_intensity forUniform:@"intensity"];
}

- (void)setBlendTypeArray:(NSArray<NSNumber *> *)blendTypeArray {
    _blendTypeArray = blendTypeArray;
    [filterProgram_ setInt:[[_blendTypeArray objectAtIndex:0] intValue] forUniform:@"comOp1"];
    [filterProgram_ setInt:[[_blendTypeArray objectAtIndex:1] intValue] forUniform:@"comOp2"];
    [filterProgram_ setInt:[[_blendTypeArray objectAtIndex:2] intValue] forUniform:@"comOp3"];
}

- (void)setAlphaArray:(NSArray<NSNumber *> *)alphaArray {
    _alphaArray = alphaArray;
    [filterProgram_ setFloat:[[_alphaArray objectAtIndex:0] floatValue]  forUniform:@"alpha1"];
    [filterProgram_ setFloat:[[_alphaArray objectAtIndex:1] floatValue]  forUniform:@"alpha2"];
    [filterProgram_ setFloat:[[_alphaArray objectAtIndex:2] floatValue]  forUniform:@"alpha3"];
}

- (void)setNumbersOfTexture:(int)numbersOfTexture {
    _numbersOfTexture = numbersOfTexture;
    [filterProgram_ setInt:_numbersOfTexture forUniform:@"numbersOfTexture"];
}

// ==========================================================================================

- (void)setMask1Image:(UIImage *)mask1Image {
    if (!mask1Image) {
        self.mask1Texture = nil;
    }
    self.mask1Texture = [[OITexture alloc] initWithCGImage:mask1Image.CGImage orientation:OITextureOrientationDown];
}

- (void)setMask2Image:(UIImage *)mask2Image {
    if (!mask2Image) {
        self.mask2Texture = nil;
    }
    self.mask2Texture = [[OITexture alloc] initWithCGImage:mask2Image.CGImage orientation:OITextureOrientationDown];
}

- (void)setMask3Image:(UIImage *)mask3Image {
    if (!mask3Image) {
        self.mask3Texture = nil;
    }
    self.mask3Texture = [[OITexture alloc] initWithCGImage:mask3Image.CGImage orientation:OITextureOrientationDown];
}


#pragma mark - 初始化

- (instancetype)initWithMaskImages:(NSArray<UIImage *> *)images {
    self = [super init];
    
    if (self) {
        [OIContext performSynchronouslyOnImageProcessingQueue:^{
            [[OIContext sharedContext] setAsCurrentContext];
            [filterProgram_ use];
            [filterProgram_ setTextureIndex:1 forTexture:@"maskImage1"];
            [filterProgram_ setTextureIndex:2 forTexture:@"maskImage2"];
            [filterProgram_ setTextureIndex:3 forTexture:@"maskImage3"];
            self.intensity = 1.0;
        }];
        self.mask1Texture = nil;
        self.mask2Texture = nil;
        self.mask3Texture = nil;
        
        [self initMaskTextureWithImages:images];
    }
    return self;
}

- (void)initMaskTextureWithImages:(NSArray <UIImage *>*)images {
    for (int i = 0; i<images.count; i++) {
        switch (i) {
            case 0:
                self.mask1Texture = [[OITexture alloc] initWithCGImage:images[i].CGImage orientation:OITextureOrientationDown];
                break;
            case 1:
                self.mask2Texture = [[OITexture alloc] initWithCGImage:images[i].CGImage orientation:OITextureOrientationDown];
                break;
            case 2:
                self.mask3Texture = [[OITexture alloc] initWithCGImage:images[i].CGImage orientation:OITextureOrientationDown];
                break;
        }
    }
}

- (void)setProgramUniform {
    [filterProgram_ use];
    
    [filterProgram_ setFloat:self.intensity forUniform:@"intensity"];
    
    if (self.mask1Texture) {
        [self.mask1Texture bindToTextureIndex:GL_TEXTURE1];
        [filterProgram_ setCoordinatePointer:self.mask1Texture.textureCoordinate coordinateSize:2 forAttribute:@"inputTextureMask1Coordinate"];
    }
    if (self.mask2Texture) {
        [self.mask1Texture bindToTextureIndex:GL_TEXTURE2];
        [filterProgram_ setCoordinatePointer:self.mask2Texture.textureCoordinate coordinateSize:2 forAttribute:@"inputTextureMask2Coordinate"];
    }
    if (self.mask3Texture) {
        [self.mask1Texture bindToTextureIndex:GL_TEXTURE3];
        [filterProgram_ setCoordinatePointer:self.mask3Texture.textureCoordinate coordinateSize:2 forAttribute:@"inputTextureMask3Coordinate"];
    }
    
    
    [filterProgram_ setFloat:_intensity forUniform:@"intensity"];
    
    [filterProgram_ setInt:[[self.blendTypeArray objectAtIndex:0] intValue] forUniform:@"comOp1"];
    [filterProgram_ setInt:[[self.blendTypeArray objectAtIndex:1] intValue] forUniform:@"comOp2"];
    [filterProgram_ setInt:[[self.blendTypeArray objectAtIndex:2] intValue] forUniform:@"comOp3"];
    
    [filterProgram_ setFloat:[[self.alphaArray objectAtIndex:0] floatValue]  forUniform:@"alpha1"];
    [filterProgram_ setFloat:[[self.alphaArray objectAtIndex:1] floatValue]  forUniform:@"alpha2"];
    [filterProgram_ setFloat:[[self.alphaArray objectAtIndex:2] floatValue]  forUniform:@"alpha3"];
    
    [filterProgram_ setInt:self.numbersOfTexture forUniform:@"numbersOfTexture"];
}


@end
