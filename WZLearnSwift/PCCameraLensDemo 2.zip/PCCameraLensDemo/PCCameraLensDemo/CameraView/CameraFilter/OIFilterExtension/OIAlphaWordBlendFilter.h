//
//  OIAlphaWordBlendFilter.h
//  POCONewCamera
//
//  Created by 陈弢 on 2017/7/14.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import <OpenGLESImage/OpenGLESImage.h>

@interface OIAlphaWordBlendFilter : OITwoInputsFilter

@end
