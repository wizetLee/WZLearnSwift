//
//  OILookUpTableFilter.m
//  POCONewCamera
//
//  Created by 陈弢 on 2017/5/15.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import "OILookUpTableFilter.h"

@implementation OILookUpTableFilter

#pragma mark - Shader

+ (NSString *)vertexShaderFilename {
    static NSString *LookUpTableVertex = @"OICameraLookUpTableFilter";
    return LookUpTableVertex;
}

+ (NSString *)fragmentShaderFilename {
    static NSString *LookUpTableFragment = @"OICameraLookUpTableFilter";
    return LookUpTableFragment;
}

#pragma mark - 初始化

- (instancetype)init {
    self = [super init];
    
    if (self) {
        [OIContext performSynchronouslyOnImageProcessingQueue:^{
            [[OIContext sharedContext] setAsCurrentContext];
            [filterProgram_ use];
            [filterProgram_ setTextureIndex:1 forTexture:@"lookUpTable"];
            self.intensity = 1.0;
        }];
        self.tableTexture = nil;
    }
    return self;
}

- (void)setLutImage:(UIImage *)lutImage {
    [self setupLookUpTableTextureWithImage:lutImage];
}

#pragma mark - 初始化

- (instancetype)initWithLutImage:(UIImage *)lutImage {
    self = [super init];
    if (self) {
        [OIContext performSynchronouslyOnImageProcessingQueue:^{
            [[OIContext sharedContext] setAsCurrentContext];
            [filterProgram_ use];
            
            [filterProgram_ setTextureIndex:1 forTexture:@"lookUpTable"];
            self.intensity = 1.0;
        }];
        self.tableTexture = nil;
        [self setupLookUpTableTextureWithImage:lutImage];
    }
    return self;
}

// 加载查表图素材纹理
- (void)setupLookUpTableTextureWithImage:(UIImage *)lutImage {
    if (lutImage) {
        self.tableTexture = [[OITexture alloc] initWithCGImage:lutImage.CGImage orientation:OITextureOrientationDown];
    }
}

// 加载基础黑白素材纹理
- (void)setupBasicBlackWhiteTexture {
    UIImage *blackWhite = [UIImage imageNamed:@"Filter_Color_Basic_Black.png"];
    self.basicBlackWhiteTexture = [[OITexture alloc] initWithCGImage:blackWhite.CGImage orientation:OITextureOrientationDown];
}

- (void)setProgramUniform {
    [filterProgram_ use];
    
    [filterProgram_ setFloat:self.intensity forUniform:@"intensity"];
    
    [self.tableTexture bindToTextureIndex:GL_TEXTURE1];
    [filterProgram_ setCoordinatePointer:self.tableTexture.textureCoordinate coordinateSize:2 forAttribute:@"lookUpTextureCoordinate"];
    
    if (self.isBlackWhiteFilter) {
        [filterProgram_ setInt:1 forUniform:@"isBlackWhite"];
        [self.basicBlackWhiteTexture bindToTextureIndex:GL_TEXTURE2];
        [filterProgram_ setCoordinatePointer:self.basicBlackWhiteTexture.textureCoordinate coordinateSize:2 forAttribute:@"blackWhiteTextureCoordinate"];
    }
}

// setprogram
- (void)setIntensity:(CGFloat)intensity {
    intensity = intensity;
    _intensity = OIClampf(intensity, 0.0, 1.0);
}

- (void)setIsBlackWhiteFilter:(BOOL)isBlackWhiteFilter {
    _isBlackWhiteFilter = isBlackWhiteFilter;
    if (isBlackWhiteFilter == YES) {
        [OIContext performSynchronouslyOnImageProcessingQueue:^{
            [[OIContext sharedContext] setAsCurrentContext];
            [filterProgram_ use];
            [filterProgram_ setTextureIndex:2 forTexture:@"basicBlackWhite"];
        }];
        [self setupBasicBlackWhiteTexture];
    }
}

@end
