//
//  OIAlphaWordBlendFilter.m
//  POCONewCamera
//
//  Created by 陈弢 on 2017/7/14.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import "OIAlphaWordBlendFilter.h"

@implementation OIAlphaWordBlendFilter

+ (NSString *)fragmentShaderFilename {
    static NSString *fName = @"OIAlphaWordBlendFilter";
    return fName;
}

@end
