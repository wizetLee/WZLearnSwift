//
//  OILookUpTableFilter.h
//  POCONewCamera
//
//  Created by 陈弢 on 2017/5/15.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import <OpenGLESImage/OpenGLESImage.h>

// 查表滤镜(目前仅支持64size表格)
@interface OILookUpTableFilter : OIFilter

// 查表图的纹理
@property (nonatomic, strong) OITexture *tableTexture;
@property (nonatomic, strong) OITexture *basicBlackWhiteTexture; // 基础黑白纹理

// 使用256位图表，默认为NO
@property (nonatomic, assign) BOOL enableBigSize;

// 滤镜的强度，0.0 ~ 1.0
@property (nonatomic, assign) CGFloat intensity;

@property (nonatomic, assign) BOOL isBlackWhiteFilter; // 开启是否黑白滤镜，默认NO

- (instancetype)initWithLutImage:(UIImage *)lutImage;
- (void)setLutImage:(UIImage *)lutImage;

@end
