//
//  OILookUpMultipleBlendFilter.m
//  POCONewCamera
//
//  Created by 陈弢 on 2017/7/7.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import "OILookUpMultipleBlendFilter.h"

@implementation OILookUpMultipleBlendFilter

#pragma mark - Shader

+ (NSString *)vertexShaderFilename {
    static NSString *OILookUpMultipleBlendFilterVertex = @"OILookUpMultipleBlendFilter";
    return OILookUpMultipleBlendFilterVertex;
}

+ (NSString *)fragmentShaderFilename {
    static NSString *OILookUpMultipleBlendFilterFragment = @"OILookUpMultipleBlendFilter";
    return OILookUpMultipleBlendFilterFragment;
}

#pragma mark - 初始化

- (instancetype)init {
    self = [super init];
    
    if (self) {
        [OIContext performSynchronouslyOnImageProcessingQueue:^{
            [[OIContext sharedContext] setAsCurrentContext];
            [filterProgram_ use];
            [filterProgram_ setTextureIndex:1 forTexture:@"maskImage1"];
            [filterProgram_ setTextureIndex:2 forTexture:@"maskImage2"];
            [filterProgram_ setTextureIndex:3 forTexture:@"lookUpTable"];
            self.intensity = 1.0;
        }];
        self.mask1Texture = nil;
        self.mask2Texture = nil;
        self.tableTexture = nil;
    }
    return self;
}

// setprogram

- (void)setIntensity:(float)intensity {
    _intensity = OIClampf(intensity, 0.0, 1.0);
    [filterProgram_ setFloat:_intensity forUniform:@"intensity"];
}

- (void)setBlendTypeArray:(NSArray<NSNumber *> *)blendTypeArray {
    _blendTypeArray = blendTypeArray;
    [filterProgram_ setInt:[[_blendTypeArray objectAtIndex:0] intValue] forUniform:@"comOp1"];
    [filterProgram_ setInt:[[_blendTypeArray objectAtIndex:1] intValue] forUniform:@"comOp2"];
    [filterProgram_ setInt:[[_blendTypeArray objectAtIndex:2] intValue] forUniform:@"comOp3"];
}

- (void)setAlphaArray:(NSArray<NSNumber *> *)alphaArray {
    _alphaArray = alphaArray;
    [filterProgram_ setFloat:[[_alphaArray objectAtIndex:0] floatValue]  forUniform:@"alpha1"];
    [filterProgram_ setFloat:[[_alphaArray objectAtIndex:1] floatValue]  forUniform:@"alpha2"];
    [filterProgram_ setFloat:[[_alphaArray objectAtIndex:2] floatValue]  forUniform:@"alpha3"];
}

// ==========================================================================================

- (void)setMask1Image:(UIImage *)mask1Image {
    if (!mask1Image) {
        self.mask1Texture = nil;
    }
    self.mask1Texture = [[OITexture alloc] initWithCGImage:mask1Image.CGImage orientation:OITextureOrientationDown];
}

- (void)setMask2Image:(UIImage *)mask2Image {
    if (!mask2Image) {
        self.mask2Texture = nil;
    }
    self.mask2Texture = [[OITexture alloc] initWithCGImage:mask2Image.CGImage orientation:OITextureOrientationDown];
}

- (void)setTableImage:(UIImage *)tableImage {
    if (!tableImage) {
        self.tableTexture = nil;
    }
    self.tableTexture = [[OITexture alloc] initWithCGImage:tableImage.CGImage orientation:OITextureOrientationDown];
}

#pragma mark - 初始化

- (void)setProgramUniform {
    [filterProgram_ use];
    
    [filterProgram_ setFloat:self.intensity forUniform:@"intensity"];
    
    if (self.mask1Texture) {
        [self.mask1Texture bindToTextureIndex:GL_TEXTURE1];
        [filterProgram_ setCoordinatePointer:self.mask1Texture.textureCoordinate coordinateSize:2 forAttribute:@"inputTextureMask1Coordinate"];
    }
    if (self.mask2Texture) {
        [self.mask1Texture bindToTextureIndex:GL_TEXTURE2];
        [filterProgram_ setCoordinatePointer:self.mask2Texture.textureCoordinate coordinateSize:2 forAttribute:@"inputTextureMask2Coordinate"];
    }
    if (self.tableTexture) {
        [self.tableTexture bindToTextureIndex:GL_TEXTURE3];
        [filterProgram_ setCoordinatePointer:self.tableTexture.textureCoordinate coordinateSize:2 forAttribute:@"lookUpTextureCoordinate"];
    }
    
    
    [filterProgram_ setFloat:_intensity forUniform:@"intensity"];
    
    [filterProgram_ setInt:[[self.blendTypeArray objectAtIndex:0] intValue] forUniform:@"comOp1"];
    [filterProgram_ setInt:[[self.blendTypeArray objectAtIndex:1] intValue] forUniform:@"comOp2"];
    [filterProgram_ setInt:[[self.blendTypeArray objectAtIndex:2] intValue] forUniform:@"comOp3"];
    
    [filterProgram_ setFloat:[[self.alphaArray objectAtIndex:0] floatValue]  forUniform:@"alpha1"];
    [filterProgram_ setFloat:[[self.alphaArray objectAtIndex:1] floatValue]  forUniform:@"alpha2"];
    [filterProgram_ setFloat:[[self.alphaArray objectAtIndex:2] floatValue]  forUniform:@"alpha3"];
    
//    [filterProgram_ setInt:self.numbersOfTexture forUniform:@"numbersOfTexture"];
}


@end
