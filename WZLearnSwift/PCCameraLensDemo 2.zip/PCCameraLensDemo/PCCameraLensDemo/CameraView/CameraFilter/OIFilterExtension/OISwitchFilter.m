//
//  OISwitchFilter.m
//  POCONewCamera
//
//  Created by 陈弢 on 2017/6/12.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import "OISwitchFilter.h"

@implementation OISwitchFilter

#pragma mark - Shader

+ (NSString *)vertexShaderFilename {
    static NSString *OICameraSwitchVertex = @"OICameraSwitchFilter";
    return OICameraSwitchVertex;
}

+ (NSString *)fragmentShaderFilename {
    static NSString *OICameraSwitchFrag = @"OICameraSwitchFilter";
    return OICameraSwitchFrag;
}

#pragma mark - Public Method

- (void)setFirstFilter:(OIFilter *)firstFilter {
    
}

#pragma mark - 初始化

- (instancetype)init {
    self = [super init];
    
    if (self) {
        [OIContext performSynchronouslyOnImageProcessingQueue:^{
            [[OIContext sharedContext] setAsCurrentContext];
            [filterProgram_ use];
            [filterProgram_ setTextureIndex:0 forTexture:@"firstTextureCoordinate"];
            [filterProgram_ setTextureIndex:1 forTexture:@"secondTextureCoordinate"];
            self.index = 0.0;
        }];
        self.firstFilterTexture = nil;
        self.secondFilterTexture = nil;
    }
    return self;
}

- (void)renderRect:(CGRect)rect atTime:(CMTime)time
{
    if (!_firstFilterTexture || !_secondFilterTexture || !enabled_) {
        return;
    }
    
    if (CGSizeEqualToSize(contentSize_, CGSizeZero)) {
        self.contentSize = _firstFilterTexture.size;
    }
    if (CGRectEqualToRect(self.outputFrame, CGRectZero)) {
        self.outputFrame = CGRectMake(0, 0, contentSize_.width, contentSize_.height);
    }
    
    if (!CGSizeEqualToSize(filterFBO_.size, contentSize_)) {
        [filterFBO_ setupStorageForOffscreenWithSize:contentSize_];
    }
    [filterFBO_ bindToPipeline];
    [filterFBO_ clearBufferWithRed:0.0 green:0.0 blue:0.0 alpha:0.0];
    [_firstFilterTexture bindToTextureIndex:GL_TEXTURE0];
    [_secondFilterTexture bindToTextureIndex:GL_TEXTURE1];
    
    [filterProgram_ use];
    [filterProgram_ setTextureIndex:0 forTexture:@"firstTexture"];
    [filterProgram_ setTextureIndex:1 forTexture:@"secondTexture"];
    [self setProgramUniform];
    [filterProgram_ setCoordinatePointer:[filterFBO_ verticesCoordinateForDrawableRect:rect] coordinateSize:2 forAttribute:@"position"];
    [filterProgram_ setCoordinatePointer:_firstFilterTexture.textureCoordinate coordinateSize:2 forAttribute:@"firstTextureCoordinate"];
    [filterProgram_ setCoordinatePointer:_secondFilterTexture.textureCoordinate coordinateSize:2 forAttribute:@"secondTextureCoordinate"];
    [filterProgram_ draw];
    
    outputTexture_ = filterFBO_.texture;
    [self produceAtTime:time];
    
    _firstFilterTexture = nil;
    _secondFilterTexture = nil;
}


#pragma mark - 初始化

- (void)setInputTexture:(OITexture *)texture {
    if (!_firstFilterTexture) {
        _firstFilterTexture = texture;
    } else if (!_secondFilterTexture) {
        _secondFilterTexture = texture;
    }
}

- (void)setProgramUniform {
    [filterProgram_ use];
    
    [filterProgram_ setFloat:self.index forUniform:@"index"];
    [filterProgram_ setInt:self.closewise forUniform:@"closewise"];
}

@end
