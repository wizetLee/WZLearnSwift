//
//  OIMultipleBlendFilter.h
//  POCONewCamera
//
//  Created by 陈弢 on 2017/5/18.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import <OpenGLESImage/OpenGLESImage.h>

typedef NS_ENUM(int, OIMultipleBlendFilterType) {
    kOIBlendTypeNormalBlend = 1,
    kOIBlendTypeColorBurnBlend = 8,
    kOIBlendTypeColorDodgeBlend = 9,
    kOIBlendTypeDarkenBlend = 20,
    kOIBlendTypeDifferenceBlend = 26,
    kOIBlendTypeExclusionBlend = 29,
    kOIBlendTypeHardLightBlend = 30,
    kOIBlendTypeLightenBlend = 33,
    kOIBlendTypeLinearLightBlend = 34,
    kOIBlendTypeMultiplyBlend = 38,
    kOIBlendTypeOverlayBlend = 41,
    kOIBlendTypeScreenBlend = 45,
    kOIBlendTypeSoftLightBlend = 46,
    kOIBlendTypeVividLightBlend = 59,
    kOIBlendTypeLinearDodgeBlend = 61
};

// 多重混合滤镜
@interface OIMultipleBlendFilter : OIFilter


// 最大三张纹理纹理
@property (nonatomic, strong) OITexture *mask1Texture;
@property (nonatomic, strong) OITexture *mask2Texture;
@property (nonatomic, strong) OITexture *mask3Texture;

@property (nonatomic, assign) int numbersOfTexture; // 纹理数

// 混合模式
@property (nonatomic, assign) OIMultipleBlendFilterType blendType;
// 素材混合的透明度，0.0 ~ 1.0
//@property (nonatomic, assign) float alpha;

// 混合模式数组
@property (nonatomic, strong) NSArray <NSNumber *> *blendTypeArray;
// 素材混合的透明度数组
@property (nonatomic, strong) NSArray <NSNumber *> *alphaArray;

// 滤镜的强度 0.0 ~ 1.0
@property (nonatomic, assign) float intensity;

- (void)setMask1Image:(UIImage *)mask1Image;
- (void)setMask2Image:(UIImage *)mask2Image;
- (void)setMask3Image:(UIImage *)mask3Image;

- (instancetype)initWithMaskImages:(NSArray <UIImage *>*)images;

@end
