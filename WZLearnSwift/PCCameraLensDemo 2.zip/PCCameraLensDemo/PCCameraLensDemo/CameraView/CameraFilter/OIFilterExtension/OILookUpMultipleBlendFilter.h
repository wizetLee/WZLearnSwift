//
//  OILookUpMultipleBlendFilter.h
//  POCONewCamera
//
//  Created by 陈弢 on 2017/7/7.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import <OpenGLESImage/OpenGLESImage.h>


typedef NS_ENUM(int, OILookUpMultipleBlendFilterType) {
    kOILookUpBlendTypeNormalBlend = 1,
    kOILookUpBlendTypeColorBurnBlend = 8,
    kOILookUpBlendTypeColorDodgeBlend = 9,
    kOILookUpBlendTypeDarkenBlend = 20,
    kOILookUpBlendTypeDifferenceBlend = 26,
    kOILookUpBlendTypeExclusionBlend = 29,
    kOILookUpBlendTypeHardLightBlend = 30,
    kOILookUpBlendTypeLightenBlend = 33,
    kOILookUpBlendTypeLinearLightBlend = 34,
    kOILookUpBlendTypeMultiplyBlend = 38,
    kOILookUpBlendTypeOverlayBlend = 41,
    kOILookUpBlendTypeScreenBlend = 45,
    kOILookUpBlendTypeSoftLightBlend = 46,
    kOILookUpBlendTypeVividLightBlend = 59,
    kOILookUpBlendTypeLinearDodgeBlend = 61
};

// 多重混合滤镜
@interface OILookUpMultipleBlendFilter : OIFilter

// 最大三张纹理纹理
@property (nonatomic, strong) OITexture *mask1Texture;
@property (nonatomic, strong) OITexture *mask2Texture;
@property (nonatomic, assign) int numbersOfTexture; // 纹理数
// 查表图纹理
@property (nonatomic, strong) OITexture *tableTexture;

// 混合模式
@property (nonatomic, assign) OILookUpMultipleBlendFilterType blendType;
// 混合模式数组
@property (nonatomic, strong) NSArray <NSNumber *> *blendTypeArray;
// 素材混合的透明度数组
@property (nonatomic, strong) NSArray <NSNumber *> *alphaArray;

// 滤镜的强度 0.0 ~ 1.0
@property (nonatomic, assign) float intensity;

- (void)setMask1Image:(UIImage *)mask1Image;
- (void)setMask2Image:(UIImage *)mask2Image;
- (void)setTableImage:(UIImage *)tableImage;

//- (instancetype)initWithMaskImages:(NSArray <UIImage *>*)images andLutImage:(UIImage *)tableImage;



@end
