//
//  INPCamera.m
//  POCONewCamera
//
//  Created by 陈弢 on 2017/5/25.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import "INPCamera.h"

@interface INPCamera ()

@property (nonatomic) dispatch_queue_t microphoneQueue;

@property (nonatomic, strong) AVCaptureDevice *microphone;
@property (nonatomic, strong) AVCaptureDeviceInput *audioInput;
@property (nonatomic, strong) AVCaptureAudioDataOutput *audioOutput;
@property (nonatomic, strong) AVCaptureMetadataOutput *QRCodeOutput;

@end

const char *microphoneQueue = "InterPhoto.camera.microphone.queue";

@implementation INPCamera

@synthesize delegate;

static INPCamera *shareINPCamera = nil;

#pragma mark - ShareInstance
+ (INPCamera *)shareINPCamera {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        shareINPCamera = [[self alloc] init];
    });
    return shareINPCamera;
}

#pragma mark - Dealloc



#pragma mark - Init

- (instancetype)init {
    self = [self initWithCameraPosition:AVCaptureDevicePositionBack sessionPreset:AVCaptureSessionPresetHigh];
    return self;
}

- (instancetype)initWithCameraPosition:(AVCaptureDevicePosition)cameraPosition sessionPreset:(NSString *)sessionPreset {
    self = [super initWithCameraPosition:cameraPosition sessionPreset:sessionPreset];
    if (self) {
        // 添加麦克风输入
        self.microphoneQueue = dispatch_queue_create(microphoneQueue, NULL);
        
        [cameraSession_ beginConfiguration];
        self.microphone = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeAudio];
        
        NSError *error = nil;
        
        self.audioInput = [[AVCaptureDeviceInput alloc] initWithDevice:self.microphone error:&error];
        
        if (error) {
            NSLog(@"OpenGLESImage Error at INPCamera - (id)initWithCameraPosition: sessionPreset:, message: %@.", error);
        }
        
        if ([cameraSession_ canAddInput:self.audioInput]) {
            [cameraSession_ addInput:self.audioInput];
        } else {
            NSLog(@"OpenGLESImage Error at INPCamera - (id)initWithCameraPosition: sessionPreset:, message: audio input can not be add.");
        }
        
        self.audioOutput = [[AVCaptureAudioDataOutput alloc] init];
        
        //由于加入mic的输出之后，引起很多bug，比如不能震动，后台音乐关闭等，故将添加mic输出的代码移到后面，等需要录音时再添加。
        [cameraSession_ commitConfiguration];
        
    }
    return self;
}

#pragma mark - 属性的setter和getter

- (void)setMicrophoneEnabled:(BOOL)microphoneEnabled {
    if (_microphoneEnabled == microphoneEnabled) {
        return;
    }
    
    _microphoneEnabled = microphoneEnabled;
    
    if (_microphoneEnabled) {
        [cameraSession_ beginConfiguration];
        
        if ([cameraSession_ canAddOutput:self.audioOutput]) {
            [cameraSession_ addOutput:self.audioOutput];
        } else {
            NSLog(@"OpenGLESImage Error at INPCamera - (id)initWithCameraPosition: sessionPreset:, message: audio output can not be add.");
        }
        
        [self.audioOutput setSampleBufferDelegate:self queue:self.microphoneQueue];
        [cameraSession_ commitConfiguration];
    } else {
        [cameraSession_ beginConfiguration];
        [self.audioOutput setSampleBufferDelegate:nil queue:NULL];
        
        [cameraSession_ removeOutput:self.audioOutput];
        [cameraSession_ commitConfiguration];
    }
}

- (void)setQRCodeDetectionEnabled:(BOOL)QRCodeDetectionEnabled {
    if (QRCodeDetectionEnabled) {
        [cameraSession_ beginConfiguration];
        
        self.QRCodeOutput = [[AVCaptureMetadataOutput alloc] init];
        
        //设置代理监听输出对象的输出数据，在主线程中刷新
        [self.QRCodeOutput setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
        
        // 添加输出到会话中（判断session是否已满）
        if ([cameraSession_ canAddOutput:self.QRCodeOutput]) {
            [cameraSession_ addOutput:self.QRCodeOutput];
        } else {
            NSLog(@"OpenGLESImage Error at INPCamera - (id)initWithCameraPosition: sessionPreset:, message: qrcode output can not be add.");
        }
        
        //告诉输出对象, 需要输出什么样的数据 (二维码还是条形码等) 要先创建会话才能设置
        self.QRCodeOutput.metadataObjectTypes = @[AVMetadataObjectTypeQRCode];
        [cameraSession_ commitConfiguration];
    } else {
        [cameraSession_ beginConfiguration];
        
        [cameraSession_ removeOutput:self.QRCodeOutput];
        [self.QRCodeOutput setMetadataObjectsDelegate:nil queue:NULL];
        
        self.QRCodeOutput = nil;
        [cameraSession_ commitConfiguration];
    }
    _QRCodeDetectionEnabled = QRCodeDetectionEnabled;
}

#pragma mark - 公有方法

- (NSDictionary *)recommendedAudioSettingsForWriterWithOutputFileType:(NSString *)outputFileType {
    return [self.audioOutput recommendedAudioSettingsForAssetWriterWithOutputFileType:outputFileType];
}

- (AVCaptureDevice *)captureDevice {    
    return camera_;
}

#pragma mark - AVCaptureVideoDataOutputSampleBufferDelegate & AVCaptureAudioDataOutputSampleBufferDelegate

- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer fromConnection:(AVCaptureConnection *)connection {
    if (!self.isEnabled) {
        return;
    }
    
    if (captureOutput == self.audioOutput) {
        if (self.delegate && [self.delegate respondsToSelector:@selector(camera:didReceiveAudioSampleBuffer:)]) {
            CFRetain(sampleBuffer);
            [self.delegate camera:self didReceiveAudioSampleBuffer:sampleBuffer];
            CFRelease(sampleBuffer);
        }
    } else if (captureOutput == videoOutput_) {
        [super captureOutput:captureOutput didOutputSampleBuffer:sampleBuffer fromConnection:connection];
    }
}

#pragma mark - AVCaptureMetadataOutputObjectsDelegate

//二维码扫描结果
- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputMetadataObjects:(NSArray *)metadataObjects fromConnection:(AVCaptureConnection *)connection {
    if (metadataObjects.count > 0 && self.delegate && [self.delegate respondsToSelector:@selector(camera:didGetStringFromQRCode:)]) {
        AVMetadataMachineReadableCodeObject *metaDataObject = [metadataObjects firstObject];
        [self.delegate camera:self didGetStringFromQRCode:metaDataObject.stringValue];
    }
    
}

@end
