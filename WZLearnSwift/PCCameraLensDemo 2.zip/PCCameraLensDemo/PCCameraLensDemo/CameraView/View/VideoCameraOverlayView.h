//
//  VideoCameraOverlayView.h
//  POCONewCamera
//
//  Created by 陈弢 on 2017/6/6.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VideoCameraPreviewView.h"
#import "INPVideoCameraFilterView.h"

// pan拖拽模式
typedef NS_ENUM(NSInteger, VideoCameraPanAnimationDirection) {
    kVideoCameraPanAnimationDirectionUp,
    kVideoCameraPanAnimationDirectionDown,
    kVideoCameraPanAnimationDirectionLeft,
    kVideoCameraPanAnimationDirectionRight,
    
    
    kVideoCameraPanAnimationPortraitDirectionRight,
    kVideoCameraPanAnimationPortraitDirectionLeft,
    
    kVideoCameraPanAnimationLandscapeLeftDirectionLeft,
    kVideoCameraPanAnimationLandscapeLeftDirectionRight,
    
    kVideoCameraPanAnimationLandscapeRightDirectionLeft,
    kVideoCameraPanAnimationLandscapeRightDirectionRight,
};


// 相机样式
typedef NS_ENUM(NSInteger, InterPhotoCameraOverlayType) {
    kInterPhotoCameraOverlayTypeNormal,
    kInterPhotoCameraOverlayTypePhotoOnly,
    kInterPhotoCameraOverlayTypeVideoOnly,
};


@protocol VideoCameraOverlayDelegate <NSObject>

- (void)shouldBcakHome;
- (void)shouldExchangeCameraPosition:(VideoCameraPosition)position;//切换前后镜头
- (void)shouldExchangeCameraMode:(VideoCameraMode)mode;//切换 拍照 视频
- (void)selectFilterID:(NSInteger)idNumber;

- (void)pressedShutterWithMode:(VideoCameraMode)mode;//按下快门
- (void)shouldShouldAlbumViewWithMode:(VideoCameraMode)mode;//跳转相册

- (void)shouldShowSettingViewWithMode:(VideoCameraMode)mode;//显示设置界面

- (void)cameraRampToVideoZoomFactor:(CGFloat)factor withRate:(float)rate; // 调整镜头缩放


- (void)overlayViewTapFocosExposurePoint;
- (void)changeFocusCenterPoint:(CGPoint)focusPoint;
- (void)changeExposureCenterPoint:(CGPoint)exposurePoint;


- (void)videoCameraUesCourseView;


- (void)didChooseINPFilter:(OIFilter *)filter; // 选择了某个印象滤镜


- (void)didChooseNextINPFilter:(OIFilter *)filter withOrder:(BOOL)nextOrder; // 下一个滤镜 1:右边 0:左边
- (void)didPanFilterWithPercent:(CGFloat)percent;
- (void)didEndFilterChoosingWithPercent:(CGFloat)percent resume:(BOOL)isResume; // 结束滤镜，是恢复原滤镜还是切换到下一个

@end


@interface VideoCameraOverlayView : UIView

@property (nonatomic,weak)id<VideoCameraOverlayDelegate>delegate;
@property (nonatomic,assign)VideoCameraMode  cameraMode;//默认 kVideoCameraModeStillImage
@property (nonatomic,assign)VideoCameraPosition  cameraPosition;//默认 kVideoCameraPositionBack
@property (nonatomic,assign)NSTimeInterval recordTime;
@property (nonatomic,assign)BOOL  showFilter;
@property (nonatomic,assign)CGRect previewFrame;
@property (nonatomic,assign)NSInteger selectFilterID;
@property (nonatomic,strong)UIImageView *albumImageView;

@property (nonatomic, copy) NSString *selectedColorId;

@property (nonatomic, assign) InterPhotoCameraOverlayType cameraType;
// 设置手势view的大小
- (void)adjustGestureViewFrameWithFrame:(CGRect)frame;
// 设置overLay与设备方向的关系
- (void)setCameraOverlayOrientation:(VideoCameraViewOrientationMode)orientationMode;

- (void)startRecordVideo;
- (void)stopRecordVideo;
- (void)cancelRecordVideo;
- (void)shutterSendTouchUpInsideAction;
- (void)takePhotoAnimation;//点击拍照闪一下

// 开启/禁用 手势
//- (void)enableSwipeGesture:(BOOL)enable;

// 拍摄镜头用的滤镜
@property (nonatomic, strong) NSDictionary *filterColorDic;

// 切换滤镜
- (void)changeFilterCoverImageToNextFilter;

@end
