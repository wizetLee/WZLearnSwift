//
//  INPCameraCountDownView.h
//  POCONewCamera
//
//  Created by 紫秋 刘 on 2017/7/7.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol INPCameraCountDownViewDelegate <NSObject>

- (void)countDownTimeup;
- (void)cancelCountDownTimeUp;

@end


@interface INPCameraCountDownView : UIView

@property (nonatomic,weak)id<INPCameraCountDownViewDelegate>delegate;

- (instancetype)initWithCountDownTime:(NSTimeInterval)seconds;

- (void)cancelCountDown;

@end
