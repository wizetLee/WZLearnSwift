//
//  VideoCameraSettingView.m
//  POCONewCamera
//
//  Created by 紫秋 刘 on 2017/6/7.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import "VideoCameraSettingView.h"
//#import "INPFilterCountNumber.h"

@interface VideoCameraSettingView ()<UITableViewDelegate,UITableViewDataSource>{

    UITableView *_tableView;
    UIView *_backgroundView;
    float _cellHeight;
    BOOL hasFlash;
}

@property (nonatomic,strong)NSMutableArray *functionItems;
@property (nonatomic,strong)NSArray *scaleItems;


@end

@implementation VideoCameraSettingView

- (instancetype)initWithFrame:(CGRect)frame withDelegate:(id)delegate {
    
    self = [super initWithFrame:frame];
    self.delegate = delegate;
    self.backgroundColor = [UIColor clearColor];
    self.shutterMode = kVideoCameraModeStillImage;
    _cellHeight = 55 * 1;
    [self configUI];
    
    return self;
}

- (void)configData{
    
    NSString *settingKey = @"123";
    if(self.shutterMode == kVideoCameraModeStillImage){
        
        settingKey = @"123";
    }
    
    NSDictionary *settingDic = [[NSUserDefaults standardUserDefaults] objectForKey:settingKey];
    
    NSString *flashString = settingDic[@"123"];
    NSString *scaleString = settingDic[@"123"];
    NSString *timerString = settingDic[@"123"];
    
    self.flashType = flashString.integerValue;
    self.timerType = timerString.integerValue;
    self.scaleType = [self viewScaleWithString:scaleString];
    
}

- (void)configUI{
    hasFlash = [self.delegate videoSettingHasFlash];
    
    
    UIBlurEffect *effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    _backgroundView = [[UIVisualEffectView alloc] initWithEffect:effect];
    _backgroundView.frame = CGRectMake(10 * 1,50 + 20 * 1,[UIScreen mainScreen].bounds.size.width - 20 * 1, (hasFlash ? 4:3) * _cellHeight + 60 * 1);
    [self addSubview:_backgroundView];
    
    UIView *blackView = [[UIView alloc] initWithFrame:_backgroundView.bounds];
//    blackView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.6];
    blackView.backgroundColor = [UIColor clearColor];
    [_backgroundView addSubview:blackView];
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(15 * 1,5 * 1,CGRectGetWidth(_backgroundView.frame) - 30 * 1, _cellHeight * 5) style:UITableViewStylePlain];
    _tableView.backgroundColor = [UIColor clearColor];
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _tableView.backgroundView = nil;
//    _tableView.backgroundColor = COLOR_RGB_255(14, 14, 14);
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.delaysContentTouches = NO;
    _tableView.scrollEnabled = NO;
    [_backgroundView addSubview:_tableView];

}

#pragma mark - Public Method
// 设定view随着设备方向做出的旋转
- (void)setCameraSettingViewOrientation:(VideoCameraViewOrientationMode)orientationMode withAnimation:(BOOL)animated {
    CGFloat translatePosition = 1 ? 150 : 60;
    switch (orientationMode) {
        case kVideoCameraViewOrientationModePortrait:
            [self cameraOverLayViewsTransformWithAngle:0 translate:0 withAnimation:animated];
            break;
        case kVideoCameraViewOrientationModeLeft:
            [self cameraOverLayViewsTransformWithAngle:M_PI_2 translate:translatePosition withAnimation:animated];
            break;
        case kVideoCameraViewOrientationModeRight:
            [self cameraOverLayViewsTransformWithAngle:-M_PI_2 translate:-translatePosition withAnimation:animated];
            break;
        case kVideoCameraViewOrientationModeUpSideDown:
            [self cameraOverLayViewsTransformWithAngle:0 translate:0 withAnimation:animated];
            break;
    }
}

- (void)cameraOverLayViewsTransformWithAngle:(CGFloat)angle translate:(CGFloat)translate withAnimation:(BOOL)animated {
    if (animated) {
        [UIView animateWithDuration:0.2 animations:^{
            _backgroundView.transform = CGAffineTransformMakeRotation(angle);
            _backgroundView.transform = CGAffineTransformTranslate(_backgroundView.transform, translate, 0);
        }];
    } else {
        _backgroundView.transform = CGAffineTransformMakeRotation(angle);
        _backgroundView.transform = CGAffineTransformTranslate(_backgroundView.transform, translate, 0);
    }
}


#pragma mark tableview Delegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return _cellHeight;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.functionItems.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Identifier"];
    
    if(cell == nil){
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Identifier"];
        cell.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    for(UIView *aView in cell.contentView.subviews){
        
        [aView removeFromSuperview];
    }
    
    NSDictionary *itemDic = self.functionItems[indexPath.row];
    NSArray *selectItems = itemDic[@"selectType"];
    
    UIColor *lineColor = [UIColor blackColor];// COLOR_RGB_255(85, 85, 85);
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 90 * 1, _cellHeight)];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.text = itemDic[@"title"];
    titleLabel.font = [UIFont systemFontOfSize:15 * 1];
    titleLabel.textColor = [UIColor blackColor];//COLOR_RGB_255(153, 153, 153);
    [cell.contentView addSubview:titleLabel];
    
    NSArray *functionIndexArray = hasFlash ? @[@0, @1, @2, @3, @4] : @[@0, @1, @5, @2, @3];
    
    if(indexPath.row == [functionIndexArray[0] intValue]){
        
        titleLabel.font = [UIFont boldSystemFontOfSize:15 * 1];
        titleLabel.textColor = [UIColor whiteColor];
        lineColor =  [UIColor blackColor];// COLOR_RGB_255(153, 153, 153);
    }
    else if(indexPath.row == [functionIndexArray[1] intValue]){
        
        NSInteger itemCount = selectItems.count;
        CGFloat totalWidth = 30 * 1 * itemCount + 60 * 1;
        CGFloat firstOffsetX = CGRectGetWidth(_tableView.frame) - totalWidth;
        titleLabel.font = [UIFont systemFontOfSize:12 * 1];
        
        for(NSInteger i= 0; i<itemCount; i++){
            NSString *scaleString = selectItems[i];
            VideoCameraPreviewCrop rowScaleType = [self viewScaleWithString:scaleString];
            
            bool isSelectScale = (rowScaleType == self.scaleType);
            
            NSString *suffix = isSelectScale? @"sel":@"nor";
            NSString *imgName = [NSString stringWithFormat:@"cameraScale%@_%@",scaleString,suffix];
            UIImage *image = [UIImage imageNamed:imgName];
            UIButton *scaleBtn = [[UIButton alloc] initWithFrame:CGRectMake(firstOffsetX + (60 * 1 * i), 0, 30 * 1, _cellHeight)];

            scaleBtn.tag = scaleString.integerValue;
            [scaleBtn setImage:image forState:UIControlStateNormal];
            [scaleBtn addTarget:self action:@selector(switchScale:) forControlEvents:UIControlEventTouchUpInside];
            [cell.contentView addSubview:scaleBtn];
            
        }
    }
    else if(indexPath.row == [functionIndexArray[2] intValue] ){
        
        NSInteger itemCount = selectItems.count;
        
        if (itemCount == 3) {
            CGFloat totalWidth = 30 * 1 * itemCount + 60 * 1;
            CGFloat firstOffsetX = CGRectGetWidth(_tableView.frame) - totalWidth;
            titleLabel.font = [UIFont systemFontOfSize:12 * 1];
            
            for(NSInteger i= 0; i<itemCount; i++){
                
                NSString *itemString = selectItems[i];
                VideoCameraViewFlashMode itemNumber = [self exchangeFlashTypeWithString:itemString];
                bool isSelectScale = (itemNumber == self.flashType);
                
                UIColor *labelColor = [UIColor greenColor]; // 1? COLOR_RGB_255(255, 196, 51) : COLOR_RGB(255, 255, 255);
                UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(firstOffsetX + (60 * 1 * i), 0, 30 * 1, _cellHeight)];
                btn.tag = itemNumber;
                btn.titleLabel.font = [UIFont systemFontOfSize: 12 * 1];
                [btn setTitle:itemString forState:UIControlStateNormal];
                [btn setTitleColor:labelColor forState:UIControlStateNormal];
                [btn addTarget:self action:@selector(switchFlash:) forControlEvents:UIControlEventTouchUpInside];
                [cell.contentView addSubview:btn];
                
            }
        } else if (itemCount == 2) {
            itemCount = 3;
            CGFloat totalWidth = 30 * 1 * itemCount + 60 * 1;
            CGFloat firstOffsetX = CGRectGetWidth(_tableView.frame) - totalWidth;
            titleLabel.font = [UIFont systemFontOfSize:12 * 1];
            
            for(NSInteger i= 1; i<3; i++){
                
                NSString *itemString = selectItems[i-1];
                VideoCameraViewFlashMode itemNumber = [self exchangeFlashTypeWithString:itemString];
                
                VideoCameraViewFlashMode flashMode = self.flashType;
                
                if(self.flashType == kVideoCameraViewFlashModeAuto){
                    
                    flashMode = kVideoCameraViewFlashModeDisenabled;
                }
                
                bool isSelectScale = (itemNumber == flashMode);
                
                
                UIColor *labelColor = [UIColor yellowColor];//isSelectScale? COLOR_RGB_255(255, 196, 51) : COLOR_RGB(255, 255, 255);
                UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(firstOffsetX + (60 * 1 * i), 0, 30 * 1, _cellHeight)];
                btn.tag = itemNumber;
                btn.titleLabel.font = [UIFont systemFontOfSize: 12 * 1];
                [btn setTitle:itemString forState:UIControlStateNormal];
                [btn setTitleColor:labelColor forState:UIControlStateNormal];
                [btn addTarget:self action:@selector(switchFlash:) forControlEvents:UIControlEventTouchUpInside];
                [cell.contentView addSubview:btn];
            }
        }
    }
    else if(indexPath.row == [functionIndexArray[3] intValue]){
        
        NSInteger itemCount = selectItems.count;
        CGFloat totalWidth = 30 * 1 * itemCount + 60 * 1;
        CGFloat firstOffsetX = CGRectGetWidth(_tableView.frame) - totalWidth;
        titleLabel.font = [UIFont systemFontOfSize:12 * 1];
        
        for(NSInteger i= 0; i<itemCount; i++){
            
            NSString *itemString = selectItems[i];
            BOOL isCloseTimer = [itemString isEqualToString:@"关闭"];
            NSInteger itemNumber = isCloseTimer? 0 : itemString.integerValue;
            
            itemString = isCloseTimer ? itemString : [itemString stringByAppendingString:@"S"];
            
            bool isSelectScale = (itemNumber == self.timerType);
            
            UIColor *labelColor = [UIColor redColor];//isSelectScale? COLOR_RGB_255(255, 196, 51) : COLOR_RGB(255, 255, 255);
            UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(firstOffsetX + (60 * 1) * i, 0, 30 * 1, _cellHeight)];
            btn.tag = itemNumber;
            btn.titleLabel.font = [UIFont systemFontOfSize: 12 * 1];
            [btn setTitle:itemString forState:UIControlStateNormal];
            [btn setTitleColor:labelColor forState:UIControlStateNormal];
            [btn addTarget:self action:@selector(switchTimer:) forControlEvents:UIControlEventTouchUpInside];
            [cell.contentView addSubview:btn];
            
        }
        
    }
    else if(indexPath.row == [functionIndexArray[4] intValue]){
        
        NSInteger itemCount = selectItems.count;
        itemCount = 3;
        CGFloat totalWidth = 30 * 1 * itemCount + 60 * 1;
        CGFloat firstOffsetX = CGRectGetWidth(_tableView.frame) - totalWidth;
        titleLabel.font = [UIFont systemFontOfSize:12 * 1];
        
        NSDictionary *settingDic = [[NSUserDefaults standardUserDefaults] objectForKey:@"1"];
        NSString *touchScreenString = settingDic[@"1"];
        BOOL openTouchScreen = [touchScreenString boolValue];
        
        for(NSInteger i= 1; i<itemCount; i++){
            
            NSString *itemString = selectItems[i-1];
            BOOL isCloseTimer = [itemString isEqualToString:@"关闭"];
            NSInteger itemNumber = isCloseTimer? 0 : 1;
            
            bool isSelectScale = (itemNumber == openTouchScreen);
            
            UIColor *labelColor = [UIColor redColor];//isSelectScale? COLOR_RGB_255(255, 196, 51) : COLOR_RGB(255, 255, 255);
            UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(firstOffsetX + (60 * 1) * i, 0, 30 * 1, _cellHeight)];
            btn.tag = itemNumber;
            btn.titleLabel.font = [UIFont systemFontOfSize: 12 * 1];
            [btn setTitle:itemString forState:UIControlStateNormal];
            [btn setTitleColor:labelColor forState:UIControlStateNormal];
            [btn addTarget:self action:@selector(switchTouchScreen:) forControlEvents:UIControlEventTouchUpInside];
            [cell.contentView addSubview:btn];
            
        }
    }
    
    if(indexPath.row < (self.functionItems.count - 1)){
        
        UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, _cellHeight - 1 * 1,CGRectGetWidth(tableView.frame), 1 * 1)];
        line.backgroundColor = lineColor;
        [cell.contentView addSubview:line];
    }
    
    return cell;
}




#pragma mark 切换镜头比例
- (void)switchScale:(UIButton *)sender{
    
    NSString *settingKey = @"21";
    if(self.shutterMode == kVideoCameraModeStillImage){
        
        settingKey = @"21";
    }
    
    NSString *value = [NSString stringWithFormat:@"%d",(int)sender.tag];
    self.scaleType = [self viewScaleWithString:value];
    
    NSDictionary *settingDic    = [[NSUserDefaults standardUserDefaults] objectForKey:settingKey];
    NSMutableDictionary *tmpDic = [NSMutableDictionary dictionaryWithDictionary:settingDic];
    tmpDic[@"21"] = value;
    [[NSUserDefaults standardUserDefaults] setObject:tmpDic forKey:settingKey];
    
    [_tableView reloadData];
    
    // 统计
    switch (self.scaleType) {
        case kVideoCameraPreviewCrop16To9:
            if (self.shutterMode == kVideoCameraModeStillImage) {
//                [[CLReporting sharedInstance] pushEvent:kCameraCountIndexOfPhotoMode16To9 paraString:nil];
            } else {
//                [[CLReporting sharedInstance] pushEvent:kCameraCountIndexOfVideoMode16To9 paraString:nil];
            }
            break;
        case kVideoCameraPreviewCrop4To3:
//            [[CLReporting sharedInstance] pushEvent:kCameraCountIndexOfPhotoMode4To3 paraString:nil];
            break;
        case kVideoCameraPreviewCrop235To1:
//            [[CLReporting sharedInstance] pushEvent:kCameraCountIndexOfVideoMode235To1 paraString:nil];
            break;
        case kVideoCameraPreviewCrop1To1:
            if (self.shutterMode == kVideoCameraModeStillImage) {
//                [[CLReporting sharedInstance] pushEvent:kCameraCountIndexOfPhotoMode1To1 paraString:nil];
            } else {
//                [[CLReporting sharedInstance] pushEvent:kCameraCountIndexOfVideoMode1To1 paraString:nil];
            }
            break;
        default:
            break;
    }
    
    if([self.delegate respondsToSelector:@selector(shouldChangeScale:)]){
        [self.delegate shouldChangeScale:self.scaleType];
    }
}

#pragma mark 闪光灯设置
- (void)switchFlash:(UIButton *)sender{
    
    NSString *settingKey = kVideoSettingKey;
    if(self.shutterMode == kVideoCameraModeStillImage){
        
        settingKey = kPhotoSettingKey;
    }
    
    self.flashType = sender.tag;
    NSDictionary *settingDic    = [[NSUserDefaults standardUserDefaults] objectForKey:settingKey];
    NSMutableDictionary *tmpDic = [NSMutableDictionary dictionaryWithDictionary:settingDic];
    tmpDic[kCameraFreshSetting] = [NSString stringWithFormat:@"%d",(int)sender.tag];
    [[NSUserDefaults standardUserDefaults] setObject:tmpDic forKey:settingKey];
    [_tableView reloadData];
    
    if([self.delegate respondsToSelector:@selector(shouldChangeFlash:)]){
        
        [self.delegate shouldChangeFlash:self.flashType];
    }
}


#pragma mark 触屏设置
- (void)switchTouchScreen:(UIButton *)sender{

    NSString *settingKey = kVideoSettingKey;
    if(self.shutterMode == kVideoCameraModeStillImage){
        
        settingKey = kPhotoSettingKey;
    }
    
    self.isTouchScreen = sender.tag;
    
    // 统计
    if (self.isTouchScreen == YES) {
        [[CLReporting sharedInstance] pushEvent:kCameraCountIndexOfPhotoTouchScreen paraString:nil];
    }
    NSDictionary *settingDic            = [[NSUserDefaults standardUserDefaults] objectForKey:settingKey];
    NSMutableDictionary *tmpDic         = [NSMutableDictionary dictionaryWithDictionary:settingDic];
    tmpDic[kCameraTouchScreenSetting]   = [NSString stringWithFormat:@"%d",(int)sender.tag];
    [[NSUserDefaults standardUserDefaults] setObject:tmpDic forKey:settingKey];

    [_tableView reloadData];
    
    if([self.delegate respondsToSelector:@selector(shouldChangeTouchSceenEnable:)]){
        
        [self.delegate shouldChangeTouchSceenEnable:self.isTouchScreen];
    }
}

#pragma mark 时长设置
- (void)switchTimer:(UIButton *)sender{
    
    NSString *settingKey = kVideoSettingKey;
    if(self.shutterMode == kVideoCameraModeStillImage){
        
        settingKey = kPhotoSettingKey;
    }
    
    self.timerType = sender.tag;
    NSDictionary *settingDic = [[NSUserDefaults standardUserDefaults] objectForKey:settingKey];
    NSMutableDictionary *tmpDic = [NSMutableDictionary dictionaryWithDictionary:settingDic];
    tmpDic[kCameraTimerSetting] = [NSString stringWithFormat:@"%d",(int)sender.tag];
    [[NSUserDefaults standardUserDefaults] setObject:tmpDic forKey:settingKey];
    [_tableView reloadData];
    
    // 统计
    switch (self.timerType) {
        case 10:
            if (self.shutterMode == kVideoCameraModeVideo) {
                [[CLReporting sharedInstance] pushEvent:kCameraCountIndexOfVideoDuration10s paraString:nil];
            }
            break;
        case 30:
            [[CLReporting sharedInstance] pushEvent:kCameraCountIndexOfVideoDuration30s paraString:nil];
            break;
        case 60:
            [[CLReporting sharedInstance] pushEvent:kCameraCountIndexOfVideoDuration60s paraString:nil];
            break;
        default:
            break;
    }
    
    if([self.delegate respondsToSelector:@selector(shouldChangeShutTime:)]){
        [self.delegate shouldChangeShutTime:self.timerType];
    }
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    UITouch *touch = [touches anyObject];
    UIView *touchView = touch.view;
    if(touchView != _tableView){
        [UIView animateWithDuration:0.2 animations:^{
            self.alpha = 0.0;
        } completion:^(BOOL finished) {
            [self removeFromSuperview];
        }];
    }
}


- (void)setShutterMode:(VideoCameraMode)shutterMode{
    
    
    if(shutterMode == kVideoCameraModeVideo){
        
        self.functionItems = [NSMutableArray arrayWithArray:@[@{@"title":LocalString(@"视频更多")},
                                                              @{@"title":LocalString(@"画幅"),@"selectType":@[@"916",@"169",@"11"]},
                                                              @{@"title":LocalString(@"闪光灯"),@"selectType":@[LocalString(@"开启"),LocalString(@"关闭")]},
                                                              @{@"title":LocalString(@"时长"),@"selectType":@[@"60",@"30",@"10"]},
                                                              ]];
        _tableView.frame = CGRectMake(15 * 1,5 * 1,CGRectGetWidth(_backgroundView.frame) - 30 * 1, _cellHeight * self.functionItems.count);
        _backgroundView.frame = CGRectMake(10 * 1,50 + 20 * 1,SCREEN_WIDTH - 20 * 1, (hasFlash ? 3:2) * _cellHeight + 60 * 1);
    }
    else{
        
        self.functionItems = [NSMutableArray arrayWithArray:@[@{@"title":LocalString(@"视频更多")},
                                                              @{@"title":LocalString(@"画幅"),@"selectType":@[@"916",@"43",@"11"]},
                                                              @{@"title":LocalString(@"闪光灯"),@"selectType":@[LocalString(@"自动"),LocalString(@"开启"),LocalString(@"关闭")]},
                                                              @{@"title":LocalString(@"倒计时"),@"selectType":@[@"10",@"3",LocalString(@"关闭")]},
                                                              @{@"title":LocalString(@"触屏拍照"),@"selectType":@[LocalString(@"开启"),LocalString(@"关闭")]}]];
    }
    
    hasFlash = [self.delegate videoSettingHasFlash];
    if (!hasFlash) {
        [self.functionItems removeObjectAtIndex:2]; // 删掉闪光灯
    }
    
    _shutterMode = shutterMode;
    [self configData];
}


- (VideoCameraViewFlashMode)exchangeFlashTypeWithString:(NSString *)flashString{
    
    VideoCameraViewFlashMode flashType = kVideoCameraViewFlashModeAuto;
    if([flashString isEqualToString:LocalString(@"开启")]){
        
        flashType = kVideoCameraViewFlashModeEnabled;
        
    }else if([flashString isEqualToString:LocalString(@"关闭")]){
        
        flashType = kVideoCameraViewFlashModeDisenabled;
    }
    else{
        flashType = kVideoCameraViewFlashModeAuto;
    }
    
    return flashType;
}

- (VideoCameraPreviewCrop)viewScaleWithString:(NSString *)scaleString{
    
    VideoCameraPreviewCrop scaleType = kVideoCameraPreviewCrop4To3;
    if([scaleString isEqualToString:@"916"]){
        
        scaleType = kVideoCameraPreviewCrop16To9;
        
    }else if([scaleString isEqualToString:@"11"]){
        
        scaleType = kVideoCameraPreviewCrop1To1;
    }
    else if([scaleString isEqualToString:@"43"]){
        
        scaleType = kVideoCameraPreviewCrop4To3;
    }
    else if([scaleString isEqualToString:@"169"]){
        
        scaleType = kVideoCameraPreviewCrop235To1;
    }

    return scaleType;
}


@end
