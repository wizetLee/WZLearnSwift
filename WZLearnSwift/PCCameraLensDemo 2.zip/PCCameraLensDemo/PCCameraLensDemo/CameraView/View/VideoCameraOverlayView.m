//
//  VideoCameraOverlayView.m
//  POCONewCamera
//
//  Created by 陈弢 on 2017/6/6.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import "VideoCameraOverlayView.h"
#import "VideoCameraSettingView.h"
//#import "ProgressCircleView.h"
//#import "CameraCourseView.h"
//#import "MPVolumeObserver.h"

static CGFloat VideoFilterViewHeight = 87.5 + (20.0 + 40.0) / 2.0; // 滤镜view高度
static const NSInteger kCameraViewMaxExposurePointerFlickerCount = 2;
static const NSInteger MicroPhoneAuthorityAlertView = 233;
static NSString *const AppMicroPhontUrl = @"App-Prefs:root=Privacy&path=MICROPHONE";

@interface VideoCameraOverlayView ()<INPVideoCameraFilterViewDelegate,CameraCourseViewDelegate, BeautyAlertViewDelegate>{

}

@property (nonatomic,strong)UIButton *homeBtn;
@property (nonatomic,strong)UIButton *exchangeBtn;//切换前置后置镜头
@property (nonatomic,strong)UIButton *tutorialBtn;//教程
@property (nonatomic,strong)UIButton *moreBtn;
@property (nonatomic,strong)UIButton *filterBtn;
@property (nonatomic,strong)UIButton *filterBtnCover;
@property (nonatomic,strong)UIButton *changeShotModeBtn;//视频/拍照
@property (nonatomic,strong)UIButton *shutterBtn;//快门
@property (nonatomic,strong)ProgressCircleView *recordCircleView;
@property (nonatomic,strong)UIView *topbar;
@property (nonatomic,strong)UIView *bottomBar;
@property (nonatomic,strong)VideoCameraSettingView *settingView;
@property (nonatomic,strong)UIView *perView;
@property (nonatomic,strong)NSTimer *recordTimer;
@property (nonatomic,strong)NSTimer *recordProgressTimer;
@property (nonatomic,strong)UILabel *progressLabel;
//@property (nonatomic, strong) UILabel *showFilterNameLabel;
@property (nonatomic,assign)float recordProgress;
@property (nonatomic,strong)INPVideoCameraFilterView *videoFilterView; // 印象滤镜View

@property (nonatomic, strong) CameraCourseView *courseView;

@property (nonatomic, assign) BOOL isUsingCourseView;
@property (nonatomic, assign) CGFloat preScale;
@property (nonatomic, assign) CGFloat nowScale;

@property (nonatomic, assign) VideoCameraViewOrientationMode videoCameraOrientationMode;

// 手势
@property (nonatomic, strong) UIPanGestureRecognizer *panGesture;
@property (nonatomic, strong) UITapGestureRecognizer *tapGesture;
@property (nonatomic, strong) UIPinchGestureRecognizer *pinchGesture;
// 曝光点和聚焦点的pan手势
@property (nonatomic, strong) UIPanGestureRecognizer *focusPanGesture;
@property (nonatomic, strong) UIPanGestureRecognizer *exposurePanGesture;

// 曝光、聚焦
@property (nonatomic, strong) UIImageView *nnewExprosureImgView;
@property (nonatomic, strong) UIImageView *nnewFocusImgView;
@property (nonatomic, assign) int flickerCount;

// 移动手势
@property (nonatomic, assign) VideoCameraPanAnimationDirection animationDirection;
@property (nonatomic, assign) BOOL isSwitchingFilter; // 标记用，当正在切换时，禁止相应的手势

// 滤镜参数记录
@property (nonatomic, strong) UIImage *nextFilterThumbnailImage;
@property (nonatomic, strong) NSArray *nextFilterCoverColorArray;
@property (nonatomic, copy) NSString *nextFilterColorId;

@property (nonatomic, assign) BOOL isRecordingVideo;

@property (nonatomic, assign) CFAbsoluteTime recordStartTime;
@property (nonatomic, assign) CFAbsoluteTime recordStopTime;

@property (nonatomic, strong) UIButton *cancelCourseViewBtnForIPad; // iPad用的用来取消构图的按钮

@end

@implementation VideoCameraOverlayView

- (instancetype)initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    self.recordProgress = 0;
    [self createGestureView];
    [self createTopbarBtn];
    [self createBottomBar];
    [self createFilterView];
    
    return self;
}

- (void)setDelegate:(id<VideoCameraOverlayDelegate>)delegate {
    _delegate = delegate;
    if ([[NSUserDefaults standardUserDefaults] objectForKey:@"123"]) {
        [self.videoFilterView selectColorFilterWithColorId:[[NSUserDefaults standardUserDefaults] objectForKey:@"123"]];
    }
}

- (void)setCameraType:(InterPhotoCameraOverlayType)cameraType {
    switch (cameraType) {
        case kInterPhotoCameraOverlayTypeNormal:
            self.cameraMode = kVideoCameraModeStillImage;
            break;
        case kInterPhotoCameraOverlayTypePhotoOnly:
            self.cameraMode = kVideoCameraModeStillImage;
            self.changeShotModeBtn.hidden = YES;
            self.albumImageView.hidden = YES;
            break;
        case kInterPhotoCameraOverlayTypeVideoOnly:
            self.cameraMode = kVideoCameraModeVideo;
            [self.shutterBtn setSelected:YES];
            self.changeShotModeBtn.hidden = YES;
            self.albumImageView.hidden = YES;
            break;
    }
}

#pragma mark - Public Method

- (void)shutterSendTouchUpInsideAction {
    if (self.isRecordingVideo) {
        [self stopRecord];
        return;
    }
    if (self.showFilter) {
        return;
    }
    if (!self.shutterBtn.hidden) {
        [self.shutterBtn sendActionsForControlEvents:UIControlEventTouchUpInside];
    }
//    else if (self.isRecordingVideo) {
//        [self stopRecord];
//    }
}

#pragma mark 设置手势Frame(响应范围)
- (void)adjustGestureViewFrameWithFrame:(CGRect)frame {
    _perView.frame = frame;
}

#pragma mark 设置设备方向
- (void)setCameraOverlayOrientation:(VideoCameraViewOrientationMode)orientationMode {
    self.videoCameraOrientationMode = orientationMode;
    switch (orientationMode) {
            // 暂时屏蔽了 swipe 手势
        case kVideoCameraViewOrientationModePortrait:
//            [self openSwipeGestureForProtrait];
            [self cameraOverLayViewsTransformWithAngle:0];
            break;
        case kVideoCameraViewOrientationModeLeft:
//            [self openSwipeGestureForLandscape];
            [self cameraOverLayViewsTransformWithAngle:M_PI_2];
            break;
        case kVideoCameraViewOrientationModeRight:
//            [self openSwipeGestureForLandscape];
            [self cameraOverLayViewsTransformWithAngle:-M_PI_2];
            break;
        case kVideoCameraViewOrientationModeUpSideDown:
//            [self openSwipeGestureForProtrait];
            [self cameraOverLayViewsTransformWithAngle:0];
            break;
    }
}

- (void)cameraOverLayViewsTransformWithAngle:(CGFloat)angle {
    [UIView animateWithDuration:0.2 animations:^{
        // topbar
        self.homeBtn.transform = CGAffineTransformMakeRotation(angle);
        self.exchangeBtn.transform = CGAffineTransformMakeRotation(angle);
        self.tutorialBtn.transform = CGAffineTransformMakeRotation(angle);
        self.moreBtn.transform = CGAffineTransformMakeRotation(angle);
        // bottomBar
        self.filterBtn.transform = CGAffineTransformMakeRotation(angle);
        self.filterBtnCover.transform = CGAffineTransformMakeRotation(angle);
        self.changeShotModeBtn.transform = CGAffineTransformMakeRotation(angle);
        self.albumImageView.transform = CGAffineTransformMakeRotation(angle);
        // filterNameLabel
//        self.showFilterNameLabel.transform = CGAffineTransformMakeRotation(angle);
    }];
}

#pragma mark - Private Method

- (void)startRecordVideo {
    self.recordStartTime = CFAbsoluteTimeGetCurrent();
    self.isRecordingVideo = YES;
    self.homeBtn.hidden = YES;
    self.exchangeBtn.hidden = YES;
    self.tutorialBtn.hidden = YES;
    self.moreBtn.hidden = YES;
    self.filterBtn.hidden = YES;
    self.filterBtnCover.hidden = YES;
    self.changeShotModeBtn.hidden = YES;
    self.topbar.hidden = YES;
    self.bottomBar.hidden = YES;
    self.albumImageView.hidden = YES;
    
    self.videoFilterView.userInteractionEnabled = NO;
    self.panGesture.enabled = NO;
}

- (void)stopRecordVideo {
    self.isRecordingVideo = NO;
    self.homeBtn.hidden = NO;
    self.exchangeBtn.hidden = NO;
    self.tutorialBtn.hidden = NO;
    self.moreBtn.hidden = NO;
    self.filterBtn.hidden = NO;
    self.filterBtnCover.hidden = NO;
    self.changeShotModeBtn.hidden = NO;
    self.topbar.hidden = NO;
    self.bottomBar.hidden = NO;
    self.albumImageView.hidden = NO;
    
    self.videoFilterView.userInteractionEnabled = YES;
    self.panGesture.enabled = YES;
}

- (void)cancelRecordVideo {
    [self stopRecordVideo];
    
    [self destroyTimer];
    [self destroyCircleView];
    self.shutterBtn.hidden = NO;
    self.shutterBtn.alpha = 1.0;
    self.shutterBtn.enabled = YES;
}

- (void)createGestureView{
    
    _perView = [[UIView alloc] initWithFrame:self.bounds];
    [self addSubview:_perView];
    _perView.clipsToBounds = YES;
    
    self.pinchGesture = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinchChangeGesture:)];
    self.pinchGesture.scale = 1;
    
    self.panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panChangeGesture:)];
    self.panGesture.minimumNumberOfTouches = 1;
    self.panGesture.maximumNumberOfTouches = 1;
    
    self.tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapChangeGesture:)];
    
    [_perView addGestureRecognizer:self.pinchGesture];
    [_perView addGestureRecognizer:self.panGesture];
    [_perView addGestureRecognizer:self.tapGesture];
    
    
    self.focusPanGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(focusPanChangeGesture:)];
    self.focusPanGesture.minimumNumberOfTouches = 1;
    self.focusPanGesture.maximumNumberOfTouches = 1;
    
    self.exposurePanGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(exposurePanChangeGesture:)];
    self.exposurePanGesture.minimumNumberOfTouches = 1;
    self.exposurePanGesture.maximumNumberOfTouches = 1;
    
    [self.nnewFocusImgView addGestureRecognizer:self.focusPanGesture];
    [self.nnewExprosureImgView addGestureRecognizer:self.exposurePanGesture];
    
    /*
#warning 暂时屏蔽上下左右滑动
    // 左滑右滑手势
    self.leftSwipeGesture = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(leftSwipe:)];
    self.leftSwipeGesture.direction = UISwipeGestureRecognizerDirectionLeft;
    [_perView addGestureRecognizer:self.leftSwipeGesture];
    
    self.rightSwipeGesture = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(rightSwipe:)];
    self.rightSwipeGesture.direction = UISwipeGestureRecognizerDirectionRight;
    [_perView addGestureRecognizer:self.rightSwipeGesture];
    
    self.upSwipeGesture = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(upSwipe:)];
    self.upSwipeGesture.direction = UISwipeGestureRecognizerDirectionUp;
    [_perView addGestureRecognizer:self.upSwipeGesture];
    
    self.downSwipeGesture = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(downSwipe:)];
    self.downSwipeGesture.direction = UISwipeGestureRecognizerDirectionDown;
    [_perView addGestureRecognizer:self.downSwipeGesture];
    */
}

- (void)createTopbarBtnAbandon{
    
    NSArray *imageArr = @[@"video_camera_backHome",@"video_camera_switchCamera",@"video_camera_tutorialDefault",@"video_camera_loadMore"];
    CGFloat padding = (CGRectGetWidth(self.frame) - [UIImage imageNamed:imageArr[0]].size.width * imageArr.count) / imageArr.count;
    
    _topbar = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 50 )];
    [self addSubview: _topbar];
    
    for(NSInteger i=0; i<imageArr.count; i++){
        
        UIImage *image = [UIImage imageNamed:imageArr[i]];
        UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(padding/2 + (image.size.width + padding) * i,0, image.size.width, image.size.height)];
        btn.center = CGPointMake(btn.center.x, 25);
        btn.tag = i;
        [btn setImage:image forState:UIControlStateNormal];
        [_topbar addSubview:btn];
        
        if(i == 2){
            [btn setImage:[UIImage imageNamed:@"video_camera_tutorialDisable"] forState:UIControlStateDisabled];
            [btn addTarget:self action:@selector(showTutorialView) forControlEvents:UIControlEventTouchUpInside];
            self.tutorialBtn = btn;
        } else if (i == 0){
            [btn addTarget:self action:@selector(backHome) forControlEvents:UIControlEventTouchUpInside];
            self.homeBtn = btn;
        } else if (i == 1){
            [btn addTarget:self action:@selector(exchangeCamera) forControlEvents:UIControlEventTouchUpInside];
            self.exchangeBtn = btn;
        } else if (i == 3){
            [btn addTarget:self action:@selector(showMoreFunction) forControlEvents:UIControlEventTouchUpInside];
            self.moreBtn = btn;
            
        }
    }
}

- (void)createTopbarBtn {
    NSArray *imageArr = @[@"video_camera_backHome@2x",@"video_camera_switchCamera@2x",@"video_camera_tutorialDefault@2x",@"video_camera_loadMore@2x"];
    
    _topbar = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 50 )];
    [self addSubview: _topbar];
    
    CGFloat btnWidth = CGRectGetWidth(self.frame)/imageArr.count;
    for (int i = 0; i<imageArr.count; i++) {
        UIImage *image = [UIImage imageNamed:imageArr[i]];
        UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(i*btnWidth, 0, btnWidth, 50)];
        btn.tag = i;
        [btn setImage:image forState:UIControlStateNormal];
        [_topbar addSubview:btn];
        
        if(i == 2){
            [btn setImage:[UIImage imageNamed:@"video_camera_tutorialDisable@2x"] forState:UIControlStateDisabled];
            [btn addTarget:self action:@selector(showTutorialView) forControlEvents:UIControlEventTouchUpInside];
            self.tutorialBtn = btn;
        } else if (i == 0){
            [btn addTarget:self action:@selector(backHome) forControlEvents:UIControlEventTouchUpInside];
            self.homeBtn = btn;
        } else if (i == 1){
            [btn addTarget:self action:@selector(exchangeCamera) forControlEvents:UIControlEventTouchUpInside];
            self.exchangeBtn = btn;
        } else if (i == 3){
            [btn addTarget:self action:@selector(showMoreFunction) forControlEvents:UIControlEventTouchUpInside];
            self.moreBtn = btn;
        }
    }
}

- (void)createBottomBar{
    
    UIImage *filterImg = [UIImage imageNamed:@"video_camera_filterButton"];
    UIImage *cameraModeImg = [UIImage imageNamed:@"video_camera_videoMode"];
    UIImage *camerShutterImg = [UIImage imageNamed:@"cameraShutterBtn"];
    UIImage *videoShutterImg = [UIImage imageNamed:@"videoShutterBtn"];
    UIImage *albumImg = [UIImage imageNamed:@"cameraAlbumEntry"];
    
    CGFloat filterBtnX = 25 * SCREEN_WIDTH / 375;
    CGFloat changeModeBtnX = 15 * SCREEN_WIDTH / 375;
    
    CGFloat sizeLength = 50 * SCREEN_WIDTH / 375;
    if (sizeLength > 50) {
        sizeLength = 50;
    }
    
    CGSize shutterBtnSize = camerShutterImg.size;
    if(SCREEN_WIDTH <= 321){
        
        shutterBtnSize = CGSizeMake(shutterBtnSize.width * WIDTH_375_RATE, shutterBtnSize.height * WIDTH_375_RATE);
    }
    
    CGFloat bottomBarHeight = 117.0 / 667.0 * SCREEN_HEIGHT;
    bottomBarHeight = bottomBarHeight > 117.0 ? 117.0 : bottomBarHeight;
    
    _bottomBar = [[UIView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT - bottomBarHeight, SCREEN_WIDTH, bottomBarHeight)];
    [self addSubview:_bottomBar];
    
    _filterBtn = [[UIButton alloc] initWithFrame:CGRectMake(filterBtnX, 0, sizeLength, sizeLength)];
    _filterBtn.center = CGPointMake(self.filterBtn.center.x, CGRectGetHeight(_bottomBar.frame)/2);
    _filterBtn.layer.cornerRadius = 6.0;
    [_filterBtn.layer setMasksToBounds:YES];
    [_filterBtn setImage:filterImg forState:UIControlStateNormal];
    //    [_filterBtn addTarget:self action:@selector(showFilterSelectView) forControlEvents:UIControlEventTouchUpInside];
    [_bottomBar addSubview:_filterBtn];
    
    _filterBtnCover = [[UIButton alloc] initWithFrame:CGRectMake(filterBtnX, 0, sizeLength, sizeLength)];
    _filterBtnCover.center = CGPointMake(self.filterBtn.center.x, CGRectGetHeight(_bottomBar.frame)/2);
    _filterBtnCover.layer.cornerRadius = 6.0;
    [_filterBtnCover.layer setMasksToBounds:YES];
    //    [_filterBtnCover setImage:filterImg forState:UIControlStateNormal];
    [_filterBtnCover addTarget:self action:@selector(showFilterSelectView) forControlEvents:UIControlEventTouchUpInside];
    [_bottomBar addSubview:_filterBtnCover];
    
    _changeShotModeBtn = [[UIButton alloc] initWithFrame:CGRectMake(CGRectGetMaxX(_filterBtn.frame) + changeModeBtnX,
                                                                    CGRectGetMinY(_filterBtn.frame),
                                                                    sizeLength,
                                                                    sizeLength)];
    [_changeShotModeBtn setImage:cameraModeImg forState:UIControlStateNormal];
//    [_changeShotModeBtn setImage:videoModeImg forState:UIControlStateSelected];
    [_changeShotModeBtn addTarget:self action:@selector(changeCameraVideoMode:) forControlEvents:UIControlEventTouchUpInside];
    [_bottomBar addSubview:_changeShotModeBtn];
    
    _shutterBtn = [[UIButton alloc] initWithFrame:CGRectMake(0,0, shutterBtnSize.width, shutterBtnSize.height)];
    _shutterBtn.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT - CGRectGetHeight(_bottomBar.frame)/2);
    [_shutterBtn setImage:camerShutterImg forState:UIControlStateNormal];
    [_shutterBtn setImage:videoShutterImg forState:UIControlStateSelected];
    [_shutterBtn addTarget:self action:@selector(pressedShutter) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_shutterBtn];
    
//    CGFloat albumImageViewSize = 50 * SCREEN_WIDTH / 375;
    _albumImageView = [[UIImageView alloc] initWithFrame:CGRectMake(SCREEN_WIDTH - filterBtnX - sizeLength, 0, sizeLength, sizeLength)];
    _albumImageView.center = CGPointMake(_albumImageView.center.x, CGRectGetHeight(_bottomBar.frame)/2);
    _albumImageView.userInteractionEnabled = YES;
    _albumImageView.clipsToBounds = YES;
    _albumImageView.contentMode = UIViewContentModeScaleAspectFill;
    _albumImageView.backgroundColor = COLOR_RGB_255(51, 51, 51);
    _albumImageView.image = albumImg;
    [_bottomBar addSubview:_albumImageView];
    
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(gotoAlbumView)];
    [_albumImageView addGestureRecognizer:tap];
    
}

- (void)createCircleBtn{
    
    [self destroyCircleView];
    
    CGRect circleFrame = _shutterBtn.frame;
    circleFrame.size.width -= 6;
    circleFrame.size.height -= 6;
    self.recordCircleView = [[ProgressCircleView alloc] initWithFrame:circleFrame percent:0.05 color:COLOR_RGB_255(255, 0, 0) clockwise:YES];
    self.recordCircleView.lineWidth = 7;
    self.recordCircleView.center = _shutterBtn.center;
//    self.recordCircleView.circleBgColor = COLOR_RGB_255(51, 51, 51);
//    self.recordCircleView.circleBgColor = [UIColor clearColor];
    self.recordCircleView.circleBgColor = COLOR_RGBA_255(255, 255, 255, 0.6);
    self.recordCircleView.isShowCircleBg = YES;
    self.recordCircleView.userInteractionEnabled = YES;
    [self addSubview:self.recordCircleView];
    [self.recordCircleView reloadViewWithPercent:0.01];
    
    self.recordCircleView.transform = self.exchangeBtn.transform;
    
    UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(stopRecord)];
    [_recordCircleView addGestureRecognizer:tap1];
    
    CGRect labelFrame = _shutterBtn.frame;
    labelFrame.size.width -= 15;
    labelFrame.size.height -= 15;
    _progressLabel = [[UILabel alloc] initWithFrame:labelFrame];
    _progressLabel.center = CGPointMake(CGRectGetWidth(circleFrame)/2, CGRectGetHeight(circleFrame)/2);
    _progressLabel.textColor = [UIColor whiteColor];
    _progressLabel.font = [UIFont systemFontOfSize:15];
    _progressLabel.textAlignment = NSTextAlignmentCenter;
    _progressLabel.backgroundColor = [UIColor clearColor];
    _progressLabel.layer.cornerRadius = CGRectGetWidth(labelFrame)/2;
    _progressLabel.clipsToBounds = YES;
    _progressLabel.text = 0;
    [_recordCircleView addSubview:_progressLabel];
}

- (void)destroyCircleView{
    self.recordProgress = 0;
    if(self.recordCircleView){
        if(self.recordCircleView.superview){
            [self.recordCircleView removeFromSuperview];
        }
        self.recordCircleView = nil;
    }
}

#pragma mark 返回首页
- (void)backHome{
    if([self.delegate respondsToSelector:@selector(shouldBcakHome)]){
        [self.delegate shouldBcakHome];
    }
}

#pragma mark 印象滤镜视图

- (void)createFilterView {
    [self addSubview:self.videoFilterView];
}

#pragma mark - VideoFilterView Delegate

- (void)videoCameraVideoFilterViewDidChangeFilter:(OIFilter *)filter {
    if ([self.delegate respondsToSelector:@selector(didChooseINPFilter:)]) {
        [self.delegate didChooseINPFilter:filter];
    }
    [self changeFilterCoverImageToNextFilter];
}

- (void)videoCameraVideoFilterViewDidChangeNextFilter:(OIFilter *)filter withOrder:(BOOL)nextOrder {
//    if ([self.delegate respondsToSelector:@selector(didChooseNextINPFilter:withOrder:)]) {
//        [self.delegate didChooseNextINPFilter:filter withOrder:nextOrder];
//    }
}

- (void)videoCameraVideoLeave {
    
    if ([self.videoFilterView alphaAdjusting]) {
        [self.videoFilterView enterAlphaAdjusting];
//        return;
    }
    self.showFilter = NO;
    [self shutterBtnMoveUp:NO];
    [UIView animateWithDuration:0.2 animations:^{
        self.videoFilterView.transform = CGAffineTransformIdentity;
    }];
}

- (void)videoCameraVideoFilterGetThumbnailImage:(UIImage *)thumbnail andCoverColor:(NSArray *)coverColor colorId:(NSString *)colorId {
    self.nextFilterThumbnailImage = thumbnail;
    self.nextFilterCoverColorArray = coverColor;
    self.nextFilterColorId = colorId;
}

- (void)changeFilterCoverImageToNextFilter {
    [_filterBtn setBackgroundImage:self.nextFilterThumbnailImage forState:UIControlStateNormal];
    self.selectedColorId = self.nextFilterColorId;
    // 设置user default
    [[NSUserDefaults standardUserDefaults] setObject:self.nextFilterColorId forKey:kCameraDefaultFilterColorId];
    [UIView transitionWithView:self.filterBtn
                      duration:0.4f
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    animations:^{
                        [_filterBtn setBackgroundImage:self.nextFilterThumbnailImage forState:UIControlStateNormal];
                    } completion:nil];
    
    _filterBtnCover.backgroundColor = self.nextFilterCoverColorArray ? COLOR_RGBA_255([self.nextFilterCoverColorArray[0]intValue],
                                                                                      [self.nextFilterCoverColorArray[1]intValue],
                                                                                      [self.nextFilterCoverColorArray[2]intValue], 0.5) : [UIColor clearColor];
}

// 滤镜界面
- (INPVideoCameraFilterView *)videoFilterView {
    if (!_videoFilterView) {
        _videoFilterView = [[INPVideoCameraFilterView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, VideoFilterViewHeight * 1)];
        _videoFilterView.delegate = self;
        _videoFilterView.openMultipeFilterSwitchingEffect = YES;
    }
    return _videoFilterView;
}



#pragma mark 更多
- (void)showMoreFunction{
    if (self.isSwitchingFilter) {
        return;
    }
    if (self.showFilter) {
        [self videoCameraVideoLeave];
    }
    if([self.delegate respondsToSelector:@selector(shouldShowSettingViewWithMode:)]){
        [self.delegate shouldShowSettingViewWithMode:self.cameraMode];
    }
}

#pragma mark 教程
- (void)showTutorialView{
    if (self.showFilter) {
        [self videoCameraVideoLeave];
    }
    if (self.courseView != nil) {
        [self.courseView revocerCourseView];
        [self sendSubviewToBack:self.bottomBar];
    } else {
        if (!self.courseView) {
            self.courseView = [[CameraCourseView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
            self.courseView.delegate = self;
        }
        self.courseView.userInteractionEnabled = NO;
        [self addSubview:self.courseView];
        
        [UIView animateWithDuration:0.3 animations:^{
            self.courseView.frame = SCREEN_FRAME;
        } completion:^(BOOL finished) {
            self.courseView.userInteractionEnabled = YES;
        }];
        
    }
    [self bringSubviewToFront:self.courseView];
}

#pragma mark 切换镜头
- (void)exchangeCamera{
    if (self.showFilter) {
        [self videoCameraVideoLeave];
    }
    if(self.cameraPosition == kVideoCameraPositionBack){
        self.cameraPosition = kVideoCameraPositionFront;
    } else {
        self.cameraPosition = kVideoCameraPositionBack;
    }
    if([self.delegate respondsToSelector:@selector(shouldExchangeCameraPosition:)]){
        [self.delegate shouldExchangeCameraPosition:self.cameraPosition];
    }
}

#pragma mark 显示滤镜
- (void)showFilterSelectView {
    if (self.isSwitchingFilter) {
        return;
    }
    
    self.showFilter = YES;
    [self shutterBtnMoveUp:YES];
    if (self.showFilter) {
        [UIView animateWithDuration:0.2 animations:^{
            self.videoFilterView.transform = CGAffineTransformMakeTranslation(0, -VideoFilterViewHeight * 1);
        }];
    }
}

#pragma mark 快门动画

- (void)shutterBtnMoveUp:(BOOL)move {
    [UIView animateWithDuration:0.2 animations:^{
        if (move) {
            _shutterBtn.frame = CGRectMake(0, 0, 80.0/2.0, 80/2.0);
            _shutterBtn.center = CGPointMake(SCREEN_WIDTH/2.0, SCREEN_HEIGHT-(VideoFilterViewHeight+(20+80)/2/2)*1);
        } else {
            _shutterBtn.frame = CGRectMake(0,0, 134.0/2.0, 134.0/2.0);
            _shutterBtn.center = CGPointMake(SCREEN_WIDTH/2, SCREEN_HEIGHT - CGRectGetHeight(_bottomBar.frame)/2);
        }
    }];
}

#pragma mark - 曝光点、聚焦点
#pragma mark - Exposure&FocusPoint

- (void)adjustCameraFocusExposurePoint {
    [self adjustCameraFocusPoint];
    [self adjustCameraExposurePoint];
}

- (void)adjustCameraFocusPoint {
    if ([self.delegate respondsToSelector:@selector(changeFocusCenterPoint:)]) {
        [self.delegate changeFocusCenterPoint:self.nnewFocusImgView.center];
    }
}

- (void)adjustCameraExposurePoint {
    if ([self.delegate respondsToSelector:@selector(changeExposureCenterPoint:)]) {
        [self.delegate changeExposureCenterPoint:self.nnewExprosureImgView.center];
    }
}

/*!
 触摸屏幕移动聚焦和曝光点
 */
- (void)moveExposurePointerToPoint:(CGPoint)point {
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(flickerExposurePointer) object:nil];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(highlightExposurePointer) object:nil];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(darkenExposurePointer) object:nil];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(hideExposurePointer) object:nil];
    
    CGAffineTransform transform = CGAffineTransformMakeTranslation(0, 0);
    self.nnewExprosureImgView.transform = CGAffineTransformScale(transform, 1.5, 1.5);
    self.nnewFocusImgView.transform = CGAffineTransformScale(transform, 1.5, 1.5);
    
    self.nnewExprosureImgView.alpha = 1.0;
    self.nnewFocusImgView.alpha = 1.0;
    
    [UIView beginAnimations:@"MoveExposurePointerToPoint" context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    self.nnewExprosureImgView.transform = CGAffineTransformIdentity;
    self.nnewFocusImgView.transform = CGAffineTransformIdentity;
    
    self.nnewExprosureImgView.center = point;
    self.nnewFocusImgView.center = point;
    
    [UIView commitAnimations];
    [self adjustCameraFocusExposurePoint];
    [self performSelector:@selector(flickerExposurePointer) withObject:nil afterDelay:0.3];
}

- (void)tapExposurePointerToPoint {
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(flickerExposurePointer) object:nil];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(highlightExposurePointer) object:nil];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(darkenExposurePointer) object:nil];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(hideExposurePointer) object:nil];
    
    CGAffineTransform transform = CGAffineTransformMakeTranslation(0, 0);
    self.nnewExprosureImgView.transform = CGAffineTransformScale(transform, 1.5, 1.5);
    self.nnewFocusImgView.transform = CGAffineTransformScale(transform, 1.5, 1.5);
    
    self.nnewExprosureImgView.alpha = 1.0;
    self.nnewFocusImgView.alpha = 1.0;
    
    [UIView beginAnimations:@"MoveExposurePointerToPoint" context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    self.nnewExprosureImgView.transform = CGAffineTransformIdentity;
    self.nnewFocusImgView.transform = CGAffineTransformIdentity;
    
//    self.nnewExprosureImgView.center = point;
//    self.nnewFocusImgView.center = point;
    
    [UIView commitAnimations];
    [self adjustCameraFocusExposurePoint];
    [self performSelector:@selector(flickerExposurePointer) withObject:nil afterDelay:0.3];
}

- (void)panExposurePointerToPoint:(CGPoint)point {
    
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(flickerExposurePointer) object:nil];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(highlightExposurePointer) object:nil];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(darkenExposurePointer) object:nil];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(hideExposurePointer) object:nil];
    
    self.nnewFocusImgView.alpha = 1.0;
    self.nnewExprosureImgView.alpha = 1.0;
    
    [UIView beginAnimations:@"MoveExposurePointerToPoint" context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    self.nnewExprosureImgView.transform = CGAffineTransformIdentity;
    
    self.nnewExprosureImgView.center = point;
    
    [UIView commitAnimations];
//    [self adjustCameraFocusExposurePoint];
    [self adjustCameraExposurePoint];
    [self performSelector:@selector(adjustCameraExposurePoint) withObject:nil afterDelay:0.5 ];
}

- (void)panFocusPointerToPoint:(CGPoint)point {
    
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(flickerExposurePointer) object:nil];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(highlightExposurePointer) object:nil];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(darkenExposurePointer) object:nil];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(hideExposurePointer) object:nil];
    
    self.nnewFocusImgView.alpha = 1.0;
    self.nnewExprosureImgView.alpha = 1.0;
    
    [UIView beginAnimations:@"MoveExposurePointerToPoint" context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    self.nnewFocusImgView.transform = CGAffineTransformIdentity;
    
    self.nnewFocusImgView.center = point;
    
    [UIView commitAnimations];
//    [self adjustCameraFocusExposurePoint];
    [self adjustCameraFocusPoint];
    [self performSelector:@selector(adjustCameraFocusPoint) withObject:nil afterDelay:0.5 ];
}


- (void)flickerExposurePointer {
    self.flickerCount = 0;
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(highlightExposurePointer) object:nil];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(darkenExposurePointer) object:nil];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(hideExposurePointer) object:nil];
    
    [self darkenExposurePointer];
}

- (void)darkenExposurePointer {
    [UIView beginAnimations:@"DarkenExposurePointer" context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    self.nnewExprosureImgView.alpha = 0.2;
    self.nnewFocusImgView.alpha = 0.2;
    
    [UIView commitAnimations];
    
    [self performSelector:@selector(highlightExposurePointer) withObject:nil afterDelay:0.2];
}

- (void)highlightExposurePointer {
    [UIView beginAnimations:@"HighlightExposurePointer" context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    self.nnewExprosureImgView.alpha = 1.0;
    self.nnewFocusImgView.alpha = 1.0;
    
    [UIView commitAnimations];
    
    if (++self.flickerCount < kCameraViewMaxExposurePointerFlickerCount) {
        [self performSelector:@selector(darkenExposurePointer) withObject:nil afterDelay:0.3];
    }
    else {
        [self performSelector:@selector(hideExposurePointer) withObject:nil afterDelay:0.4];
    }
}

- (void)hideExposurePointer {
    [UIView beginAnimations:@"HideExposurePointer" context:nil];
    [UIView setAnimationBeginsFromCurrentState:YES];
    self.nnewExprosureImgView.alpha = 0.0;
    self.nnewFocusImgView.alpha = 0.0;
    
    [UIView commitAnimations];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"CameraViewPanGestureEnabledNo" object:nil ];
}

#pragma mark 切换镜头、视频
- (void)changeCameraVideoMode:(UIButton *)button {
    if (self.isSwitchingFilter) {
        return;
    }
    
    // 判断授权
    if (self.cameraMode == kVideoCameraModeStillImage) {
        AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeAudio];
        if(authStatus != AVAuthorizationStatusAuthorized){
            NSString *errorStr = LocalString(@"尚未授权获取麦克风权限，授权后继续录像");
            BeautyAlertView *alert = [[BeautyAlertView alloc] initWithTitle:LocalString(@"提示") message:errorStr delegate:self cancelButtonTitle:LocalString(@"取消") otherButtonTitles:LocalString(@"去授权"), nil];
            alert.cancelBtnColor = [UIColor whiteColor];
            alert.tag = MicroPhoneAuthorityAlertView;
            [alert show];
            // 弹出提醒
            return;
        }
    }
    
    // 这里原来是为了切换模式时禁止监听音量键的，但是会导致切换变慢，暂时注释
//    [MPVolumeObserver sharedInstance].delegate = nil;
//    [[MPVolumeObserver sharedInstance] stopObserveVolumeChangeEvents];
    
    if(self.cameraMode == kVideoCameraModeVideo){
        [button setImage:[UIImage imageNamed:@"video_camera_videoMode"] forState:UIControlStateNormal];
        self.cameraMode = kVideoCameraModeStillImage;
        self.tutorialBtn.enabled = YES;
        [self.changeShotModeBtn setSelected:NO];
        [self.shutterBtn setSelected:NO];
    } else {
        [button setImage:[UIImage imageNamed:@"video_camera_cameraMode"] forState:UIControlStateNormal];
        self.cameraMode = kVideoCameraModeVideo;
        self.tutorialBtn.enabled = NO;
        [self.changeShotModeBtn setSelected:YES];
        [self.shutterBtn setSelected:YES];
        
    }
    if([self.delegate respondsToSelector:@selector(shouldExchangeCameraMode:)]){
        [self.delegate shouldExchangeCameraMode:self.cameraMode];
    }
    
}

- (void)beautyAlertView:(BeautyAlertView *)alertView clickedButtonAtIndex:(NSInteger)index {
    if (alertView.tag == MicroPhoneAuthorityAlertView && index == 1) {
        if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:AppMicroPhontUrl]]) {
            if ([[UIDevice currentDevice].systemVersion doubleValue] >= 10.0) {
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:AppMicroPhontUrl] options:@{} completionHandler:nil];
            } else {
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:AppMicroPhontUrl]];
            }  
        }
    }
}

#pragma mark 点击快门
- (void)pressedShutter{
    if (self.isSwitchingFilter) {
        return;
    }
    
    if (self.showFilter) {
        [self videoCameraVideoLeave];
    }
    
    if([self.delegate respondsToSelector:@selector(pressedShutterWithMode:)]){
        [self.delegate pressedShutterWithMode:self.cameraMode];
    }
    if(self.cameraMode == kVideoCameraModeVideo){
        self.shutterBtn.hidden = YES;
        self.shutterBtn.enabled = NO;
        [UIView animateWithDuration:0.2 animations:^{
            self.shutterBtn.alpha = 0.0;
        }];
        
        [self createCircleBtn];
        [self createTimer];            
    }
}

- (void)stopRecord {
    self.recordStopTime = CFAbsoluteTimeGetCurrent();
    NSString *backURL = [BSObject shareInstant].currentModel.backURL;
    
    if ([backURL containsString:@"circle20160324"]) {
        if (self.recordStopTime - self.recordStartTime < 2.0) {
            return;
        }
    } else {
        if (self.recordStopTime - self.recordStartTime < 1.0) {
            return;
        }
    }
    
    [self destroyTimer];
    [self destroyCircleView];
    if([self.delegate respondsToSelector:@selector(pressedShutterWithMode:)]){
        [self.delegate pressedShutterWithMode:self.cameraMode];
    }
    self.shutterBtn.hidden = NO;
    [UIView animateWithDuration:0.2 animations:^{
        self.shutterBtn.alpha = 1.0;
    } completion:^(BOOL finished) {
        self.shutterBtn.enabled = YES;
    }];
}

#pragma mark 跳转相册列表
- (void)gotoAlbumView{
    if([self.delegate respondsToSelector:@selector(shouldShouldAlbumViewWithMode:)]){
        [self.delegate shouldShouldAlbumViewWithMode:self.cameraMode];
    }
}

#pragma mark 移动手势
- (void)panChangeGesture:(UIPanGestureRecognizer *)gesture {
    if (self.showFilter) {
        [self videoCameraVideoLeave];
    }
    
    CGPoint translationPoint = [gesture translationInView:gesture.view];

    CGFloat translationPercent = 0;
    CGFloat velocity = 0;
    
    switch (self.animationDirection) {
        case kVideoCameraPanAnimationPortraitDirectionRight:
            translationPercent = translationPoint.x / SCREEN_WIDTH < 0 ? translationPoint.x / SCREEN_WIDTH : 0;
            break;
        case kVideoCameraPanAnimationPortraitDirectionLeft:
            translationPercent = translationPoint.x / SCREEN_WIDTH > 0 ? translationPoint.x / SCREEN_WIDTH : 0;
            break;
        case kVideoCameraPanAnimationLandscapeLeftDirectionRight:
            translationPercent = translationPoint.y / SCREEN_HEIGHT * 2 < 0 ? translationPoint.y / SCREEN_HEIGHT * 2 : 0;
            break;
        case kVideoCameraPanAnimationLandscapeLeftDirectionLeft:
            translationPercent = translationPoint.y / SCREEN_HEIGHT * 2 > 0 ? translationPoint.y / SCREEN_HEIGHT * 2 : 0;
            break;
        case kVideoCameraPanAnimationLandscapeRightDirectionLeft:
            translationPercent = translationPoint.y / SCREEN_HEIGHT * 2 < 0 ? translationPoint.y / SCREEN_HEIGHT * 2 : 0;
            break;
        case kVideoCameraPanAnimationLandscapeRightDirectionRight:
            translationPercent = translationPoint.y / SCREEN_HEIGHT * 2 > 0 ? translationPoint.y / SCREEN_HEIGHT * 2 : 0;
            break;
        default:
            break;
    }
    
    switch (gesture.state) {
        case UIGestureRecognizerStateBegan: {
            self.isSwitchingFilter = YES;
            switch (self.videoCameraOrientationMode) {
                case kVideoCameraViewOrientationModePortrait:{
                    velocity = [gesture velocityInView:gesture.view].x;
                    if (velocity > 0) {
                        [self videoFilterViewSelectPreIndexPath];
                        [self.delegate didChooseNextINPFilter:self.videoFilterView.currentFilter withOrder:NO];
                        self.animationDirection = kVideoCameraPanAnimationPortraitDirectionLeft;
                    } else {
                        [self videoFilterViewSelectNextIndexPath];
                        [self.delegate didChooseNextINPFilter:self.videoFilterView.currentFilter withOrder:YES];
                        self.animationDirection = kVideoCameraPanAnimationPortraitDirectionRight;
                    }
                }
                    break;
                case kVideoCameraViewOrientationModeLeft:{
                    velocity = [gesture velocityInView:gesture.view].y;
                    if (velocity > 0) {
                        [self videoFilterViewSelectPreIndexPath];
                        [self.delegate didChooseNextINPFilter:self.videoFilterView.currentFilter withOrder:NO];
                        self.animationDirection = kVideoCameraPanAnimationLandscapeLeftDirectionLeft;
                    } else {
                        [self videoFilterViewSelectNextIndexPath];
                        [self.delegate didChooseNextINPFilter:self.videoFilterView.currentFilter withOrder:YES];
                        self.animationDirection = kVideoCameraPanAnimationLandscapeLeftDirectionRight;
                    }
                }
                    break;
                case kVideoCameraViewOrientationModeRight: {
                    velocity = [gesture velocityInView:gesture.view].y;
                    if (velocity < 0) {
                        [self videoFilterViewSelectPreIndexPath];
                        [self.delegate didChooseNextINPFilter:self.videoFilterView.currentFilter withOrder:NO];
                        self.animationDirection = kVideoCameraPanAnimationLandscapeRightDirectionLeft;
                    } else {
                        [self videoFilterViewSelectNextIndexPath];
                        [self.delegate didChooseNextINPFilter:self.videoFilterView.currentFilter withOrder:YES];
                        self.animationDirection = kVideoCameraPanAnimationLandscapeRightDirectionRight;
                    }
                }
                    break;
                case kVideoCameraViewOrientationModeUpSideDown:
                    velocity = [gesture velocityInView:gesture.view].x;
                    if (velocity > 0) {
                        [self videoFilterViewSelectPreIndexPath];
                        [self.delegate didChooseNextINPFilter:self.videoFilterView.currentFilter withOrder:NO];
                        self.animationDirection = kVideoCameraPanAnimationPortraitDirectionLeft;
                    } else {
                        [self videoFilterViewSelectNextIndexPath];
                        [self.delegate didChooseNextINPFilter:self.videoFilterView.currentFilter withOrder:YES];
                        self.animationDirection = kVideoCameraPanAnimationPortraitDirectionRight;
                    }
                    break;
                default:
                    break;
            }
            
        }
            break;
        case UIGestureRecognizerStateChanged: {
            
            // 根据手势变换传percent，进行控制
            if ([self.delegate respondsToSelector:@selector(didPanFilterWithPercent:)]) {
                [self.delegate didPanFilterWithPercent:ABS(translationPercent)];
            }
            
        }
            break;
        case UIGestureRecognizerStateEnded: {
            
            // 计算速度
            switch (self.videoCameraOrientationMode) {
                case kVideoCameraViewOrientationModePortrait:{
                    velocity = [gesture velocityInView:gesture.view].x;
                }
                    break;
                case kVideoCameraViewOrientationModeLeft:{
                    velocity = [gesture velocityInView:gesture.view].y;
                }
                    break;
                case kVideoCameraViewOrientationModeRight: {
                    velocity = [gesture velocityInView:gesture.view].y;
                }
                default:
                    velocity = [gesture velocityInView:gesture.view].x;
                    break;
            }
            
            // 判断速度
            if (self.animationDirection == kVideoCameraPanAnimationPortraitDirectionRight || self.animationDirection == kVideoCameraPanAnimationLandscapeLeftDirectionRight) {
                // 选择下一个
                if (ABS(velocity) > 400) {
                    // 如果速度足够大，则表示是某种力度推过去的
                    if (velocity > 0) {
                        // 向右
                        [self.delegate didEndFilterChoosingWithPercent:translationPercent resume:YES]; // 恢复(恢复后应该)
                        [self.videoFilterView currentIndexPathReduction]; // 恢复上一个
                    } else {
                        // 向左
                        [self.delegate didEndFilterChoosingWithPercent:translationPercent resume:NO]; // next
                    }
                    
                } else {
                    // 如果速度不够，则判断目前的中点位置
                    if (ABS(translationPercent) < 0.5) {
                        // 向右
                        [self.delegate didEndFilterChoosingWithPercent:translationPercent resume:YES]; // 恢复
                        [self.videoFilterView currentIndexPathReduction]; // 恢复上一个
                    } else {
                        // 向左
                        [self.delegate didEndFilterChoosingWithPercent:translationPercent resume:NO]; // next
                    }
                }
            } else if (self.animationDirection == kVideoCameraPanAnimationPortraitDirectionLeft || self.animationDirection == kVideoCameraPanAnimationLandscapeLeftDirectionLeft) {
                // 选择上一个
                if (ABS(velocity) > 400) {
                    // 如果速度足够大，则表示是某种力度推过去的
                    if (velocity < 0) {
                        // 向右
                        [self.delegate didEndFilterChoosingWithPercent:translationPercent resume:YES]; // 恢复
                        [self.videoFilterView currentIndexPathIncrease]; // 恢复回下一个
                    } else {
                        // 向左
                        [self.delegate didEndFilterChoosingWithPercent:translationPercent resume:NO]; // next
                    }
                    
                } else {
                    // 如果速度不够，则判断目前的中点位置
                    if (ABS(translationPercent) < 0.5) {
                        // 向右
                        [self.delegate didEndFilterChoosingWithPercent:translationPercent resume:YES]; // 恢复
                        [self.videoFilterView currentIndexPathIncrease]; // 恢复回下一个
                    } else {
                        // 向左
                        [self.delegate didEndFilterChoosingWithPercent:translationPercent resume:NO]; // next
                    }
                }
            } else if (self.animationDirection == kVideoCameraPanAnimationLandscapeRightDirectionLeft) {
                if (ABS(velocity) > 400) {
                    if (velocity > 0) {
                        [self.delegate didEndFilterChoosingWithPercent:translationPercent resume:YES]; // 恢复
                        [self.videoFilterView currentIndexPathIncrease]; // 恢复回下一个
                    } else{
                        [self.delegate didEndFilterChoosingWithPercent:translationPercent resume:NO]; // next
                    }
                } else {
                    if (ABS(translationPercent) < 0.5) {
                        // 向右
                        [self.delegate didEndFilterChoosingWithPercent:translationPercent resume:YES]; // 恢复
                        [self.videoFilterView currentIndexPathIncrease]; // 恢复回下一个
                    } else {
                        // 向左
                        [self.delegate didEndFilterChoosingWithPercent:translationPercent resume:NO]; // next
                    }
                }
            } else if (self.animationDirection == kVideoCameraPanAnimationLandscapeRightDirectionRight) {
                if (ABS(velocity) > 400) {
                    if (velocity < 0) {
                        [self.delegate didEndFilterChoosingWithPercent:translationPercent resume:YES]; // 恢复
                        [self.videoFilterView currentIndexPathIncrease]; // 恢复回下一个
                    } else{
                        [self.delegate didEndFilterChoosingWithPercent:translationPercent resume:NO]; // next
                    }
                } else {
                    if (ABS(translationPercent) < 0.5) {
                        // 向右
                        [self.delegate didEndFilterChoosingWithPercent:translationPercent resume:YES]; // 恢复
                        [self.videoFilterView currentIndexPathIncrease]; // 恢复回下一个
                    } else {
                        // 向左
                        [self.delegate didEndFilterChoosingWithPercent:translationPercent resume:NO]; // next
                    }
                }
            }
            
            self.isSwitchingFilter = NO;
            
        }
            break;
        case UIGestureRecognizerStateCancelled: {
            self.isSwitchingFilter = NO;
        }
        default:
            break;
    }
}

// 曝光点、聚焦点的pan手势
- (void)focusPanChangeGesture:(UIPanGestureRecognizer *)gesture {
    if (gesture.state == UIGestureRecognizerStateEnded) {
        [self tapExposurePointerToPoint];
    } else {
        CGPoint location = [gesture locationInView:_perView];
        [self panFocusPointerToPoint:location];
    }
}

- (void)exposurePanChangeGesture:(UIPanGestureRecognizer *)gesture {
    if (gesture.state == UIGestureRecognizerStateEnded) {
        [self tapExposurePointerToPoint];
    } else {
        CGPoint location = [gesture locationInView:_perView];
        [self panExposurePointerToPoint:location];
    }
}

#pragma mark 缩放手势
- (void)pinchChangeGesture:(UIPinchGestureRecognizer *)gesture{
    
    CGFloat scale = gesture.scale;
    
    if (_preScale == 0) {
        _preScale = 1.0;
        _nowScale = 1.0;
    }
    
    if (gesture.state == UIGestureRecognizerStateBegan) {
        _nowScale = 1;
    }else if (gesture.state == UIGestureRecognizerStateChanged){
        
        if (scale > 1) {
            _nowScale = _preScale + (scale -1);
        } else {
            _nowScale = _preScale + (scale -1) * 4;
        }
        
        if(_nowScale < 1){
            _nowScale = 1;
        }
        else if(_nowScale >= 4){
            _nowScale = 4;
        }
        
        // 传出代理
        if ([self.delegate respondsToSelector:@selector(cameraRampToVideoZoomFactor:withRate:)]) {
//            NSLog(@"%f-%f",_nowScale,scale);
            [self.delegate cameraRampToVideoZoomFactor:_nowScale withRate:50];
        }
        
    }else if (gesture.state == UIGestureRecognizerStateEnded || gesture.state == UIGestureRecognizerStateCancelled){
        _preScale = _nowScale;
    }
    
}

#pragma mark 缩放比例

//- (void)changeScalePointWithOutputScale:(float)scale{
//    scale = (scale-1)*1.0/3;
//    float pointX = (self.scaleLineImgView.frame.size.width - self.scalePointImgView.frame.size.width)*scale + CGRectGetMinX(self.scaleLineImgView.frame);
//    self.scalePointImgView.frame = CGRectMake(pointX , self.scalePointImgView.frame.origin.y, self.scalePointImgView.frame.size.width, self.scalePointImgView.frame.size.height);
//}

#pragma mark 点击手势
- (void)tapChangeGesture:(UITapGestureRecognizer *)gesture{
    if (self.showFilter) {
        [self videoCameraVideoLeave];
    }
    if ([self.delegate respondsToSelector:@selector(overlayViewTapFocosExposurePoint)]) {
        [self.delegate overlayViewTapFocosExposurePoint];
    }
    CGPoint location = [gesture locationInView:_perView];
    [self moveExposurePointerToPoint:location];
}

#pragma mark 左滑手势

- (void)leftSwipe:(UISwipeGestureRecognizer *)gesture {
    if (self.showFilter) {
        [self videoCameraVideoLeave];
    }
    [self videoFilterViewSelectNextIndexPath];
}

#pragma mark 右滑手势

- (void)rightSwipe:(UISwipeGestureRecognizer *)gesture {
    if (self.showFilter) {
        [self videoCameraVideoLeave];
    }
    [self videoFilterViewSelectPreIndexPath];
}

#pragma mark 上滑手势

- (void)upSwipe:(UISwipeGestureRecognizer *)gesture {
    if (self.showFilter) {
        [self videoCameraVideoLeave];
    }
    if (self.videoCameraOrientationMode == kVideoCameraViewOrientationModeLeft) {
        [self videoFilterViewSelectNextIndexPath];
    } else if (self.videoCameraOrientationMode == kVideoCameraViewOrientationModeRight) {
        [self videoFilterViewSelectPreIndexPath];
    }
}

#pragma mark 下滑手势

- (void)downSwipe:(UISwipeGestureRecognizer *)gesture {
    if (self.showFilter) {
        [self videoCameraVideoLeave];
    }
    if (self.videoCameraOrientationMode == kVideoCameraViewOrientationModeLeft) {
        [self videoFilterViewSelectPreIndexPath];
    } else if (self.videoCameraOrientationMode == kVideoCameraViewOrientationModeRight) {
        [self videoFilterViewSelectNextIndexPath];
    }
}

- (void)videoFilterViewSelectNextIndexPath {
    NSIndexPath *indexPath = nil;
    if (self.videoFilterView.currentIndexPath) {
        indexPath = [NSIndexPath indexPathForItem:self.videoFilterView.currentIndexPath.item+1 inSection:0];
    } else {
        indexPath = [NSIndexPath indexPathForItem:1 inSection:0];
    }
//    NSLog(@"select下一个 - %ld",indexPath.item);
    [self.videoFilterView selectItemAtIndexPath:indexPath];
}

- (void)videoFilterViewSelectPreIndexPath {
    NSIndexPath *indexPath = nil;
    if (self.videoFilterView.currentIndexPath) {
        indexPath = [NSIndexPath indexPathForItem:self.videoFilterView.currentIndexPath.item-1 inSection:0];
    } else {
        indexPath = [NSIndexPath indexPathForItem:0 inSection:0];
    }
//    NSLog(@"select上一个 - %ld",indexPath.item);
    [self.videoFilterView selectItemAtIndexPath:indexPath];
}

/*
// 竖屏手势
- (void)openSwipeGestureForProtrait {
    self.leftSwipeGesture.enabled = YES;
    self.rightSwipeGesture.enabled = YES;
    self.upSwipeGesture.enabled = NO;
    self.downSwipeGesture.enabled = NO;
}

// 横屏手势
- (void)openSwipeGestureForLandscape {
    self.leftSwipeGesture.enabled = NO;
    self.rightSwipeGesture.enabled = NO;
    self.upSwipeGesture.enabled = YES;
    self.downSwipeGesture.enabled = YES;
}

- (void)enableSwipeGesture:(BOOL)enable {
    self.leftSwipeGesture.enabled = enable;
    self.rightSwipeGesture.enabled = enable;
    self.upSwipeGesture.enabled = enable;
    self.downSwipeGesture.enabled = enable;
}
 */

#pragma mark - 定时

- (void)recordFinish {
    [self stopRecord];
}

- (void)recordProgressFuction{
    self.recordProgress += 0.01;
    float percent = self.recordProgress/(float)self.recordTime;
    [self.recordCircleView reloadViewWithPercent:percent];
    self.progressLabel.text = [NSString stringWithFormat:@"%.1f",self.recordProgress];;
}

- (void)createTimer{
    [self destroyTimer];
    self.recordTimer = [NSTimer scheduledTimerWithTimeInterval:self.recordTime target:self selector:@selector(stopRecord) userInfo:nil repeats:NO];
    self.recordProgressTimer = [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(recordProgressFuction) userInfo:nil repeats:YES];
}

#pragma mark 销毁定时器
- (void)destroyTimer{
    if(self.recordTimer){
        [self.recordTimer invalidate];
        self.recordTimer = nil;
    }
    if(self.recordProgressTimer){
        [self.recordProgressTimer invalidate];
        self.recordProgressTimer = nil;
    }
}

#pragma mark setter&&get

//- (UILabel *)showFilterNameLabel {
//    if (!_showFilterNameLabel) {
//        _showFilterNameLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 50)];
//        _showFilterNameLabel.textAlignment = NSTextAlignmentCenter;
//        _showFilterNameLabel.font = [UIFont systemFontOfSize:30.0];
//        _showFilterNameLabel.textColor = [UIColor whiteColor];
////        _showFilterNameLabel.center = self.center;
//        _showFilterNameLabel.alpha = 0.0;
//    }
//    return _showFilterNameLabel;
//}

- (UIImageView *)nnewExprosureImgView {
    if (!_nnewExprosureImgView) {
        UIImage *exprosureImg = [UIImage imageNamed:@"ExposurePointer.png"];
        _nnewExprosureImgView = [[UIImageView alloc]initWithImage:exprosureImg];
        _nnewExprosureImgView.frame = CGRectMake(0, 0, exprosureImg.size.width/2 * 1, exprosureImg.size.height/2 * 1);
        _nnewExprosureImgView.center = _perView.center;
        _nnewExprosureImgView.userInteractionEnabled = YES;
        [_perView addSubview:_nnewExprosureImgView];
        _nnewExprosureImgView.alpha = 0.0;
    }
    return _nnewExprosureImgView;
}

- (UIImageView *)nnewFocusImgView {
    if (!_nnewFocusImgView) {
        UIImage *focusImg = [UIImage imageNamed:@"FocusPointer.png"];
        _nnewFocusImgView = [[UIImageView alloc]initWithImage:focusImg];
        _nnewFocusImgView.frame = CGRectMake(0, 0, focusImg.size.width/2 * 1, focusImg.size.height/2 * 1);
        _nnewFocusImgView.center = _perView.center;
        _nnewFocusImgView.userInteractionEnabled = YES;
        [_perView addSubview:_nnewFocusImgView];
        _nnewFocusImgView.alpha = 0.0;
    }
    return _nnewFocusImgView;
}

#pragma mark - CameraCourseViewDelegate
- (void)removeCourseViewFromSuperView{
    self.courseView.userInteractionEnabled = NO;
    if (self.isUsingCourseView) {
        [UIView animateWithDuration:0.5 animations:^{
            self.courseView.alpha = 0.0;
        } completion:^(BOOL finished) {
            [self.courseView removeFromSuperview];
            self.courseView = nil;
//            self.topbar.hidden = NO;
            self.topbar.alpha = 1.0;
            self.isUsingCourseView = NO;
            self.changeShotModeBtn.hidden = NO;
            [self bringSubviewToFront:self.topbar];
        }];
    } else {
        [UIView animateWithDuration:0.4 animations:^{
            self.courseView.frame = CGRectMake(SCREEN_WIDTH, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
        } completion:^(BOOL finished) {
            [self.courseView removeFromSuperview];
            self.courseView = nil;
//            self.topbar.hidden = NO;
            self.topbar.alpha = 1.0;
            // [self.ownView courseCancelButtonDidBePressedThanCameraViewTopBarShow];
        }];
    }
}
- (void)CourseViewGoBackButtonDidBePressed:(UIButton *)sender {
    [self removeCourseViewFromSuperView];
}

- (void)CourseViewCancelConstructButtonDidBePressed:(UIButton *)sender {
    [self removeCourseViewFromSuperView];
}
- (void)CourseViewUseConstructButtonDidBePressed:(UIButton *)sender withConstructRatio:(constructRatio)constructRatio {
    if ([self.delegate respondsToSelector:@selector(videoCameraUesCourseView)]) {
        [self.delegate videoCameraUesCourseView];
    }
    self.isUsingCourseView = YES;
//    self.topbar.hidden = YES;
    self.topbar.alpha = 0.0;
    self.changeShotModeBtn.hidden = YES;
    //    [self bringSubviewToFront:self.videoFilterView];
    //    [self bringSubviewToFront:self.bottomBar];
    [self sendSubviewToBack:self.courseView];
    [self sendSubviewToBack:self.topbar];
    if (IsIPAD) {
        self.cancelCourseViewBtnForIPad = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 50)];
        self.cancelCourseViewBtnForIPad.backgroundColor = [UIColor clearColor];
        [self.cancelCourseViewBtnForIPad addTarget:self action:@selector(cancelCourseViewBtnForIPad:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:self.cancelCourseViewBtnForIPad];
    }
}

- (void)cancelCourseViewBtnForIPad:(UIButton *)button {
    [self.courseView pressCancelConstructBtn];
    [self.cancelCourseViewBtnForIPad removeFromSuperview];
    self.cancelCourseViewBtnForIPad = nil;
}

- (void)takePhotoAnimation
{
    UIView *blackView = [[UIView alloc]initWithFrame:self.perView.bounds];
    [self.perView addSubview:blackView];
    blackView.backgroundColor = [UIColor whiteColor];
    [UIView animateWithDuration:0.3 animations:^{
        blackView.alpha = 0.2;
    } completion:^(BOOL finished) {
        [blackView removeFromSuperview];
    }];
    
}


@end
