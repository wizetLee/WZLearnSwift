//
//  INPVideoCameraFilterView.h
//  POCONewCamera
//
//  Created by 陈弢 on 2017/6/20.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <OpenGLESImage/OpenGLESImage.h>

// 打开推荐页面时的通知
//extern NSString *const INPVideoCameraFilterViewOpenRecommendNotification;
extern NSString *const INPVideoCameraFilterViewEnterMaterialCenterNotification;

@protocol INPVideoCameraFilterViewDelegate <NSObject>
// 选择滤镜
- (void)videoCameraVideoFilterViewDidChangeFilter:(OIFilter *)filter; // 单选某滤镜
- (void)videoCameraVideoFilterViewDidChangeNextFilter:(OIFilter *)filter withOrder:(BOOL)nextOrder; // 下一张滤镜
// 退出操作
- (void)videoCameraVideoLeave;
// 获取缩略图
- (void)videoCameraVideoFilterGetThumbnailImage:(UIImage *)thumbnail andCoverColor:(NSArray *)coverColor colorId:(NSString *)colorId;

@end

@interface INPVideoCameraFilterView : UIView

@property (nonatomic, weak) id<INPVideoCameraFilterViewDelegate> delegate;
@property (nonatomic, assign) BOOL openMultipeFilterSwitchingEffect;

@property (nonatomic, strong) NSIndexPath *currentIndexPath;
- (void)currentIndexPathReduction;
- (void)currentIndexPathIncrease;

@property (nonatomic, assign, readonly) BOOL alphaAdjusting;

@property (nonatomic, strong) OIFilter *currentFilter;

//@property (nonatomic, strong, readonly) NSDictionary *colorFilter;

- (void)selectItemAtIndexPath:(NSIndexPath *)indexPath;

- (OIFilter *)getFilterBackWhenSelectItemAtIndexPath:(NSIndexPath *)indexPath;

- (void)enterAlphaAdjusting;

// 根据colorId选择某个滤镜(通常为默认滤镜)
- (void)selectColorFilterWithColorId:(NSString *)colorId;

@end
