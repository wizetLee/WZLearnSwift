//
//  VideoCameraPreviewView.m
//  POCONewCamera
//
//  Created by 陈弢 on 2017/6/6.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import "VideoCameraPreviewView.h"
#import <AssetsLibrary/AssetsLibrary.h>
//#import "OIVideoWhiteBalanceFilter.h"
//#import "INPCameraFilterModel.h"
#import <Photos/Photos.h>
#import "OISwitchFilter.h"
#import "OILookUpTableFilter.h"
#import "OIMultipleBlendFilter.h"

#import "CameraVideoPresetManager.h"
//#import "INPFilterCountNumber.h"
//#import "AlbumOperationFunction.h"

//static const NSInteger kCameraViewMaxExposurePointerFlickerCount = 2;
//static const int INPVideoFrameRate = 25; // 帧率


#define PreviewViewWidth (SCREEN_WIDTH * Adjust_ScreenScale)
#define PreviewViewHeight (SCREEN_HEIGHT * Adjust_ScreenScale)
#define PreviewViewWidth (SCREEN_WIDTH * Adjust_ScreenScale)
#define PreviewViewHeight (SCREEN_HEIGHT * Adjust_ScreenScale)
#define PreviewViewScale (SCREEN_HEIGHT / SCREEN_WIDTH)
#define HeightMarginWhen4To3 (((SCREEN_WIDTH/9.0*16.0)-(SCREEN_WIDTH/3.0*4.0))/2.0-50)

#define Adjust_ScreenScale 2

#define TopBarHeight 50.0

@interface VideoCameraPreviewView ()<OIMediaCaptorDelegate, OIAudioVideoWriterDelegate> {
    AVCaptureVideoOrientation _videoBufferOrientation;
}

@property (nonatomic, strong) OIView *previewView;        // 预览界面(尺寸永远为界面大小)
@property (nonatomic, strong) OIAudioVideoWriter *videoAudioWriter; // 音频视频写入

// --------------滤镜--------------
@property (nonatomic, strong) OIFilter *emptyCropFilter; // 只负责裁剪，不负责缩放，好处是这个可以直接输出给writer，不需要调整(注意：拍摄视频用这个filter来作为writer的输入)
@property (nonatomic, strong) OIFilter *emptyScaleFilter; // 负责缩放
@property (nonatomic, strong) OIFilter *INPFilter; // 当前印象滤镜
// 滤镜切换效果（需要同时加载三个滤镜）
@property (nonatomic, strong) OISwitchFilter *switchFilter; // 切换滤镜类
@property (nonatomic, strong) OIFilter *nextINPFilter;

//@property (nonatomic, strong) OIFilter *recordOIFilter; // 记录着拍摄状态的滤镜

@property (nonatomic, assign) BOOL filterIsSwiping; // 正在切换滤镜中 (用一个信号量控制)
@property (nonatomic, assign) BOOL filterIsResuming; // 正在恢复/切换滤镜
// --------------滤镜--------------

@property (nonatomic, assign) BOOL isChangingSession;
@property (nonatomic, assign) CGSize videoOutputSize;
// mediaCaptor->outputFrame
@property (nonatomic, assign) CGFloat captorWidth;
@property (nonatomic, assign) CGFloat captorHeight;
@property (nonatomic, assign) CGFloat scaleOfCaptor;

@property (nonatomic, strong) CameraVideoPresetManager *presetManager;

@property (nonatomic, assign, readwrite) BOOL isRecordingVideo;
@property (nonatomic, assign) BOOL isCapturingStillImage;

@property (nonatomic, strong) UIVisualEffectView *visualView;

// TEMP
@property (nonatomic, strong) UIView *shutterView;
@property (nonatomic, strong) CADisplayLink *switchAnimationLink;

@property (nonatomic, assign) VideoCameraViewOrientationMode currentVideoCameraOrientation;

@property (nonatomic, strong) NSURL *saveOriginVideoURL;

@end

@implementation VideoCameraPreviewView

//- (instancetype)initWithFrame:(CGRect)frame {
//    self = [super initWithFrame:frame];
//    if (self) {
//        [self setupUI];
//        [self startSwitchingAnimationUsingCADisplayLink];
//    }
//    return self;
//}

- (instancetype)initWithFrame:(CGRect)frame andCameraType:(InterPhotoCameraPreviewType)cameraType {
    self = [super initWithFrame:frame];
    if (self) {
        _cameraType = cameraType;
        [self setupUI];
        [self startSwitchingAnimationUsingCADisplayLink];
    }
    return self;
}

- (void)setupUI {
    self.previewView = [[OIView alloc] initWithFrame:self.bounds];
    
    [self initCamera];
    [self initFilters];
    
    // 镜头 -> 裁剪filter -> 缩放filter -> OIView
    [self.mediaCaptor addConsumer:self.emptyCropFilter];
    self.mediaCaptor.exposureMode = AVCaptureExposureModeContinuousAutoExposure;
    self.mediaCaptor.focusMode = AVCaptureFocusModeContinuousAutoFocus;
    [self.emptyCropFilter addConsumer:self.INPFilter];
    [self.INPFilter addConsumer:self.emptyScaleFilter];
    
    
    [self.emptyScaleFilter addConsumer:self.previewView];
    
    [self.mediaCaptor startRunning];
    
    [self addSubview:self.previewView];
    [self addSubview:self.shutterView];

    // 手动设置其实outputFrame
//    if (self.cameraType == kInterPhotoCameraPreviewTypeVideoOnly) {
//        _cameraMode = kVideoCameraModeVideo;
//    } else {
//        _cameraMode = kVideoCameraModeStillImage;
//    }
//    self.cameraMode = kVideoCameraModeStillImage;
    
    self.switchFilter = [[OISwitchFilter alloc] init];
}

- (void)initCamera {
    if (self.cameraType == kInterPhotoCameraPreviewTypeVideoOnly) {
        self.mediaCaptor = [[OIMediaCaptor alloc] initHighPresetVideoCamera];
        _cameraMode = kVideoCameraModeVideo;
    } else {
        self.mediaCaptor = [[OIMediaCaptor alloc] initWithCameraMode:OIMediaCaptorCameraModeStillImage cameraPosition:AVCaptureDevicePositionBack sessionPreset:AVCaptureSessionPresetPhoto];
        _cameraMode = kVideoCameraModeStillImage;
    }
    [self initCameraModeWithoutSettingCameraMode];
    
    self.mediaCaptor.delegate = self;
    self.mediaCaptor.enableSmoothAutoFocus = self.presetManager.enableSmoothAutoFocus;
    self.mediaCaptor.enableVideoStabilization = self.presetManager.enableVideoStabilization;
    // 出现设备不支持，崩溃
    self.mediaCaptor.frameRate = self.presetManager.maximumFrameRate; // 设定为25帧
}

- (void)initFilters {
    self.emptyCropFilter = [[OIFilter alloc] init];
    self.emptyScaleFilter = [[OIFilter alloc] init];
    self.INPFilter = [[OIFilter alloc] init];
}

- (void)createWriterFilter {
    self.mediaCaptor.uniqueURL = nil;
    NSURL *urlPath = nil;//[AlbumOperationFunction originVideoPathWithDeleteExitPath:YES];
    if (urlPath) {
        self.videoAudioWriter = [[OIAudioVideoWriter alloc] initWithContentSize:self.videoOutputSize outputURL:urlPath];
        self.saveOriginVideoURL = urlPath;
    } else {
        self.videoAudioWriter = [[OIAudioVideoWriter alloc] initWithContentSize:self.videoOutputSize outputURL:self.mediaCaptor.uniqueURL];
        self.saveOriginVideoURL = self.mediaCaptor.uniqueURL;
        NSLog(@"警告 - 镜头原存放视频路径出错，使用了临时唯一路径代替 VideoCameraPreviewView: - (void)createWriterFilter");
    }
    self.videoAudioWriter.delegate = self;
    self.videoAudioWriter.writingInRealTime = YES;
    self.videoAudioWriter.shouldWriteWithAudio = YES;
    
    self.videoAudioWriter.enabled = NO;
}

// 设置比例
- (void)setPreviewCrop:(VideoCameraPreviewCrop)previewCrop {
//    NSLog(@"设置镜头尺寸");
    _previewCrop = previewCrop;
    switch (previewCrop) {
        case kVideoCameraPreviewCrop1To1:
            [self adjustSizeWithClipScale:1.0/1.0];
            break;
        case kVideoCameraPreviewCrop4To3:
            [self adjustSizeWithClipScale:3.0/4.0];
            break;
        case kVideoCameraPreviewCrop16To9:
            [self adjustSizeWithClipScale:9.0/16.0];
            break;
        case kVideoCameraPreviewCrop235To1:
            // 取消2.35
//            if (self.currentVideoCameraOrientation == kVideoCameraViewOrientationModeLeft || self.currentVideoCameraOrientation == kVideoCameraViewOrientationModeRight) {
//                [self adjustSizeWithClipScale:9.0/16.0];
//            } else {
                [self adjustSizeWithClipScale:16.0/9.0];
//            }
            break;
        case kVideoCameraPreviewCrop9To16:
            [self adjustSizeWithClipScale:16.0/9.0];
            break;
            
            
            
            // TODO
            
        case kVideoCameraPreviewPhotoCrop1To1:
            [self adjustSizeWithClipScale:1.0/1.0];
            break;
        case kVideoCameraPreviewPhotoCrop3To4:
            [self adjustSizeWithClipScale:3.0/4.0];
            break;
        case kVideoCameraPreviewPhotoCrop9To16:
            [self adjustSizeWithClipScale:9.0/16.0];
            break;
            
        case kVideoCameraPreviewVideoCrop1To1:
            [self adjustSizeWithClipScale:1.0/1.0];
            break;
        case kVideoCameraPreviewVideoCrop9To16:
            [self adjustSizeWithClipScale:9.0/16.0];
            break;
        case kVideoCameraPreviewVideoCrop16To9:
            if (self.currentVideoCameraOrientation == kVideoCameraViewOrientationModeLeft || self.currentVideoCameraOrientation == kVideoCameraViewOrientationModeRight) {
                [self adjustSizeWithClipScale:9.0/16.0];
            } else {
                [self adjustSizeWithClipScale:16.0/9.0];
            }
            break;
        case kVideoCameraPreviewVideoCrop235To1:
            if (self.currentVideoCameraOrientation == kVideoCameraViewOrientationModeLeft || self.currentVideoCameraOrientation == kVideoCameraViewOrientationModeRight) {
                [self adjustSizeWithClipScale:1.0/2.35];
            } else {
                [self adjustSizeWithClipScale:2.35/1.0];
            }
            break;
    }
}

int integerSingleDigits(float digit) {
    int tmpDigit = digit / 10;
    return tmpDigit * 10;
}

//根据剪切比例 调整Size
- (void)adjustSizeWithClipScale:(CGFloat)clipScale {
//    self.previewView.enabled = NO;
    CGFloat basicScale = self.cameraMode == kVideoCameraModeStillImage ? 3.0/4.0 : 9.0/16.0;//
    
    if ((basicScale - clipScale) > 0) {
        // ---调整x(目前仅适用于静态图下的9:16)---
        // 裁剪
        self.emptyCropFilter.contentSize = CGSizeMake(self.captorHeight*clipScale, self.captorHeight);
        self.mediaCaptor.outputFrame = CGRectMake(-(basicScale - clipScale)/2.0*self.captorHeight, 0, self.captorWidth, self.captorHeight);
        self.emptyCropFilter.outputFrame = CGRectMake(0, 0, self.emptyCropFilter.contentSize.width, self.emptyCropFilter.contentSize.height);
        // 调整视图大小
        self.emptyScaleFilter.contentSize = CGSizeMake(self.captorHeight*clipScale, self.captorHeight);
//        self.emptyScaleFilter.outputFrame = CGRectMake(0, 0, PreviewViewWidth, PreviewViewHeight);
        
        if (PreviewViewWidth > PreviewViewHeight*clipScale && self.cameraMode == kVideoCameraModeVideo) {
            // 这个临时加给横向2.35：1的
            self.emptyScaleFilter.outputFrame = CGRectMake((PreviewViewWidth - PreviewViewHeight*clipScale)/2.0, 0, integerSingleDigits(PreviewViewHeight*clipScale), integerSingleDigits(PreviewViewHeight));
        } else {
            if (IsIPAD) {
                self.emptyScaleFilter.outputFrame = CGRectMake((basicScale - clipScale)/2.0*self.captorHeight, 0, self.emptyCropFilter.contentSize.width, self.emptyCropFilter.contentSize.height);;
            } else {
                self.emptyScaleFilter.outputFrame = CGRectMake(0, 0, PreviewViewWidth, PreviewViewHeight);
            }
        }
        
    } else {
        // ---调整y---
        // 裁剪
//        self.emptyCropFilter.contentSize = CGSizeMake(self.captorWidth, self.captorWidth/clipScale);
        self.emptyCropFilter.contentSize = CGSizeMake(integerSingleDigits(self.captorWidth), integerSingleDigits(self.captorWidth/clipScale));
//        self.mediaCaptor.outputFrame = CGRectMake(0, -(1.0/basicScale - 1.0/clipScale)/2.0/(1.0/basicScale)*self.captorHeight, self.captorWidth, self.captorHeight);
        self.mediaCaptor.outputFrame = CGRectMake(0, integerSingleDigits(-(1.0/basicScale - 1.0/clipScale)/2.0/(1.0/basicScale)*self.captorHeight), self.captorWidth, self.captorHeight);
        self.emptyCropFilter.outputFrame = CGRectMake(0, 0, self.emptyCropFilter.contentSize.width, self.emptyCropFilter.contentSize.height);
        // 调整视图大小
//        self.emptyScaleFilter.contentSize = CGSizeMake(self.captorWidth, self.captorWidth/clipScale);
//        self.emptyScaleFilter.outputFrame = CGRectMake(0, (PreviewViewScale - 1.0/clipScale)/2.0/PreviewViewScale*PreviewViewHeight, PreviewViewWidth, PreviewViewWidth/clipScale);
        self.emptyScaleFilter.contentSize = CGSizeMake(integerSingleDigits(self.captorWidth), integerSingleDigits(self.captorWidth/clipScale));
        self.emptyScaleFilter.outputFrame = CGRectMake(0, (PreviewViewScale - 1.0/clipScale)/2.0/PreviewViewScale*PreviewViewHeight, integerSingleDigits(PreviewViewWidth), integerSingleDigits(PreviewViewWidth/clipScale));
    }
    // 调整滤镜Filter
    self.INPFilter.contentSize = self.emptyCropFilter.contentSize;
    self.INPFilter.outputFrame = self.emptyCropFilter.outputFrame;
    // 调整switchFilter
    self.switchFilter.contentSize = self.emptyCropFilter.contentSize;
    self.switchFilter.outputFrame = CGRectMake(0, 0, self.emptyCropFilter.outputFrame.size.width, self.emptyCropFilter.outputFrame.size.height);
    
    self.videoOutputSize = self.emptyCropFilter.contentSize;
    
    if (!IsIPAD) {
        if (ABS(self.emptyScaleFilter.outputFrame.origin.y) > 1.0 ){//&& self.cameraMode == kVideoCameraModeStillImage) {
            // 向上移动preView的y值
            CGFloat ScaleFilterOriginY3To4 = (PreviewViewScale - 1.0/(3.0/4.0))/2.0/PreviewViewScale*PreviewViewHeight;
            CGFloat movePosition = ScaleFilterOriginY3To4/Adjust_ScreenScale - TopBarHeight; // 50是topbar高度
            self.previewView.frame = CGRectMake(0, -movePosition, self.previewView.frame.size.width, self.previewView.frame.size.height);
        } else {
            self.previewView.frame = self.bounds;
        }
    }
    
//    self.previewView.enabled = YES;
    if ([self.delegate respondsToSelector:@selector(previewAdjustFrame:)]) {
        CGRect previewAdjustFrame = CGRectMake(self.emptyScaleFilter.outputFrame.origin.x/Adjust_ScreenScale, self.emptyScaleFilter.outputFrame.origin.y/Adjust_ScreenScale + self.previewView.frame.origin.y, self.emptyScaleFilter.outputFrame.size.width/Adjust_ScreenScale, self.emptyScaleFilter.outputFrame.size.height/Adjust_ScreenScale);
        [self.delegate previewAdjustFrame:previewAdjustFrame];
    }
}

// 第一次进入设置
- (void)firstComeSetPreviewCrop:(VideoCameraPreviewCrop)firstComeCrop {
    while (self.mediaCaptor.outputFrame.size.width != 0) {
        [self adjustSizeWithClipScale:firstComeCrop];
    }
}

#pragma mark - Public Method

- (void)cameraRampToVideoZoomFactor:(CGFloat)factor withRate:(float)rate {
    [self.mediaCaptor rampToVideoZoomFactor:factor withRate:rate];
}

- (void)stopSwichingTimer {
    [self stopSwitchingAnimationUsingCADisplayLink];
}

#pragma mark 方向属性
- (void)setCameraPreviewOrientation:(VideoCameraViewOrientationMode)orientationMode {
    self.currentVideoCameraOrientation = orientationMode;
    self.previewCrop = self.previewCrop;// 触发setter
}

#pragma mark - 设置滤镜/滤镜链/切换滤镜动画/timer
// 设置滤镜 // 保留
- (void)setFilter:(OIFilter *)inpFilter {
    [self currentFilterCancelChain];
    self.INPFilter = inpFilter;
    [self currentFilterRebuildChain];
}

// 设置下一个滤镜
- (void)setRightFilter:(OIFilter *)rightFilter {
    if (self.currentVideoCameraOrientation == kVideoCameraViewOrientationModePortrait ||
        self.currentVideoCameraOrientation == kVideoCameraViewOrientationModeUpSideDown) {
        if (self.switchFilter.closewise == 1) {
            self.switchFilter.index = 0.0;
        } else if (self.switchFilter.index != 0.0) {
            self.switchFilter.index = 1.0 - self.switchFilter.index;
        }
        self.switchFilter.closewise = 1;
//        [self setAnimateSwitchFilter:rightFilter];
    } else if (self.currentVideoCameraOrientation == kVideoCameraViewOrientationModeLeft) {
//        NSLog(@"next left"); // correct
        if (self.switchFilter.closewise == 1) {
            self.switchFilter.index = 0.0;
        } else if (self.switchFilter.index != 0.0) {
            self.switchFilter.index = 1.0 - self.switchFilter.index;
        }
        self.switchFilter.closewise = 2;
//        [self setAnimateSwitchFilter:rightFilter];
    } else if (self.currentVideoCameraOrientation == kVideoCameraViewOrientationModeRight) {
//        NSLog(@"next right");
        if (self.switchFilter.closewise == 1) {
            self.switchFilter.index = 0.0;
        } else if (self.switchFilter.index != 0.0) {
            self.switchFilter.index = 1.0 - self.switchFilter.index;
        }
        self.switchFilter.closewise = 3;
//        [self setAnimateSwitchFilter:rightFilter];
    }
    [self prepareSwitchFilterWithoutAnimate:rightFilter];
}

// 设置上一个滤镜
- (void)setLeftFilter:(OIFilter *)leftFilter {
    if (self.currentVideoCameraOrientation == kVideoCameraViewOrientationModePortrait ||
        self.currentVideoCameraOrientation == kVideoCameraViewOrientationModeUpSideDown) {
        if (self.switchFilter.closewise == 0) {
            self.switchFilter.index = 0.0;
        } else if (self.switchFilter.index != 0.0) {
            self.switchFilter.index = 1.0 - self.switchFilter.index;
        }
        self.switchFilter.closewise = 0;
//        [self setAnimateSwitchFilter:leftFilter];
    } else if (self.currentVideoCameraOrientation == kVideoCameraViewOrientationModeLeft) {
        if (self.switchFilter.closewise == 0) {
            self.switchFilter.index = 0.0;
        } else if (self.switchFilter.index != 0.0) {
            self.switchFilter.index = 1.0 - self.switchFilter.index;
        }
        self.switchFilter.closewise = 3;
//        [self setAnimateSwitchFilter:leftFilter];
    } else if (self.currentVideoCameraOrientation == kVideoCameraViewOrientationModeRight) {
        if (self.switchFilter.closewise == 0) {
            self.switchFilter.index = 0.0;
        } else if (self.switchFilter.index != 0.0) {
            self.switchFilter.index = 1.0 - self.switchFilter.index;
        }
        self.switchFilter.closewise = 2;
//        [self setAnimateSwitchFilter:leftFilter];
    }
    [self prepareSwitchFilterWithoutAnimate:leftFilter];
}

#pragma mark - Public Method - 设置滤镜

- (void)setSwitchFilterWithPercent:(CGFloat)percent {
    self.switchFilter.index = percent;
}

// 开始切换滤镜动画
- (void)setAnimateSwitchFilter:(OIFilter *)filter {
    [self prepareSwitchFilterWithoutAnimate:filter];
    // 5、执行timer动画
    [self startSwitchingAnimation];
}

// 准备切换动画
- (void)prepareSwitchFilterWithoutAnimate:(OIFilter *)filter {
    // 1、确认当前是否正在切换滤镜中
    if (self.filterIsSwiping) {
        
        // 1.2、切断滤镜双链
        [self currentSwitchFilterCancelChain];
        
        // 1.3、设置滤镜
        self.INPFilter = self.nextINPFilter;
        self.nextINPFilter = nil;
        
        // 1.4、恢复状态，进入处理
        self.filterIsSwiping = NO;
    }
    
    // 2、切断滤镜单链
    [self currentFilterCancelChain];
    
    // 3、设置nextFilter
    self.nextINPFilter = filter;
    
    // 4、建立滤镜双链
    [self currentSwitchFilterBuildChain];
}

// 开启切换滤镜动画
- (void)startSwitchingAnimation {
    self.filterIsSwiping = YES;
}

- (void)startSwitchingAnimationUsingCADisplayLink {
    self.switchAnimationLink = [CADisplayLink displayLinkWithTarget:self selector:@selector(changingSwitchingAnimation)];
    [self.switchAnimationLink addToRunLoop:[NSRunLoop currentRunLoop] forMode:NSRunLoopCommonModes];
}

- (void)stopSwitchingAnimationUsingCADisplayLink {
    if (self.switchAnimationLink) {
        [self.switchAnimationLink invalidate];
        self.switchAnimationLink = nil;
    }
}

// 正在进行滤镜切换动画
- (void)changingSwitchingAnimation {
    if (!self.filterIsSwiping) {
        return;
    }
    if (self.switchFilter.index >= 1.0 || self.switchFilter.index <= 0.0) {
        [self endSwitchingAnimation];
    } else {
        self.switchFilter.index += self.filterIsResuming ? -0.07 : 0.07;
    }
}

// 结束切换滤镜动画
- (void)endSwitchingAnimation {
//    NSLog(@"结束滤镜动画");
    // 2、切断滤镜双链
    [self currentSwitchFilterCancelChain];
    
    // 3、设置filter
    if (!self.filterIsResuming) {
        self.INPFilter = self.nextINPFilter;
    }
    self.nextINPFilter = nil;
    
    // 4、恢复滤镜单链
    [self currentFilterRebuildChain];
    
    // 5、恢复状态
    self.switchFilter.index = 0.0;
    self.filterIsSwiping = NO;
}

- (void)didEndFilterChoosingWithPercent:(CGFloat)percent resume:(BOOL)isResume {
    if (isResume) {
        // 恢复
//        NSLog(@"恢复");
        self.filterIsResuming = YES;
        self.filterIsSwiping = YES;
        
    } else {
        
        self.filterIsResuming = NO;
        // 选择下一个
        self.filterIsSwiping = YES;
    }
}

// 断开滤镜单链
- (void)currentFilterCancelChain {
//    [self.emptyCropFilter removeConsumer:self.INPFilter];
//    [self.INPFilter removeConsumer:self.emptyScaleFilter];
    [self.emptyCropFilter removeAllConsumers];
    [self.INPFilter removeAllConsumers];
}

// 恢复滤镜单链
- (void)currentFilterRebuildChain {
    [self.emptyCropFilter addConsumer:self.INPFilter];
    [self.INPFilter addConsumer:self.emptyScaleFilter];
}

// 断开滤镜双链
- (void)currentSwitchFilterCancelChain {
    [self.emptyCropFilter removeAllConsumers];
    
    [self.INPFilter removeAllConsumers];
    [self.nextINPFilter removeAllConsumers];
    
    [self.switchFilter removeAllConsumers];
}

// 建立滤镜双链
- (void)currentSwitchFilterBuildChain {
    [self.emptyCropFilter addConsumer:self.INPFilter];
    [self.emptyCropFilter addConsumer:self.nextINPFilter];
    
    [self.INPFilter addConsumer:self.switchFilter];
    [self.nextINPFilter addConsumer:self.switchFilter];
    
    [self.switchFilter addConsumer:self.emptyScaleFilter];
}

#pragma mark 拍摄静态图

- (void)takeStillImagePhotoWithCompletion:(void (^)(UIImage *, NSDictionary *))completion {
    if (self.cameraMode != kVideoCameraModeStillImage) {
        return;
    }
    if (self.isCapturingStillImage) {
        return;
    }
    self.isCapturingStillImage = YES;

    OIMediaCaptorOutputSizeMode sizeMode;
    switch (_previewCrop) {
        case kVideoCameraPreviewCrop1To1:
            sizeMode = OIMediaCaptorOutputSizeMode1To1;
            break;
        case kVideoCameraPreviewCrop4To3:
            sizeMode = OIMediaCaptorOutputSizeMode4To3;
            break;
        case kVideoCameraPreviewCrop16To9:
            sizeMode = OIMediaCaptorOutputSizeMode16To9;
            break;
        default:
            sizeMode = OIMediaCaptorOutputSizeMode4To3;
            break;
    }
    
    self.previewView.enabled = NO;
    [self.mediaCaptor captureProcessedImageWithFinalFilter:@[self.emptyCropFilter, self.INPFilter] cropRect:sizeMode AsynchronouslyWithCompletionHandler:^(UIImage *processedImage, NSError *error) {
        [self setPreviewCrop:self.previewCrop];
        self.previewView.enabled = YES;
        
        self.isCapturingStillImage = NO;
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            completion(processedImage, self.mediaCaptor.currentCaptureMetaData);
        });
    }];
}

- (void)mediaCaptorShouldProcessCapturedStillImageUsingOpenGL {
//    dispatch_async(dispatch_get_global_queue(0, 0), ^{
//        self.previewView.enabled = NO;
//    });
}

#pragma mark - Public Method - 拍摄录制
// 开始录制
- (void)startRecordVideo {
    if (!_videoAudioWriter) {
        [self createWriterFilter];
    }
    
    if (self.cameraType == kInterPhotoCameraPreviewTypeVideoOnly) {
        // 只拍视频，直接输出带滤镜视频
        [self.INPFilter addConsumer:self.videoAudioWriter];
    } else {
        [self.emptyCropFilter addConsumer:self.videoAudioWriter];
    }
    
//    self.recordOIFilter = self.INPFilter;
    
    if (self.isRecordingVideo) {
        NSLog(@"出错！！！已经在录制视频了");
        return;
    }
    
    NSLog(@"开始拍摄视频");
    // 用来获取设备方向/
    switch (self.currentVideoCameraOrientation) {
        case kVideoCameraViewOrientationModePortrait:
            [self.videoAudioWriter setAssetWriterOrientation:CGAffineTransformIdentity];
            break;
        case kVideoCameraViewOrientationModeLeft:
            [self.videoAudioWriter setAssetWriterOrientation:CGAffineTransformMakeRotation(-M_PI/2.0)];
            break;
        case kVideoCameraViewOrientationModeRight:
            [self.videoAudioWriter setAssetWriterOrientation:CGAffineTransformMakeRotation(M_PI/2.0)];
            break;
        case kVideoCameraViewOrientationModeUpSideDown:
            [self.videoAudioWriter setAssetWriterOrientation:CGAffineTransformMakeRotation(M_PI)];
            break;
    }
    
    if ([self.delegate respondsToSelector:@selector(previewStartRecordingVideo:)]) {
        [self.delegate previewStartRecordingVideo:YES];
    }
    
    self.videoAudioWriter.contentSize = self.videoOutputSize;
    self.videoAudioWriter.enabled = YES;
    self.isRecordingVideo = YES;
}

- (void)startRecordVideoWithOrientation:(AVCaptureVideoOrientation)orientation {
    [self startRecordVideo];
}

- (void)finishRecordVideo {
//    if ([self.delegate respondsToSelector:@selector(previewStartRecordingVideo:)]) {
//        [self.delegate previewStartRecordingVideo:NO];
//    }
    [self.videoAudioWriter finishWriting];
    self.videoAudioWriter.enabled = NO;
    self.isRecordingVideo = NO; // 先停掉音频
}

- (void)cancelRecordVideo {
    self.isRecordingVideo = NO;
    self.videoAudioWriter.enabled = NO;
    
    // 清除writer
    if (self.cameraType == kInterPhotoCameraPreviewTypeVideoOnly) {
        [self.INPFilter removeConsumer:self.videoAudioWriter]; // 添加滤镜
    } else {
        [self.emptyCropFilter removeConsumer:self.videoAudioWriter]; // 直接输出
    }
    self.videoAudioWriter = nil;
}

- (void)startCameraRunning {
    [self currentFilterCancelChain];
    [self currentSwitchFilterCancelChain];
    [self currentFilterRebuildChain];
    
    [self.mediaCaptor startRunning];
}

- (void)stopCameraRunning {
    // 关掉闪光灯
    if (self.cameraMode == kVideoCameraModeVideo) {
        [self closeFlashLightWhenInVideoMode];
//        NSString *settingKey = kVideoSettingKey;
//        NSDictionary *settingDic = [[NSUserDefaults standardUserDefaults] objectForKey:settingKey];
//        NSMutableDictionary *temSettingDic = [NSMutableDictionary dictionaryWithDictionary:settingDic];
//        NSString *flashString = temSettingDic[kCameraFreshSetting];
//        
//        // 正在开启闪光灯
//        if (flashString.integerValue == 1) {
//            // 关闭，同时设置为关
//            self.flashMode = kVideoCameraViewFlashModeDisenabled;
//            
//            temSettingDic[kCameraFreshSetting] = @"0";
//            [[NSUserDefaults standardUserDefaults] setObject:temSettingDic forKey:kVideoSettingKey];
//        }
    }
    [self.mediaCaptor stopRunning];
}


- (void)closeFlashLightWhenInVideoMode {
    // 关掉闪光灯
    if (self.cameraMode == kVideoCameraModeVideo) {
        NSString *settingKey = kVideoSettingKey;
        NSDictionary *settingDic = [[NSUserDefaults standardUserDefaults] objectForKey:settingKey];
        NSMutableDictionary *temSettingDic = [NSMutableDictionary dictionaryWithDictionary:settingDic];
        NSString *flashString = temSettingDic[kCameraFreshSetting];
        
        // 正在开启闪光灯
        if (flashString.integerValue == 1) {
            // 关闭，同时设置为关
            self.flashMode = kVideoCameraViewFlashModeDisenabled;
            
            temSettingDic[kCameraFreshSetting] = @"0";
            [[NSUserDefaults standardUserDefaults] setObject:temSettingDic forKey:kVideoSettingKey];
        }
    }
}

#pragma mark - Public Setter

- (void)setCameraMode:(VideoCameraMode)cameraMode {
    if (_cameraMode != cameraMode) {
        [self switchCameraMode];
        _cameraMode = cameraMode;
        _cameraPosition = kVideoCameraPositionBack;
    }
}

- (void)setCameraPosition:(VideoCameraPosition)cameraPosition {
    if (self.cameraMode == kVideoCameraModeVideo && cameraPosition == kVideoCameraPositionFront) {
        // 关掉闪光灯
//        if (self.cameraMode == kVideoCameraModeVideo) {
//            NSString *settingKey = kVideoSettingKey;
//            NSDictionary *settingDic = [[NSUserDefaults standardUserDefaults] objectForKey:settingKey];
//            NSMutableDictionary *temSettingDic = [NSMutableDictionary dictionaryWithDictionary:settingDic];
//            NSString *flashString = temSettingDic[kCameraFreshSetting];
//            
//            // 正在开启闪光灯
//            if (flashString.integerValue == 1) {
//                // 关闭，同时设置为关
//                self.flashMode = kVideoCameraViewFlashModeDisenabled;
//                
//                temSettingDic[kCameraFreshSetting] = @"0";
//                [[NSUserDefaults standardUserDefaults] setObject:temSettingDic forKey:kVideoSettingKey];
//            }
//        }
        [self closeFlashLightWhenInVideoMode];
    }
    
    if (_cameraPosition != cameraPosition) {
        [self switchCameraPosition];
        _cameraPosition = cameraPosition;
    }
}

#pragma mark - Private Method

- (CGAffineTransform)transformFromVideoBufferOrientationToOrientation:(AVCaptureVideoOrientation)orientation withAutoMirroring:(BOOL)mirror {
    CGAffineTransform transform = CGAffineTransformIdentity;
    
    CGFloat orientationAngleOffset = angleOffsetFromPortraitOrientationToOrientation(orientation);
    CGFloat videoOrientationAngleOffset = angleOffsetFromPortraitOrientationToOrientation(_videoBufferOrientation);
    
    CGFloat angleOffset = orientationAngleOffset - videoOrientationAngleOffset;
    transform = CGAffineTransformMakeRotation(angleOffset);
    
    if (self.cameraPosition == kVideoCameraPositionFront) {
        if (mirror) {
            transform = CGAffineTransformScale(transform, -1, 1);
        } else {
            if (UIInterfaceOrientationIsPortrait((UIInterfaceOrientation)orientation)) {
                transform = CGAffineTransformRotate(transform, M_PI);
            }
        }
    }
    return transform;
}

static CGFloat angleOffsetFromPortraitOrientationToOrientation(AVCaptureVideoOrientation orientation) {
    CGFloat angle = 0.0;
    
    switch (orientation) {
        case AVCaptureVideoOrientationPortrait:
            angle = 0.0;
            break;
        case AVCaptureVideoOrientationPortraitUpsideDown:
            angle = M_PI;
            break;
        case AVCaptureVideoOrientationLandscapeRight:
            angle = -M_PI_2;
            break;
        case AVCaptureVideoOrientationLandscapeLeft:
            angle = M_PI_2;
            break;
        default:
            break;
    }
    return angle;
}

- (CGFloat)captorWidth {
    return self.mediaCaptor.outputFrame.size.width == 0 ? PreviewViewWidth : self.mediaCaptor.outputFrame.size.width;
}
- (CGFloat)captorHeight {
    return self.mediaCaptor.outputFrame.size.height == 0 ? PreviewViewWidth*(4.0/3.0) : self.mediaCaptor.outputFrame.size.height;
}

- (CGFloat)scaleOfCaptor {
    return SCREEN_WIDTH * Adjust_ScreenScale / self.captorWidth;
}

#pragma mark - OIAudioVideoDelegate

- (void)audioVideoWriterDidfinishWriting:(OIAudioVideoWriter *)audioVideoWriter {
    // 清除writer
    if (self.cameraType == kInterPhotoCameraPreviewTypeVideoOnly) {
        [self.INPFilter removeConsumer:self.videoAudioWriter]; // 添加滤镜
    } else {
        [self.emptyCropFilter removeConsumer:self.videoAudioWriter]; // 直接输出
    }
    self.videoAudioWriter = nil;
    
    if ([self.delegate respondsToSelector:@selector(videoCameraFinishRecordVideo:)]) {
        [self.delegate videoCameraFinishRecordVideo:self.saveOriginVideoURL];
    }
}

- (void)saveRecordedVideo:(void(^)(bool isSaved))saveBlock{
    ALAssetsLibrary *library = [[ALAssetsLibrary alloc] init];
    
    [library writeVideoAtPathToSavedPhotosAlbum:self.saveOriginVideoURL completionBlock:^(NSURL *assetURL, NSError *error){
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                NSLog(@"保存失败");
                if(saveBlock){
                    saveBlock(NO);
                }
                
            } else {
                NSLog(@"保存成功");
                
                if(saveBlock){
                    
                    saveBlock(YES);
                }
            }
        });
    }];
}

#pragma mark - Action

- (void)switchCameraPosition {
    [self.mediaCaptor switchCameraPosition];
}

- (void)switchCameraMode {
    self.mediaCaptor.enabled = NO;
    self.isChangingSession = YES;
    
    [self.mediaCaptor switchCameraMode]; // 切换拍摄模式
    if (self.cameraMode == kVideoCameraModeStillImage) {
        [[CLReporting sharedInstance] pushEvent:kCameraCountIndexOfEnterVideoMode paraString:nil];
        if (!_videoAudioWriter) {
            [self createWriterFilter];
        }
        self.mediaCaptor.outputFrame = CGRectMake(0, 0, self.presetManager.cameraOutputSize.width, self.presetManager.cameraOutputSize.height);
    } else {
        [[CLReporting sharedInstance] pushEvent:kCameraCountIndexOfEnterPhotoMode paraString:nil];
        self.mediaCaptor.outputFrame = CGRectMake(0, 0, SCREEN_WIDTH*Adjust_ScreenScale, SCREEN_WIDTH*Adjust_ScreenScale*4/3);
    }
    [self setPreviewCrop:self.previewCrop];
}


- (void)initCameraModeWithoutSettingCameraMode {
    self.mediaCaptor.enabled = NO;
    self.isChangingSession = YES;
    
    if (self.cameraMode == kVideoCameraModeStillImage) {
        [[CLReporting sharedInstance] pushEvent:kCameraCountIndexOfEnterPhotoMode paraString:nil];
        self.mediaCaptor.outputFrame = CGRectMake(0, 0, SCREEN_WIDTH*Adjust_ScreenScale, SCREEN_WIDTH*Adjust_ScreenScale*4/3);
    } else {
        [[CLReporting sharedInstance] pushEvent:kCameraCountIndexOfEnterVideoMode paraString:nil];
        if (!_videoAudioWriter) {
            [self createWriterFilter];
        }
        self.mediaCaptor.outputFrame = CGRectMake(0, 0, self.presetManager.cameraOutputSize.width, self.presetManager.cameraOutputSize.height);
    }
    [self setPreviewCrop:self.previewCrop];
}


#pragma mark - OIFlashDelegate

- (void)setFlashMode:(VideoCameraViewFlashMode)flashMode {
    _flashMode = flashMode;
    switch (flashMode) {
        case kVideoCameraViewFlashModeAuto:
            [self.mediaCaptor setFlashMode:OIMediaCaptorFlashModeAuto];
            break;
        case kVideoCameraViewFlashModeEnabled:
            if (self.cameraMode == kVideoCameraModeVideo) {
                [self.mediaCaptor setFlashMode:OIMediaCaptorFlashModeTorch];
            } else {
                [self.mediaCaptor setFlashMode:OIMediaCaptorFlashModeOn];
            }
            break;
        case kVideoCameraViewFlashModeDisenabled:
            [self.mediaCaptor setFlashMode:OIMediaCaptorFlashModeOff];
            break;
    }
}

- (void)switchCameraAndChangeFlashMode {
    switch (_flashMode) {
        case kVideoCameraViewFlashModeAuto:
            [self.mediaCaptor setFlashMode:OIMediaCaptorFlashModeAuto];
            break;
        case kVideoCameraViewFlashModeEnabled:
            if (self.cameraMode == kVideoCameraModeStillImage) {
                [self.mediaCaptor setFlashMode:OIMediaCaptorFlashModeTorch];
            } else {
                [self.mediaCaptor setFlashMode:OIMediaCaptorFlashModeOn];
            }
            break;
        case kVideoCameraViewFlashModeDisenabled:
            [self.mediaCaptor setFlashMode:OIMediaCaptorFlashModeOff];
            break;
    }
}

#pragma mark - 聚焦点、曝光点

- (void)changeExposurePointerToPoint:(CGPoint)point {
    self.mediaCaptor.exposurePoint = [self getRelativePoint:point];
}

- (void)changeFocusPointerToPoint:(CGPoint)point {
    self.mediaCaptor.focusPoint = [self getRelativePoint:point];
}

- (CGPoint)getRelativePoint:(CGPoint)point {
    CGSize captorSize = self.cameraMode == kVideoCameraModeVideo ? CGSizeMake(SCREEN_WIDTH, SCREEN_HEIGHT) : CGSizeMake(SCREEN_WIDTH, SCREEN_WIDTH/3*4);
    CGPoint truePosition = CGPointZero;
    CGPoint relativePoint = CGPointZero;
    switch (self.previewCrop) {
        case kVideoCameraPreviewCrop1To1:{
            truePosition = CGPointMake(point.x, (SCREEN_HEIGHT - SCREEN_WIDTH)/2 + point.y);
            relativePoint = CGPointMake(truePosition.x / captorSize.width, truePosition.y / captorSize.height);
        }
            break;
        case kVideoCameraPreviewCrop4To3:{
            relativePoint = CGPointMake(point.x / captorSize.width, point.y / captorSize.height);
        }

            break;
        case kVideoCameraPreviewCrop16To9:{
            // 竖
            relativePoint = CGPointMake(point.x / captorSize.width, point.y / captorSize.height);
        }

            break;
        case kVideoCameraPreviewCrop235To1:{
            // 横 9:16
            truePosition = CGPointMake(point.x, (SCREEN_HEIGHT - (SCREEN_WIDTH/16*9))/2 + point.y);
            relativePoint = CGPointMake(truePosition.x / captorSize.width, truePosition.y / captorSize.height);
        }
            
            break;
        case kVideoCameraPreviewCrop9To16:{
            // 横 9:16
            truePosition = CGPointMake(point.x, (SCREEN_HEIGHT - (SCREEN_WIDTH/16*9))/2 + point.y);
            relativePoint = CGPointMake(truePosition.x / captorSize.width, truePosition.y / captorSize.height);
        }

            break;
        default:
            break;
    }
//    NSLog(@"relative = %@",NSStringFromCGPoint(relativePoint));
    return relativePoint;
}

#pragma mark - OIMediaCaptorDelegate

// 输出video视频的sampleBuffer
// 这里静态图Photos拍摄时拿到的是1000 x 750，而视频拿到的则是原尺寸
- (void)captorWillOutputVideoSampleBuffer:(CMSampleBufferRef)sampleBuffer {
    BOOL enable = YES;
    if (self.mediaCaptor.outputFrame.size.width == 0) {
        enable = NO;
    } else if (!(self.mediaCaptor.outputFrame.size.width == SCREEN_WIDTH*Adjust_ScreenScale || self.mediaCaptor.outputFrame.size.width == self.presetManager.cameraOutputSize.width)) {
        enable = NO;
    }
    
    if (self.mediaCaptor.enabled != enable) {
        self.mediaCaptor.enabled = enable;
    }
//    if (_isRecordingVideo) {
//        NSLog(@"video = %f", CMTimeGetSeconds(CMSampleBufferGetPresentationTimeStamp(sampleBuffer)));
//    }
}

// 输出video音频的sampleBuffer
- (void)captorWillOutputAudioSampleBuffer:(CMSampleBufferRef)sampleBuffer {
    if (self.isRecordingVideo) {
        [self.videoAudioWriter writeWithAudioSampleBuffer:sampleBuffer]; // 写入音频
    }
}

#pragma mark - Getter

- (UIView *)shutterView {
    if (!_shutterView) {
        _shutterView = [[UIView alloc] initWithFrame:self.bounds];
        _shutterView.backgroundColor = [UIColor blackColor];
        _shutterView.alpha = 0.0;
    }
    return _shutterView;
}

- (void)shutterAnimation {
    [UIView animateWithDuration:0.25 animations:^{
        self.shutterView.alpha = 1.0;
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:0.20 animations:^{
            self.shutterView.alpha = 0.0;
        }];
    }];
}

- (UIVisualEffectView *)visualView {
    if (!_visualView) {
        _visualView = [[UIVisualEffectView alloc] initWithEffect:[UIBlurEffect effectWithStyle:UIBlurEffectStyleLight]];
        _visualView.frame = self.bounds;
        _visualView.alpha = 0;
    }
    return _visualView;
}

- (CameraVideoPresetManager *)presetManager {
    if (!_presetManager) {
        _presetManager = [CameraVideoPresetManager defaultPresetManager];
    }
    return _presetManager;
}

#pragma mark - Dealloc

- (void)dealloc {
    [self stopSwitchingAnimationUsingCADisplayLink];
    
    [self.mediaCaptor stopRunning];
    self.mediaCaptor.delegate = nil;
    [self.mediaCaptor removeAllConsumers];
}


@end
