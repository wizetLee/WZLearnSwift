//
//  VideoCameraPreviewView.h
//  POCONewCamera
//
//  Created by 陈弢 on 2017/6/6.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <OpenGLESImage/OpenGLESImage.h>

// 镜头录制逻辑
/*
 预览:
 VideoDataOutput -> 滤镜Filter -> 空滤镜A负责裁剪比例 -> 空滤镜B负责调整位置 -> OIView渲染
 录制:
 VideoDataOutput -> 滤镜Filter -> 空滤镜A负责裁剪比例 -> AssertWriter录制
 拍照:
 StillImageOutput -> 滤镜Filter -> 空滤镜A负责裁剪比例 -> Buffer获取图片
 */

// 拍摄模式
typedef NS_ENUM(NSInteger, VideoCameraMode) {
    kVideoCameraModeStillImage, // 静态图
    kVideoCameraModeVideo,      // 录像
};

// 镜头方向
typedef NS_ENUM(NSInteger, VideoCameraPosition) {
    kVideoCameraPositionBack,   // 后置(Default)
    kVideoCameraPositionFront,  // 前置
};

// 比例 : 宽高比
typedef NS_ENUM(NSInteger, VideoCameraPreviewCrop) {
    // photo
    kVideoCameraPreviewPhotoCrop1To1,
    kVideoCameraPreviewPhotoCrop3To4,
    kVideoCameraPreviewPhotoCrop9To16,
    
    // video
    kVideoCameraPreviewVideoCrop1To1,
    kVideoCameraPreviewVideoCrop9To16,
    kVideoCameraPreviewVideoCrop16To9,
    kVideoCameraPreviewVideoCrop235To1,
    
    kVideoCameraPreviewCrop1To1,   // 1:1,    静态与录像
    kVideoCameraPreviewCrop16To9,  // 16:9,   静态与录像
    kVideoCameraPreviewCrop4To3,   // 4:3,    静态only
    kVideoCameraPreviewCrop235To1, // 2.35:1, 视频only
    kVideoCameraPreviewCrop9To16   // 9:16,   视频only
};



// 闪光灯
typedef NS_ENUM(NSInteger, VideoCameraViewFlashMode) {
    kVideoCameraViewFlashModeAuto,        // 自动
    kVideoCameraViewFlashModeEnabled,     // 开启
    kVideoCameraViewFlashModeDisenabled   // 关闭(Default)
};

// 方向
typedef NS_ENUM(NSInteger, VideoCameraViewOrientationMode) {
    kVideoCameraViewOrientationModePortrait,    //
    kVideoCameraViewOrientationModeUpSideDown,
    kVideoCameraViewOrientationModeLeft,
    kVideoCameraViewOrientationModeRight
};

// 相机样式
typedef NS_ENUM(NSInteger, InterPhotoCameraPreviewType) {
    kInterPhotoCameraPreviewTypeNormal,
    kInterPhotoCameraPreviewTypePhotoOnly,
    kInterPhotoCameraPreviewTypeVideoOnly,
};



@protocol VideoCameraPreviewViewDelegate <NSObject>

- (void)videoCameraFinishRecordVideo:(NSURL *)finishURL;
//- (void)videoCameraFinishRecordVideo:(NSURL *)finishURL andRecordFilter:(NSDictionary *)recordFilter;

- (void)previewAdjustFrame:(CGRect)previewFrame;

- (void)previewStartRecordingVideo:(BOOL)finish;
//- (void)videoCameraSaveAlbumFinish:(NSString *)localIdentifier;

@end


@interface VideoCameraPreviewView : UIView

@property (nonatomic, assign) InterPhotoCameraPreviewType cameraType;

- (instancetype)initWithFrame:(CGRect)frame andCameraType:(InterPhotoCameraPreviewType)cameraType;

@property (nonatomic, weak) id<VideoCameraPreviewViewDelegate> delegate;
// ---设置---

// 切换前后置
- (void)switchCameraPosition;
@property (nonatomic, assign) VideoCameraPosition cameraPosition;
// 切换 拍照/录像
- (void)switchCameraMode;
@property (nonatomic, assign) VideoCameraMode cameraMode;
// 设置裁剪尺寸
@property (nonatomic, assign) VideoCameraPreviewCrop previewCrop;
// 设置闪光灯模式
@property (nonatomic, assign) VideoCameraViewFlashMode flashMode;

@property (nonatomic, strong) OIMediaCaptor *mediaCaptor; // 镜头
// 正在拍摄视频
@property (nonatomic, assign, readonly) BOOL isRecordingVideo;

// 拍摄视频时的设备方向
// (不靠谱，已废弃)
//@property (nonatomic, assign) UIDeviceOrientation recordVideoOrientation;

// 曝光、焦点
// 点击屏幕改变聚焦和曝光点
//- (void)moveExposurePointerToPoint:(CGPoint)point;
// 移动动屏幕改变聚焦和曝光点
//- (void)panExposurePointerToPoint:(CGPoint)point;
- (void)changeExposurePointerToPoint:(CGPoint)point; // 曝光点
- (void)changeFocusPointerToPoint:(CGPoint)point;    // 聚焦点

// 触屏拍照
//- (void)moveExposurePointerToPoint:(CGPoint)point andTakeStillImageWithCompletion:(void (^)(UIImage *processImage, NSDictionary *metadata))completion;

// 设置页面随着设备方向改动的旋转
- (void)setCameraPreviewOrientation:(VideoCameraViewOrientationMode)orientationMode;
// 镜头缩放
- (void)cameraRampToVideoZoomFactor:(CGFloat)factor withRate:(float)rate; // 调整镜头缩放

// 滤镜
//- (void)setFilterAlpha:(CGFloat)alpha;              // 滤镜透明度，0~1
- (void)setFilter:(OIFilter *)inpFilter;            // 直接设置印象滤镜
// 滤镜切换
- (void)setRightFilter:(OIFilter *)rightFilter; // 右边切换滤镜
- (void)setLeftFilter:(OIFilter *)leftFilter;   // 左边切换滤镜
// 结束当前滤镜切换
- (void)didEndFilterChoosingWithPercent:(CGFloat)percent resume:(BOOL)isResume;

// 控制镜头运行(未必用得上)
- (void)startCameraRunning;
- (void)stopCameraRunning;

// 停止用来控制进度的timer
- (void)stopSwichingTimer;

// 拍照(静态图)
- (void)takeStillImagePhotoWithCompletion:(void (^)(UIImage *processImage, NSDictionary *metadata))completion;
// 开始录像
- (void)startRecordVideo;
// 取消视频拍摄
- (void)cancelRecordVideo;
- (void)startRecordVideoWithOrientation:(AVCaptureVideoOrientation)orientation;
// 结束录像(回调拍好的URL)
- (void)finishRecordVideo;


- (void)saveRecordedVideo:(void(^)(bool isSaved))saveBlock;

- (void)setSwitchFilterWithPercent:(CGFloat)percent;

@end
