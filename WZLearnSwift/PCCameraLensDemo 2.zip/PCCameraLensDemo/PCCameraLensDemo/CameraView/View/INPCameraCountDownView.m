//
//  INPCameraCountDownView.m
//  POCONewCamera
//
//  Created by 紫秋 刘 on 2017/7/7.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import "INPCameraCountDownView.h"
#import <AVFoundation/AVAudioPlayer.h>

@interface INPCameraCountDownView ()

@property (nonatomic,strong)NSTimer *timer;
@property (nonatomic,strong)UILabel *countLabel;
@property (nonatomic,assign)int count;
@property (nonatomic,strong)AVAudioPlayer *soundPlayer;
@end

@implementation INPCameraCountDownView

- (instancetype)initWithCountDownTime:(NSTimeInterval)seconds{
    
    self = [super initWithFrame:[UIScreen mainScreen].bounds];
    
    self.count = (int)seconds;
    self.countLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, [UIScreen mainScreen].bounds.size.height / 4, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height * 0.5)];
    self.countLabel.font = [UIFont systemFontOfSize:50 ];
    self.countLabel.text = [NSString stringWithFormat:@"%d",self.count];
    self.countLabel.textColor = [UIColor whiteColor];
    self.countLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:self.countLabel];
    
    self.timer =[NSTimer scheduledTimerWithTimeInterval:1.0f
                                     target:self
                                   selector:@selector(countDownTime)
                                   userInfo:nil
                                    repeats:YES];
    
    [UIView animateWithDuration:0.98 animations:^{
        
       // self.countLabel.transform = CGAffineTransformMakeScale(0.1, 0.1);
        self.countLabel.alpha = 0;
        
    }];
    
    
    bool shouldPlayCountingDownSound = [[NSUserDefaults standardUserDefaults] boolForKey:@"sec"];
    
    
    if(shouldPlayCountingDownSound){
        if (!_soundPlayer) {
            NSString *soundFilePath = @"";//ResourcePath(@"tickta", @"wav");
            NSURL *soundFileURL = [[NSURL alloc] initFileURLWithPath:soundFilePath];
            
            if (soundFileURL) {
                _soundPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:soundFileURL error:nil];
            }
        }
        [_soundPlayer prepareToPlay];
        _soundPlayer.volume = 0.5;
        [_soundPlayer play];
        
    }
    
    


    return self;

}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self cancelCountDown];
}

- (void)cancelCountDown {
    // 点击取消倒计时
    [self.timer invalidate];
    self.timer = nil;
    
    if ([self.delegate respondsToSelector:@selector(cancelCountDownTimeUp)]) {
        [self.delegate cancelCountDownTimeUp];
    }
}

- (void)countDownTime{

    self.count--;
    
    self.countLabel.text = [NSString stringWithFormat:@"%d",self.count];
    self.countLabel.alpha = 1;
   
    if(self.count == 0){
        
        if (_soundPlayer) {
            if (_soundPlayer.isPlaying) {
                [_soundPlayer stop];
            }
            _soundPlayer = nil;
        }
        
        [self.timer invalidate];
        self.timer = nil;
        
        if([self.delegate respondsToSelector:@selector(countDownTimeup)]){
            
            [self.delegate countDownTimeup];
        }
        
    }else{
        
        
        if(_soundPlayer){
            
            [_soundPlayer prepareToPlay];
            [_soundPlayer play];
        }
        
        [UIView animateWithDuration:0.98 animations:^{
            
            self.countLabel.alpha = 0;
            
        }];
        
    }
    

    
}


@end
