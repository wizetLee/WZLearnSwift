//
//  INPVideoCameraFilterView.m
//  POCONewCamera
//
//  Created by 陈弢 on 2017/6/20.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import "INPVideoCameraFilterView.h"

// 滤镜数据库及模型
#import "FilterDBManager.h"
#import "FilterDownloadManager.h"
#import "NewFilterModel.h"
#import "LightModel.h"
#import "FilterCollectionViewCell.h" // cell
#import "ThemeData.h"
#import "ThemeDownloadManager.h"
#import "ThemeModel.h"

#import "MaterialCenterListViewController.h"
#import "MaterialCenterDetailViewController.h"

#import "INPCameraFilterModel.h"
#import "FilterSliderView.h" // 透明度杆

#import "FilterMasterIntroductionView.h" // 大师页
#import "ColorImageParam.h"

#import "INPFilterCountNumber.h"

#import "ShareMainViewController.h" // 分享

#define OriginalModel @"原图"

//NSString *const INPVideoCameraFilterViewOpenRecommendNotification = @"INPVideoCameraFilterViewOpenRecommendNotification";
NSString *const INPVideoCameraFilterViewEnterMaterialCenterNotification = @"INPVideoCameraFilterViewEnterMaterialCenterNotification";

@interface INPVideoCameraFilterView()<UICollectionViewDelegate, UICollectionViewDataSource, FilterSliderViewDelegate,FilterCollectionViewCellDelegate, FilterSliderViewDelegate, shareMainviewDelegate> {
    int filterIndex;
}

@property (nonatomic, strong) NSArray *filterList;
@property (nonatomic, strong) FilterCollectionViewCell *currentCell;
// 镜头滤镜model
@property (nonatomic, strong) INPCameraFilterModel *cameraFilterModel;
// 大师页
@property (nonatomic, strong) FilterMasterIntroductionView *introductionView;
@property (nonatomic, weak) FilterCollectionViewCell *introductionCell;

// UI
@property (nonatomic, strong) FilterSliderView *filterSliderView;
@property (nonatomic, strong) UICollectionView *listCollectionView;
@property (nonatomic, strong) UIButton *bottomLeaveButton;
@property (nonatomic, assign, readwrite) BOOL alphaAdjusting;

@property (nonatomic, copy) NSString *selectedId;

@property (nonatomic, assign) BOOL isOutsideSwipe; // 外部操作的选择

// 分享
@property (nonatomic, strong) ShareMainViewController *shareVC;
@property (nonatomic, strong) UIView *shareDismissView;
@property (nonatomic, weak) UIVisualEffectView *shareVisualEffectView;

@end


@implementation INPVideoCameraFilterView

static NSString *const CellReuseID = @"VideoCollectionViewCellReuseID";

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        filterIndex = 0;
        [self createUI];
        [self addNotificatoin];
    }
    return self;
}

- (UIImage *)getImageWithLink:(NSString *)link {
    UIImage *image = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:link ofType:nil]];
    if (!image) {
        NSString *path = [FilterDownloadManager pathWithLink:link];
        image = [UIImage imageWithContentsOfFile:path];
    }
    return image;
}

#pragma mark - Public Method IndexPath

- (void)currentIndexPathReduction {
    if (self.currentIndexPath.item < 1) {
        return;
    }
    NSIndexPath *reducationIndexPath = [NSIndexPath indexPathForItem:self.currentIndexPath.item-1 inSection:0];
//    NSLog(@"恢复indexpath(减少)- %ld",reducationIndexPath.item);
    
    FilterCollectionViewCell *oldCell = (FilterCollectionViewCell *)[self.listCollectionView cellForItemAtIndexPath:self.currentIndexPath];
    [oldCell setRearrangeable_selectedWithAnimated:NO];
    self.currentIndexPath = reducationIndexPath;
    FilterCollectionViewCell *newCell = (FilterCollectionViewCell *)[self.listCollectionView cellForItemAtIndexPath:self.currentIndexPath];
    [newCell setRearrangeable_selectedWithAnimated:YES];
}

- (void)currentIndexPathIncrease {
    if (self.currentIndexPath.item > self.filterList.count - 2) {
        return;
    }
    NSIndexPath *increaseIndexPath = [NSIndexPath indexPathForItem:self.currentIndexPath.item+1 inSection:0];
//    NSLog(@"恢复indexpath(增加)- %ld",increaseIndexPath.item);
    
    FilterCollectionViewCell *oldCell = (FilterCollectionViewCell *)[self.listCollectionView cellForItemAtIndexPath:self.currentIndexPath];
    [oldCell setRearrangeable_selectedWithAnimated:NO];
    self.currentIndexPath = increaseIndexPath;
    FilterCollectionViewCell *newCell = (FilterCollectionViewCell *)[self.listCollectionView cellForItemAtIndexPath:self.currentIndexPath];
    [newCell setRearrangeable_selectedWithAnimated:YES];
}

- (void)selectColorFilterWithColorId:(NSString *)colorId {
    if (!colorId) {
        return;
    }
    
    for (int index = 0; index < self.filterList.count; index++) {
        id obj = self.filterList[index];
        if ([obj isKindOfClass:[NewFilterModel class]]) {
            NewFilterModel *model = (NewFilterModel *)obj;
            if ([model.colorID isEqualToString:colorId]) {
                NSIndexPath *selectIndexPath = [NSIndexPath indexPathForItem:index inSection:0];
                [self collectionView:self.listCollectionView didSelectItemAtIndexPath:selectIndexPath];
            }
        }
    }
}

#pragma mark - 通知

- (void)addNotificatoin {
    // 滤镜下载成功，修改data
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(obserdveVideoCameraFilterDownloadFilterNotification:) name:kSLDownloadFilterNotifySucceed object:nil];
    // 立即使用通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(observeVideoCameraFilterUseSpecifiedFilterRightNow:) name:kSNoneMaterialCenterEnterFilterNotify object:nil];
    // 素材管理页 隐藏/开启 滤镜
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(obsertveMaterialCenterManageStateDidChange:) name:MATERIALCENTER_MANAGESTATE_DIDCHANGE object:nil];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSLDownloadFilterNotifySucceed object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSNoneMaterialCenterEnterFilterNotify object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MATERIALCENTER_MANAGESTATE_DIDCHANGE object:nil];
}

#pragma mark 通知回调

- (void)obserdveVideoCameraFilterDownloadFilterNotification:(NSNotification *)notification {
    _filterList = nil;
    [self.listCollectionView reloadData];
}

- (void)observeVideoCameraFilterUseSpecifiedFilterRightNow:(NSNotification *)notification {
    BSModel *bsModel = [BSObject shareInstant].currentModel;
    
    if (!bsModel) {
        bsModel = notification.object;
    }
    
    // 改成遍历ids数组
    if (bsModel) {
        NSArray *idsArray = bsModel.bsChooseIDs;
        
        for (NSString *bsChooseID in idsArray) {
            for (int i = 0; i < self.filterList.count; i++) {
                id model = self.filterList[i];
                if ([model isKindOfClass:[NewFilterModel class]]) {
                    NewFilterModel *filterModel = (NewFilterModel *)model;
                    if ([filterModel.colorID isEqualToString:bsChooseID]) {
                        self.currentIndexPath = nil;
                        NSIndexPath *indexPath = [NSIndexPath indexPathForItem:i inSection:0];
                        self.isOutsideSwipe = NO;
                        [self collectionView:self.listCollectionView didSelectItemAtIndexPath:indexPath];
                        [BSObject shareInstant].currentModel = nil;
                        return;
                    }
                }
            }
        }
    }
}

// 刷新素材中心
- (void)obsertveMaterialCenterManageStateDidChange:(NSNotification *)notification {
    if ([[notification.userInfo valueForKey:@"id"] isEqualToString:self.selectedId]) {
        NSIndexPath *originIndexPath = [NSIndexPath indexPathForItem:0 inSection:0];
        [self collectionView:self.listCollectionView didSelectItemAtIndexPath:originIndexPath];
    }
    
    self.filterList = nil;
    [self.listCollectionView reloadData];
}

#pragma mark - Private Method

#pragma mark UI

- (void)createUI {
    // 添加高斯模糊背景
    [self addVisualBackgroundView];
    // 滑动杆
    [self addSubview:self.filterSliderView];
    // 底部按钮
    [self addSubview:self.bottomLeaveButton];
    // 分割线
    [self addSeparatedLine];
    // 列表
    [self addSubview:self.listCollectionView];
}

- (void)addVisualBackgroundView {
    UIBlurEffect *effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    UIView *backgroundView = [[UIVisualEffectView alloc] initWithEffect:effect];
    backgroundView.frame = self.bounds;
    [self addSubview:backgroundView];
}

- (void)addSeparatedLine {
    UIView *separatedLine = [[UIView alloc] initWithFrame:CGRectMake(0, self.frame.size.height - 20 * 1, SCREEN_WIDTH, 1 * 1)];
    separatedLine.backgroundColor = COLOR_RGBA_255(39, 39, 39, 1.0);
    [self addSubview:separatedLine];
}

#pragma mark - CollectionView Cell Delegate

- (void)collectionViewCellTapAuthorImageView:(FilterCollectionViewCell *)cell {
    NSIndexPath *indexPath = [self.listCollectionView indexPathForCell:cell];
    NewFilterModel *model = self.filterList[indexPath.item];
    /*设定大师页数据*/
    self.introductionView.authorName.text = model.colorIntroductionAuthor;
    self.introductionView.authorDescription.text = model.colorIntroductionAuthorTitle;
    
    NSString *detail = [model.colorIntroductionDetail stringByReplacingOccurrencesOfString:@"&lt;br rel=auto&gt;" withString:@"\n"];
    self.introductionView.authorThemeDescription.text = detail;
    
    self.introductionView.authorImage.image = [self getImageWithLink:model.colorAuthorImage];
    self.introductionView.mainImageView.image = [self getImageWithLink:model.colorCoverImage];
    // 加载Webview
    NSURL *url = [NSURL URLWithString:model.colorIntroductionURL];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [self.introductionView.introductionWebView loadRequest:request];
    
    self.introductionCell = cell;
    [cell setHidden:YES];
    [self.superview addSubview:self.introductionView];
    // 获取当前cell的CGRect
    CGRect cellRectOnCell = [self.listCollectionView convertRect:cell.thumbnailImageView.frame fromView:cell];
    CGRect cellRectOnSelfView = [self convertRect:cellRectOnCell fromView:self.listCollectionView];
    CGRect cellRect = [self.superview convertRect:cellRectOnSelfView fromView:self];
    
    if (model.colorUnlockShareLink) {
        self.introductionView.shareIntroductionButton.hidden = NO;
    } else {
        self.introductionView.shareIntroductionButton.hidden = YES;
    }
    
    // 开始动画
    __weak INPVideoCameraFilterView *weakSelf = self;
    [self.introductionView openIntroductionWithRect:cellRect andCloseAnimationWithClose:^{
        weakSelf.introductionCell.hidden = NO;
        weakSelf.introductionCell = nil; // 复位弱指针
        [weakSelf.introductionView removeFromSuperview];
        weakSelf.introductionView = nil; // 释放大师页内存
    } andUnlockAnimationWithUnlock:^{
    } andShareBlock:^{
        ShareInfo *info = [[ShareInfo alloc] init];
        [[CLReporting sharedInstance] pushEvent:kFilterCountIndexOfMasterIntroductionShare paraString:nil];
        info.shareURL = model.colorUnlockShareLink;
        info.mediaType = ShareTextWeb;
        info.shareContent = model.colorUnlockWeixinTitle;
        info.wxTimelineTitle = model.colorUnlockWeixinTitle;
        info.wxTitle = model.colorUnlockWeixinTitle;
        //info.imagePath = [self getImagePathWithLink:model.colorAuthorImage];
        
        if (isUsableNSString(model.colorUnlockWeixinImage, @"")) {
            info.imagePath = [self getImagePathWithLink:model.colorUnlockWeixinImage];
        } else {
            info.imagePath = [self getImagePathWithLink:model.colorAuthorImage];
        }
        
        
        self.shareVC = [[ShareMainViewController alloc] initForIntroductionShareWithShareInfo:info];
        self.shareVC.delegate = self;
        [self.superview addSubview:self.shareVC.view];
        [self.introductionView addSubview:self.shareDismissView];
        // do the share
        CGRect introductionFrame = self.introductionView.frame;
        CGRect shareFrame = self.shareVC.view.frame;
        
        introductionFrame = CGRectMake(introductionFrame.origin.x, introductionFrame.origin.y + 115 * 1, introductionFrame.size.width, introductionFrame.size.height);
        shareFrame = CGRectMake(shareFrame.origin.x, shareFrame.origin.y + 115 * 1, shareFrame.size.width, shareFrame.size.height);
        
        [UIView animateWithDuration:0.2 animations:^{
            self.introductionView.frame = introductionFrame;
            self.shareVC.view.frame = shareFrame;
            self.shareVisualEffectView.alpha = 1.0;
        } completion:^(BOOL finished) {
            //
        }];
    }];
}

- (NSString *)getImagePathWithLink:(NSString *)link {
    UIImage *image = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:link ofType:nil]];
    if (image) {
        return [[NSBundle mainBundle] pathForResource:link ofType:nil];
    } else {
        return [FilterDownloadManager pathWithLink:link];
    }
}

- (void)shareMainViewShouldDismiss {
    [self pressShareDismiss];
}

- (void)pressShareDismiss {
    // do the share
    CGRect introductionFrame = self.introductionView.frame;
    CGRect shareFrame = self.shareVC.view.frame;
    
    introductionFrame = CGRectMake(introductionFrame.origin.x, introductionFrame.origin.y - 115*1, introductionFrame.size.width, introductionFrame.size.height);
    shareFrame = CGRectMake(shareFrame.origin.x, shareFrame.origin.y - 115*1, shareFrame.size.width, shareFrame.size.height);
    
    [UIView animateWithDuration:0.2 animations:^{
        self.shareVC.view.frame = shareFrame;
        self.introductionView.frame = introductionFrame;
        self.shareVisualEffectView.alpha = 0.0;
    } completion:^(BOOL finished) {
        [self.shareDismissView removeFromSuperview];
        self.shareDismissView = nil;
        
        [self.shareVC.view removeFromSuperview];
        self.shareVC = nil;
    }];
}

#pragma mark - Action

- (void)videoCameraViewPressLeave:(UIButton *)button {
    if ([self.delegate respondsToSelector:@selector(videoCameraVideoLeave)]) {
        [self.delegate videoCameraVideoLeave];
    }
}

#pragma mark - FilterSliderDelegate

- (void)filterSliderViewValueChange:(FilterSliderView *)filterSliderView {
    [self adjustOIFilterAlpha:filterSliderView.value];
}

- (void)filterSliderViewTouchUpInside:(FilterSliderView *)filterSliderView {
    [self adjustOIFilterAlpha:filterSliderView.value];
}

#pragma mark - Public Method

- (void)selectItemAtIndexPath:(NSIndexPath *)indexPath {
    self.isOutsideSwipe = YES;
    [self collectionView:self.listCollectionView didSelectItemAtIndexPath:indexPath];
}

- (OIFilter *)getFilterBackWhenSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    self.isOutsideSwipe = YES;
    [self collectionView:self.listCollectionView didSelectItemAtIndexPath:indexPath];
    
    return self.currentFilter;
}

#pragma mark - ColectionView Delegate

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    FilterCollectionViewCell *collectionCell = [self.listCollectionView dequeueReusableCellWithReuseIdentifier:CellReuseID forIndexPath:indexPath];
    
    collectionCell.thumbnailImageView.contentMode = UIViewContentModeScaleAspectFill;
    collectionCell.style = InterPhotoCollectionViewCellStyleFilter;
    collectionCell.delegate = self;
    
    id obj = self.filterList[indexPath.item];
    if ([obj isKindOfClass:[ThemeModel class]]) {
        
        ThemeModel *themeModel = (ThemeModel *)obj;
        collectionCell.thumbnailImageView.image = [UIImage imageWithContentsOfFile:[ThemeDownloadManager pathWithLink:themeModel.thumnailImage]];
        collectionCell.filterStyle = kFilterCollectionViewCellStyleTheme;
        collectionCell.titlelabel.text = themeModel.subTitle;
        collectionCell.authorLabel.text = themeModel.masterName;
        NSArray *colors = [LightModel getColor:themeModel.titleColor];
        if (isUsableArray(colors, 0)) {
            collectionCell.coverColor = COLOR_RGBA_255([colors[0] intValue], [colors[1] intValue], [colors[2] intValue], 0.6);
        }
        collectionCell.rearrangeable_selected = NO;
    } else {
        
        NewFilterModel *filterModel = (NewFilterModel *)obj;
        
        if (indexPath.item == 0) {
            collectionCell.titlelabel.text = nil;
            collectionCell.authorImageView.image = nil;
            collectionCell.authorLabel.text = nil;
            collectionCell.thumbnailImageView.image = [self getImageWithLink:filterModel.colorThumbnailImage];
            collectionCell.filterStyle = kFilterCollectionViewCellStyleOriginal;
            collectionCell.coverColor = [UIColor clearColor];
            collectionCell.thumbnailImageView.contentMode = UIViewContentModeCenter;
            collectionCell.thumbnailImageView.backgroundColor = COLOR_RGBA_255(39, 39, 39, 1);
        } else {
            if ([filterModel.colorName isEqualToString:@"materialEnter"]) {
                //设置素材中心入口
                collectionCell.filterStyle = kFilterCollectionViewCellStyleDownloadMore;
                collectionCell.thumbnailImageView.backgroundColor = [UIColor clearColor];
                collectionCell.thumbnailImageView.image = nil;
            } else {
                collectionCell.authorImageView.image = [self getImageWithLink:filterModel.colorAuthorImage];
                collectionCell.authorLabel.text = filterModel.colorIntroductionAuthor;
                collectionCell.style = InterPhotoCollectionViewCellStyleFilter;
                collectionCell.thumbnailImageView.image = [self getImageWithLink:filterModel.colorThumbnailImage];
                collectionCell.titlelabel.text = filterModel.colorName;
                
                NSArray *colors = [LightModel getColor:filterModel.colorCoverColor];
                collectionCell.coverColor = COLOR_RGBA_255([colors[0] intValue], [colors[1] intValue], [colors[2] intValue], 0.6);
                collectionCell.filterStyle = [filterModel.colorMasterType integerValue] > 0 ? kFilterCollectionViewCellStyleMaster:kFilterCollectionViewCellStyleNormal;
            }
        }
        
        collectionCell.rearrangeable_selected = NO;
        if ([self.selectedId isEqualToString:filterModel.colorID]) {
            collectionCell.rearrangeable_selected = YES;
        }
    }
    
    return collectionCell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.item < 0 || indexPath.item > self.filterList.count-1) {
        return;
    }
    
    BOOL nextOrder = 0;
    if (self.currentIndexPath) {
        if (self.currentIndexPath.item < indexPath.item) {
            nextOrder = 1;
        }
    } else {
        nextOrder = 1;
    }
    
    FilterCollectionViewCell *cell = (FilterCollectionViewCell *)[collectionView cellForItemAtIndexPath:indexPath];
    OIFilter *filter = nil;
    
    // 主题
    id obj = self.filterList[indexPath.item];
    if ([obj isKindOfClass:[ThemeModel class]]) {
        if (self.isOutsideSwipe) {
            
            if (self.currentIndexPath == nil || indexPath.item > self.currentIndexPath.item) {
                NSIndexPath *newIndexPath = [NSIndexPath indexPathForItem:indexPath.item+1 inSection:0];
                [self selectItemAtIndexPath:newIndexPath];
            } else {
                if (indexPath.item > 0) {
                    NSIndexPath *newIndexPath = [NSIndexPath indexPathForItem:indexPath.item-1 inSection:0];
                    [self selectItemAtIndexPath:newIndexPath];
                }
            }
            
        } else {
            
            [self openRecommendDetailVC:obj andCell:cell];
        }
        
        return;
        
    }

    NewFilterModel *model = self.filterList[indexPath.item];
    
    if ([model.colorName isEqualToString:@"materialEnter"]) {
        MaterialCenterListViewController *materialCenterListVC = [[MaterialCenterListViewController alloc] init];
        materialCenterListVC.fromEnterance = MaterialCenterModuleTypeFilter;
        // 打开新控制器
        NSDictionary *userInfo = @{@"materialVC":materialCenterListVC};
        // 通知外面推出控制器
        [[NSNotificationCenter defaultCenter] postNotificationName:INPVideoCameraFilterViewEnterMaterialCenterNotification object:nil userInfo:userInfo];
        self.isOutsideSwipe = NO;
        
        return;
    }
    
    /*判断同一个cell*/
    if (cell.rearrangeable_selected == YES && indexPath.item != 0) {
        [self enterAlphaAdjusting];
        return;
    }
    
    [collectionView scrollToItemAtIndexPath:indexPath atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally animated:YES];
    /*判断点击状态*/
    if (self.alphaAdjusting) {
        [self performSelector:@selector(enterAlphaAdjusting) withObject:nil afterDelay:0.3];
    }
    
    /*标记当前选中cell的状态*/
    FilterCollectionViewCell *oldCell = (FilterCollectionViewCell *)[self.listCollectionView cellForItemAtIndexPath:self.currentIndexPath];
    [oldCell setRearrangeable_selectedWithAnimated:NO];
    [cell setRearrangeable_selectedWithAnimated:YES];
    self.currentIndexPath = indexPath;
    
    if (!oldCell) {
        NSArray *cells = [collectionView subviews];
        for (FilterCollectionViewCell *tmpCell in cells) {
            if (tmpCell != cell && [tmpCell isKindOfClass:[FilterCollectionViewCell class]]) {
                [tmpCell setRearrangeable_selectedWithAnimated:NO];
            }
        }
    }
    
    /*如果点击了原图,则返回原图*/
    if (indexPath.row == 0) {
        // 返回OIFilter
        filter = [[OIFilter alloc] init];
    } else {
        [[CLReporting sharedInstance] pushEvent:[model.colorStatisticalID intValue] paraString:nil];
        filter = [INPCameraFilterModel getFilterWithFilterColorDic:model.colorFilter];
        if (!filter) {
            filter = [[OIFilter alloc] init];
        }
    }
    // 此处是1.4.0由于无法添加黑白滤镜的字段，经协商决定此版本只记录这四个黑白滤镜
    if ([model.colorName isEqualToString:@"Super Stone"] ||
        [model.colorName isEqualToString:@"一刻"] ||
        [model.colorName isEqualToString:@"Leslie"] ||
        [model.colorName isEqualToString:@"独白"]) {
        OILookUpTableFilter *blackFilter = (OILookUpTableFilter *)filter;
        blackFilter.isBlackWhiteFilter = YES;
    }
    
    self.selectedId = model.colorID;
    
    CGFloat colorAlpha;
    // 透明度
    if ([model.colorName isEqualToString:@"Coast"]) {
        colorAlpha = 1.0;
    } else {
        colorAlpha = [model.colorAlpha floatValue] / 100.0;
    }
    self.filterSliderView.value = colorAlpha;
    self.currentFilter = filter;
    [self adjustOIFilterAlpha:colorAlpha];
    
    // 获取缩略图
    if ([self.delegate respondsToSelector:@selector(videoCameraVideoFilterGetThumbnailImage: andCoverColor: colorId:)]) {
        UIImage *thumbnail = [self getImageWithLink:model.colorThumbnailImage];
        if (indexPath.item == 0) {
            [self.delegate videoCameraVideoFilterGetThumbnailImage:nil andCoverColor:nil colorId:nil];
        } else {
            [self.delegate videoCameraVideoFilterGetThumbnailImage:thumbnail andCoverColor:[LightModel getColor:model.colorCoverColor] colorId:model.colorID];
        }
    }
    
    if (self.isOutsideSwipe) {
        if ([self.delegate respondsToSelector:@selector(videoCameraVideoFilterViewDidChangeNextFilter:withOrder:)]) {
            [self.delegate videoCameraVideoFilterViewDidChangeNextFilter:filter withOrder:nextOrder];
        }
    } else {
        if ([self.delegate respondsToSelector:@selector(videoCameraVideoFilterViewDidChangeFilter:)]) {
            [self.delegate videoCameraVideoFilterViewDidChangeFilter:filter];
        }
    }
    
    if (self.openMultipeFilterSwitchingEffect) {
        filterIndex++;
    }
    
    self.isOutsideSwipe = NO;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.filterList.count;
}

#pragma mark - Private Method

#pragma mark 推荐页通知


#pragma mark 打开推荐页

- (void)openRecommendDetailVC:(id)obj andCell:(FilterCollectionViewCell *)cell {
    
    __block UIView *coverView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    coverView.backgroundColor = [UIColor clearColor];
//    [manageVC.view addSubview:coverView];
    [self.superview addSubview:coverView];
    
    __block MaterialCenterDetailViewController *detailVC = [[MaterialCenterDetailViewController alloc] init];
    detailVC.themeModel = (ThemeModel *)obj;
    detailVC.isMaterailCenterEnter = NO;
    detailVC.isRecommendEnter = YES;
    detailVC.superViewController = self;
    cell.hidden = YES;
    
//    self.materialDetailVC = detailVC;
    // 获取当前cell的CGRect
    CGRect cellRectOnCell = [self.listCollectionView convertRect:cell.thumbnailImageView.frame fromView:cell];
    CGRect cellRectOnSelfView = [self convertRect:cellRectOnCell fromView:self.listCollectionView];
    CGRect cellRect = [self.superview convertRect:cellRectOnSelfView fromView:self];
    
    [self.superview addSubview:detailVC.view];
    
    [detailVC beginAnimationWith:cellRect withCloskBlock:^{
        [coverView removeFromSuperview];
        cell.hidden = NO;
//        self.materialDetailVC = nil;
        detailVC = nil;
    }];;
}

#pragma mark 显示/隐藏滑竿
- (void)enterAlphaAdjusting {
    if (!self.alphaAdjusting) {
        
        // 统计
        [[CLReporting sharedInstance] pushEvent:kCameraCountIndexOfFilterAlpha paraString:nil];
        
        [UIView animateWithDuration:0.2 animations:^{
            self.listCollectionView.transform = CGAffineTransformMakeTranslation(0, 55.0 * 1);
            self.filterSliderView.alpha = 1.0;
        } completion:^(BOOL finished) {
            self.alphaAdjusting = YES;
//            self.filterSliderView.hidden = NO;
        }];
    } else {
        [UIView animateWithDuration:0.2 animations:^{
            self.listCollectionView.transform = CGAffineTransformIdentity;
            self.filterSliderView.alpha = 0.0;
        } completion:^(BOOL finished) {
//            self.filterSliderView.hidden = YES;
            self.alphaAdjusting = NO;
        }];
    }
}

#pragma mark 原图模型
- (NSMutableArray *)addOriginalModel:(NSMutableArray *)models {
    NewFilterModel *model = [[NewFilterModel alloc] init];
    model.colorName = OriginalModel;
    model.colorThumbnailImage = @"D1_No@2x.png"; // 24*24
    [models insertObject:model atIndex:0];
    return models;
}

#pragma mark 调节filter的透明度

- (void)adjustOIFilterAlpha:(CGFloat)alpha {
    if ([self.currentFilter isKindOfClass:[OILookUpTableFilter class]]) {
        ((OILookUpTableFilter *)self.currentFilter).intensity = alpha;
    } else if ([self.currentFilter isKindOfClass:[OIMultipleBlendFilter class]]) {
        ((OIMultipleBlendFilter *)self.currentFilter).intensity = alpha;
    } else if ([self.currentFilter isKindOfClass:[OILookUpMultipleBlendFilter class]]) {
        ((OILookUpMultipleBlendFilter *)self.currentFilter).intensity = alpha;
    }
}

#pragma mark - Getter

// 列表UI
- (UICollectionView *)listCollectionView {
    if (!_listCollectionView) {
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        layout.itemSize = CGSizeMake(80.0 * 1, 87.5 * 1);
        layout.minimumLineSpacing = 0.0;
        layout.minimumInteritemSpacing = 10.0;
        layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        
        _listCollectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 87.5 * 1) collectionViewLayout:layout];
        _listCollectionView.contentInset = UIEdgeInsetsMake(0, 0, 0, -15 * 1);
        _listCollectionView.backgroundColor = [UIColor clearColor];
        _listCollectionView.showsHorizontalScrollIndicator = NO;
        _listCollectionView.delegate = self;
        _listCollectionView.dataSource = self;
        [_listCollectionView registerClass:[FilterCollectionViewCell class] forCellWithReuseIdentifier:CellReuseID];
    }
    return _listCollectionView;
}

// 离开按钮
- (UIButton *)bottomLeaveButton {
    if (!_bottomLeaveButton) {
        CGFloat buttonHeight = 20.0 * 1;
        _bottomLeaveButton = [[UIButton alloc] initWithFrame:CGRectMake(0, self.frame.size.height - buttonHeight, SCREEN_WIDTH, buttonHeight)];
        _bottomLeaveButton.backgroundColor = [UIColor clearColor];
        [_bottomLeaveButton setImage:[UIImage imageNamed:@"Filter_Adjust_leave.png"] forState:UIControlStateNormal];
        [_bottomLeaveButton addTarget:self action:@selector(videoCameraViewPressLeave:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _bottomLeaveButton;
}

// 印象滤镜的模型
- (INPCameraFilterModel *)cameraFilterModel {
    if (!_cameraFilterModel) {
        _cameraFilterModel = [[INPCameraFilterModel alloc] init];
    }
    return _cameraFilterModel;
}

// 滤镜数据
- (NSArray *)filterList {
    if (!_filterList) {
//        NSMutableArray *models = [NSMutableArray arrayWithArray:[FilterDBManager getFilterModelsNotHidden]];
        
        // 主题model
        NSMutableArray *themeModels = [NSMutableArray arrayWithArray:[ThemeData getFilterRecommendPositionThemeModels]];
        // 滤镜model
        NSMutableArray *filterModels = [NSMutableArray arrayWithArray:[FilterDBManager getFilterModelsNotHidden]]; // 滤镜model
        
        // 素材中心入口
        NewFilterModel *materialEnterInfo = [[NewFilterModel alloc] init];
        materialEnterInfo.colorName = @"materialEnter";
        [filterModels addObject:materialEnterInfo];
        
        [themeModels addObjectsFromArray:filterModels];
        
        _filterList = [self addOriginalModel:themeModels]; // 添加原图模型
    }
    return _filterList;
}

// 滑动条
- (FilterSliderView *)filterSliderView {
    if (!_filterSliderView) {
        _filterSliderView = [[FilterSliderView alloc] initWithFrame:CGRectMake(0, CGRectGetMinY(self.listCollectionView.frame), SCREEN_WIDTH, 70*1)];
        _filterSliderView.maxValue = 1.0;
        _filterSliderView.value = 1.0;
//        _filterSliderView.hidden = YES;
        _filterSliderView.alpha = 0.0;
        _filterSliderView.delegate = self;
    }
    return _filterSliderView;
}

// 大师页面
- (FilterMasterIntroductionView *)introductionView {
    if (!_introductionView) {
        _introductionView = [[[NSBundle mainBundle]loadNibNamed:@"FilterMasterIntroductionView" owner:self options:nil]firstObject];
        [_introductionView setFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
        //基础设定
        _introductionView.mainScrollView.scrollEnabled = NO;
        _introductionView.mainImageView.clipsToBounds = YES;
        _introductionView.mainImageView.layer.cornerRadius = 6.0;
        [_introductionView.mainBackgroundView setAlpha:0];
        [_introductionView.closeIntroductionButton setAlpha:0];
        [_introductionView.shareIntroductionButton setAlpha:0];
    }
    return _introductionView;
}

- (UIView *)shareDismissView {
    if (!_shareDismissView) {
        _shareDismissView = [[UIView alloc] initWithFrame:[UIScreen mainScreen].bounds];
        
        UIBlurEffect *blurEffect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
        UIVisualEffectView *effectView = [[UIVisualEffectView alloc] initWithEffect:blurEffect];
        self.shareVisualEffectView = effectView;
        effectView.alpha = 0.2;
        effectView.frame = _shareDismissView.bounds;
        [_shareDismissView addSubview:effectView];
        _shareDismissView.backgroundColor = [UIColor clearColor];
        
        if(!(IOS_VERSION_8_OR_ABOVE)){
            _shareDismissView.backgroundColor = [UIColor blackColor];
            _shareDismissView.alpha = 0.7;
        }
        UIButton *dismissBtn = [[UIButton alloc] initWithFrame:_shareDismissView.bounds];
        dismissBtn.backgroundColor = [UIColor clearColor];
        [dismissBtn addTarget:self action:@selector(pressShareDismiss) forControlEvents:UIControlEventTouchUpInside];
        [_shareDismissView addSubview:dismissBtn];
    }
    return _shareDismissView;
}

@end
