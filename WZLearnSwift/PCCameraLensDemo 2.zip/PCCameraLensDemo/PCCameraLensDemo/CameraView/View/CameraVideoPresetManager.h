//
//  CameraVideoPresetManager.h
//  POCONewCamera
//
//  Created by 陈弢 on 2017/7/10.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import "AlbumOperationFunction.h"
#import <UIKit/UIKit.h>

@interface CameraVideoPresetManager : NSObject

typedef NS_ENUM(NSUInteger, INPSessionPresetType) {
    INPSessionPresetType540,
    INPSessionPresetType720,
    INPSessionPresetType1080,
};

+ (instancetype)defaultPresetManager;

@property (nonatomic, assign) int maximumFrameRate;
@property (nonatomic, assign) CGSize cameraOutputSize;
@property (nonatomic, assign) CGSize maximumVideoSavingSize;

@property (nonatomic, assign) BOOL enableSmoothAutoFocus;
@property (nonatomic, assign) BOOL enableVideoStabilization;//防抖动
@property (nonatomic, assign) BOOL enableSwitchingFilterEffect;//选滤镜


@end
