//
//  VideoCameraSettingView.h
//  POCONewCamera
//
//  Created by 紫秋 刘 on 2017/6/7.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VideoCameraPreviewView.h"

@protocol VideoCameraSettingDelegate <NSObject>

@required
- (BOOL)videoSettingHasFlash;

@optional
- (void)shouldChangeScale:(VideoCameraPreviewCrop)sacle;
- (void)shouldChangeFlash:(VideoCameraViewFlashMode)flashMode;
- (void)shouldChangeShutTime:(NSTimeInterval)time;
- (void)shouldChangeTouchSceenEnable:(BOOL)enable;

@end

@interface VideoCameraSettingView : UIView

@property (nonatomic,weak)id<VideoCameraSettingDelegate>delegate;
@property (nonatomic,assign)VideoCameraMode shutterMode;//拍摄 图片 、视频
@property (nonatomic,assign)VideoCameraViewFlashMode flashType;
@property (nonatomic,assign)VideoCameraPreviewCrop scaleType;
@property (nonatomic,assign)NSInteger timerType;
@property (nonatomic,assign)bool  isTouchScreen;

- (instancetype)initWithFrame:(CGRect)frame withDelegate:(id)delegate;

// 设定view随着设备方向做出的旋转
- (void)setCameraSettingViewOrientation:(VideoCameraViewOrientationMode)orientationMode withAnimation:(BOOL)animated;

@end
