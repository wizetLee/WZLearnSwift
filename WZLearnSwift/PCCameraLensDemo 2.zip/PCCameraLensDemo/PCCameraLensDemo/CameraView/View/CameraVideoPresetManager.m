//
//  CameraVideoPresetManager.m
//  POCONewCamera
//
//  Created by 陈弢 on 2017/7/10.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import "CameraVideoPresetManager.h"




@implementation CameraVideoPresetManager


+ (instancetype)defaultPresetManager {
    CameraVideoPresetManager *presetManager = [[CameraVideoPresetManager alloc] init];
    
//    INPSessionPresetType presetType = [AlbumOperationFunction cameraVideoSessionPresetType];
    INPSessionPresetType presetType = INPSessionPresetType540;
    switch (presetType) {
        case INPSessionPresetType540:
            NSLog(@"preset540");
            presetManager.maximumFrameRate = 15;
            presetManager.cameraOutputSize = CGSizeMake(540.0, 960.0);
            presetManager.maximumVideoSavingSize = CGSizeMake(540.0, 960.0);
            presetManager.enableSmoothAutoFocus = NO;
            presetManager.enableVideoStabilization = NO;
            presetManager.enableSwitchingFilterEffect = NO;
            break;
        case INPSessionPresetType720:
            NSLog(@"preset720");
            presetManager.maximumFrameRate = 25;
            presetManager.cameraOutputSize = CGSizeMake(720.0, 1280.0);
            presetManager.maximumVideoSavingSize = CGSizeMake(720.0, 1280.0);
            presetManager.enableSmoothAutoFocus = YES;
            presetManager.enableVideoStabilization = YES;
            presetManager.enableSwitchingFilterEffect = YES;
            break;
        case INPSessionPresetType1080:
            NSLog(@"preset1080");
            presetManager.maximumFrameRate = 25;
            presetManager.cameraOutputSize = CGSizeMake(1080.0, 1920.0);
            presetManager.maximumVideoSavingSize = CGSizeMake(1080.0, 1920.0);
            presetManager.enableSmoothAutoFocus = YES;
            presetManager.enableVideoStabilization = YES;
            presetManager.enableSwitchingFilterEffect = YES;
            break;
    }
    
    return presetManager;
}

@end
