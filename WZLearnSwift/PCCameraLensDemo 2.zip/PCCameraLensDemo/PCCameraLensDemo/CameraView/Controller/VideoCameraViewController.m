//
//  VideoCameraViewController.m
//  POCONewCamera
//
//  Created by 陈弢 on 2017/5/16.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import "VideoCameraViewController.h"
#import <OpenGLESImage/OpenGLESImage.h>

//#import "OIVideoBrightnessFilter.h"

#import "VideoCameraOverlayView.h"
#import "VideoCameraPreviewView.h"
#import "VideoCameraSettingView.h"
//#import "VideoViewController.h"
//#import "INPVideoPickerViewController.h"
//#import "AlbumMainViewController.h"
//#import "MaterialCenterListViewController.h"
#import "INPCameraCountDownView.h"

//#import "UIImage+Clip.h"
//#import "UIImage+Resize.h"
//#import "AlbumOperationFunction.h"
#import <AssetsLibrary/AssetsLibrary.h>

//#import "SLDownloadHeader.h"

//#import "MPVolumeObserver.h"

@interface VideoCameraViewController ()<OIMediaCaptorDelegate, OIAudioVideoWriterDelegate, VideoCameraPreviewViewDelegate,VideoCameraOverlayDelegate,VideoCameraSettingDelegate,INPCameraCountDownViewDelegate, MPVolumeObserverProtocol>

@property (nonatomic, strong) VideoCameraPreviewView *cameraPreviewView;//buffer filter 预览层
@property (nonatomic, strong) VideoCameraOverlayView *cameraOverlayView;//手势 切换 层
@property (nonatomic, strong) VideoCameraSettingView *settingView;//相机配置层
@property (nonatomic, strong) INPCameraCountDownView *countDounView;//拍照层

@property (nonatomic, assign) BOOL isRecordingVideo;
@property (nonatomic, assign) BOOL isSaveImgFinish;
@property (nonatomic,   weak) OIFilter *cameraFilter; // 镜头正在使用的滤镜

@property (nonatomic, strong) CMMotionManager *motionManager; // 手机方向检查
@property (nonatomic, assign) VideoCameraViewOrientationMode currentOrientationMode;

@property (nonatomic, assign) BOOL enableTouchScreenTakePhoto;
@property (nonatomic, assign) NSTimeInterval shutTimeCount;


//@property (nonatomic, assign) VideoCameraViewFlashMode stillImageFlashMode;
//@property (nonatomic, assign) VideoCameraViewFlashMode videoFlashMode;

@end


@implementation VideoCameraViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor blackColor];
    self.isRecordingVideo = NO;
    self.isSaveImgFinish = NO;
    
    NSDictionary *settingDic = [[NSUserDefaults standardUserDefaults] objectForKey:kPhotoSettingKey];
    NSMutableDictionary *tmpDic = [NSMutableDictionary dictionaryWithDictionary:settingDic];
    NSString *timeString = tmpDic[kCameraTimerSetting];
    self.shutTimeCount = timeString.integerValue;
    
    self.enableTouchScreenTakePhoto = [tmpDic[kCameraTouchScreenSetting] boolValue];
    
    [self initCameraTypeWithBSModel];
    [self addObserverToNotification];
    
    [self enableVolumeObserver];
}

- (void)initCameraTypeWithBSModel {
    
    BSModel *model = [BSObject shareInstant].currentModel;
    if (!model) {
        self.cameraType = kInterPhotoCameraTypeNormal;
    } else {
        if (model.iconType == BS_OpenCameraVideo) {
            // 视频only
            self.cameraType = kInterPhotoCameraOverlayTypeVideoOnly;
        } else if (model.iconType == BS_OpenCamera) {
            // 镜头only
            self.cameraType = kInterPhotoCameraPreviewTypePhotoOnly;
        }
    }
//    self.cameraType = kInterPhotoCameraTypeVideoOnly;
    // 镜头画面
    self.cameraPreviewView = [[VideoCameraPreviewView alloc] initWithFrame:self.view.bounds andCameraType:(InterPhotoCameraPreviewType)self.cameraType];
    self.cameraPreviewView.delegate = self;

    // 上层UI及手势操作
    self.cameraOverlayView = [[VideoCameraOverlayView alloc] initWithFrame:self.view.bounds];
    self.cameraOverlayView.cameraType = (InterPhotoCameraOverlayType)self.cameraType;
    self.cameraOverlayView.delegate = self;
    
    [self.view addSubview:self.cameraPreviewView];
    [self.view addSubview:self.cameraOverlayView];
    
    _currentOrientationMode = kVideoCameraViewOrientationModePortrait;
    
    if (self.cameraType == kInterPhotoCameraTypeVideoOnly) {
        [self shouldExchangeCameraModeWhenBegin:kVideoCameraModeVideo];
    } else {
//        [self shouldExchangeCameraMode:kVideoCameraModeStillImage];
        [self shouldExchangeCameraModeWhenBegin:kVideoCameraModeStillImage];
    }
}

#pragma mark - 倒计时
- (void)createCountDownView{
    
    self.countDounView = [[INPCameraCountDownView alloc] initWithCountDownTime:self.shutTimeCount];
    self.countDounView.delegate = self;
    [self.view addSubview:self.countDounView];
}

- (void)countDownTimeup{
    [self.countDounView removeFromSuperview];
    self.countDounView.delegate = nil;
    self.countDounView = nil;
    [self.cameraOverlayView takePhotoAnimation];
    __weak VideoCameraViewController *weakSelf = self;
    [self.cameraPreviewView takeStillImagePhotoWithCompletion:^(UIImage *processImage, NSDictionary *metadata) {
        [weakSelf saveImage:processImage metedata:metadata];
    }];
}

- (void)cancelCountDownTimeUp {
    [self.countDounView removeFromSuperview];
    self.countDounView.delegate = nil;
    self.countDounView = nil;
}

#pragma mark Volume Observer Control
/**
 *  使能音量键 监听
 */
- (void)enableVolumeObserver {
//    dispatch_async(dispatch_get_main_queue(), ^{
        [MPVolumeObserver sharedInstance].delegate = self;
        [[MPVolumeObserver sharedInstance] startObserveVolumeChangeEvents];
//    });
}

/**
 *  禁止音量键 监听
 */
- (void)disenableVolumeObserver {
//    dispatch_async(dispatch_get_main_queue(), ^{
        [MPVolumeObserver sharedInstance].delegate = nil;
        [[MPVolumeObserver sharedInstance] stopObserveVolumeChangeEvents];
//    });
}


#pragma mark - MPVolumeObserver Protocol
/**
 *  拍照界面 点击音量键
 *
 *  @param button
 */
-(void)volumeButtonDidClick:(MPVolumeObserver *) button {
//    NSLog(@"did click volume");
    [self.cameraOverlayView shutterSendTouchUpInsideAction];
}


#pragma mark - 生命周期

- (void)viewDidAppear:(BOOL)animated{
    
    [super viewDidAppear:animated];
    self.cameraOverlayView.albumImageView.userInteractionEnabled = YES;
    
    [self.cameraPreviewView startCameraRunning];
    [self enableVolumeObserver];

    [self shouldOpenFlash];
}


- (void)shouldOpenFlash{
    
    if(self.cameraPreviewView.cameraMode == kVideoCameraModeVideo){
        
        NSDictionary *settingDic    = [[NSUserDefaults standardUserDefaults] objectForKey:kVideoSettingKey];
        NSMutableDictionary *tmpDic = [NSMutableDictionary dictionaryWithDictionary:settingDic];
        VideoCameraViewFlashMode flashMode = [tmpDic[kCameraFreshSetting] integerValue];
        
        if(flashMode == kVideoCameraViewFlashModeEnabled){
            
            self.cameraPreviewView.mediaCaptor.flashMode = OIStillImageCameraFlashModeOff;
            [self performSelector:@selector(changeFlashMode:) withObject:@(kVideoCameraViewFlashModeEnabled) afterDelay:0.2];
        }
        
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self disenableVolumeObserver];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.cameraPreviewView startCameraRunning];
}

- (void)dealloc {
    [self disenableVolumeObserver];
    [self.cameraPreviewView stopSwichingTimer];
    [self removeObserveToNotification];
}


#pragma mark - 通知/观察

#pragma mark 添加/删除 观察

- (void)addObserverToNotification {
    // 滤镜打开推荐页面
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(observeVideoCameraViewEnterMaterialCenterNotification:) name:INPVideoCameraFilterViewEnterMaterialCenterNotification object:nil];
    // 监测手机旋转方向
    [self addCMMotionToMobile];
    
    // 退入后台
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(observeVideoCameraViewWillResignActiveNotification:) name:UIApplicationWillResignActiveNotification object:nil];
    // 返回前台
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(observeVideoCameraViewWillEnterForegroundNotification:) name:UIApplicationDidBecomeActiveNotification object:nil];
}

- (void)removeObserveToNotification {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:INPVideoCameraFilterViewEnterMaterialCenterNotification object:nil];
    
    // app监听
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationWillResignActiveNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationDidBecomeActiveNotification object:nil];
}

#pragma mark 响应通知

// 进入素材中心
- (void)observeVideoCameraViewEnterMaterialCenterNotification:(NSNotification *)notification {
    MaterialCenterListViewController *materialVC = [notification.userInfo objectForKey:@"materialVC"];
    materialVC.fromEnterance = MaterialCenterModuleTypeFilter;
    [self.cameraPreviewView stopCameraRunning];
    [self.navigationController pushViewController:materialVC animated:YES];
}

// 退入后台
- (void)observeVideoCameraViewWillResignActiveNotification:(NSNotification *)notification {
    NSLog(@"退入后台");
    
    [self.cameraPreviewView cancelRecordVideo];
    [self.cameraPreviewView stopCameraRunning];
    
    [self.cameraOverlayView cancelRecordVideo];
    [self disenableVolumeObserver];
    self.isRecordingVideo = NO;
    
    [OIContext finish];
}

// 返回前台
- (void)observeVideoCameraViewWillEnterForegroundNotification:(NSNotification *)notification {
    NSLog(@"返回前台");
    
    if(self.navigationController.viewControllers.lastObject == self){
        
        [self.cameraPreviewView startCameraRunning];
        
        [self performSelector:@selector(shouldOpenFlash) withObject:nil afterDelay:0.5];
        
        [self enableVolumeObserver];
    }
    
    
}

#pragma mark 手机方向状况

- (void)addCMMotionToMobile {
    _motionManager = [[CMMotionManager alloc] init];
    if (_motionManager.isAccelerometerAvailable) {
        _motionManager.accelerometerUpdateInterval = 1.0/3.0; // 1秒钟采样5次
        
        __weak VideoCameraViewController *weakSelf = self;
        [ _motionManager startAccelerometerUpdatesToQueue:[NSOperationQueue mainQueue] withHandler:^(CMAccelerometerData *accelerometerData, NSError *error) {
            CMAcceleration acceleration = weakSelf.motionManager.accelerometerData.acceleration;
            
//            NSLog(@"x=%f, y=%f",acceleration.x,acceleration.y);
            
//            if (acceleration.x < -0.5 && (0.5>acceleration.y >-0.5)) {
//                self.currentOrientationMode = kVideoCameraViewOrientationModeLeft;
//            }else if (acceleration.x > 0.5 && (0.5>acceleration.y >-0.5)) {
//                self.currentOrientationMode = kVideoCameraViewOrientationModeRight;
//            }else if((0.5>=acceleration.x >=-0.5) && acceleration.y > 0) {
//                self.currentOrientationMode = kVideoCameraViewOrientationModeUpSideDown;
//            }else{
//                self.currentOrientationMode = kVideoCameraViewOrientationModePortrait;
//            }
            
            if (acceleration.x < -0.8 && (0.5>acceleration.y >-0.8)) {
                weakSelf.currentOrientationMode = kVideoCameraViewOrientationModeLeft;
            }else if (acceleration.x > 0.8 && (0.5>acceleration.y >-0.2)) {
                weakSelf.currentOrientationMode = kVideoCameraViewOrientationModeRight;
            }else if((0.7>=acceleration.x >=-0.7) && acceleration.y > 0.9) {
                weakSelf.currentOrientationMode = kVideoCameraViewOrientationModeUpSideDown;
            }else if((0.3>=acceleration.x >=-0.3) && acceleration.y < -0.7) {
                weakSelf.currentOrientationMode = kVideoCameraViewOrientationModePortrait;
            }
        }];
    }
}

- (void)setCurrentOrientationMode:(VideoCameraViewOrientationMode)currentOrientationMode {
    if (_currentOrientationMode == currentOrientationMode) {
        return;
    }
    _currentOrientationMode = currentOrientationMode;
    if (self.cameraPreviewView.isRecordingVideo) {
        return;
    }
    // 调整方向
    [self.cameraPreviewView setCameraPreviewOrientation:_currentOrientationMode];
    [self.cameraOverlayView setCameraOverlayOrientation:_currentOrientationMode];
    [self.settingView setCameraSettingViewOrientation:_currentOrientationMode withAnimation:YES];
}

#pragma mark overlayDelegate
#pragma mark 返回首页
- (void)shouldBcakHome{
    [self.cameraPreviewView stopCameraRunning];
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma 切换前后镜头
- (void)shouldExchangeCameraPosition:(VideoCameraPosition)position{
    
    self.cameraPreviewView.cameraPosition = position;
}


- (void)shouldExchangeCameraModeWhenBegin:(VideoCameraMode)mode {
    
    NSString *settingKey = kVideoSettingKey;
    
    if(mode == kVideoCameraModeStillImage){
        
        settingKey = kPhotoSettingKey;
        
        if(self.cameraPreviewView.flashMode == kVideoCameraViewFlashModeEnabled && self.cameraPreviewView.cameraMode == kVideoCameraModeVideo){
            self.cameraPreviewView.mediaCaptor.flashMode = OIMediaCaptorFlashModeOff;
        }
    }
    
    NSDictionary *settingDic = [[NSUserDefaults standardUserDefaults] objectForKey:settingKey];
    
    NSString *flashString = settingDic[kCameraFreshSetting];
    NSString *scaleString = settingDic[kCameraScaleSetting];
    NSString *timerString = settingDic[kCameraTimerSetting];
    
    if (timerString.integerValue == 0) {
        timerString = @"10";
    }
    
//    self.cameraPreviewView.cameraMode = mode;
    self.cameraPreviewView.previewCrop = [self viewScaleWithString:scaleString];
    self.cameraOverlayView.recordTime = timerString.integerValue;
    
    
    //    if(flashString.integerValue == kVideoCameraViewFlashModeEnabled && mode == kVideoCameraModeVideo){
    //        // 之所以用延时，是因为这里不用延时会卡住摄像头，不知道为何
    //        [self performSelector:@selector(changeFlashMode:) withObject:@(kVideoCameraViewFlashModeEnabled) afterDelay:0.5];
    //    }
#warning 秋总说这句代码可能有问题
    [self performSelector:@selector(changeFlashMode:) withObject:@(flashString.integerValue) afterDelay:0.5];
    
    // chentao: 切换模式时不禁止音量键监听，所以此处代码暂时注释
    //    [self performSelector:@selector(enableVolumeObserver) withObject:nil afterDelay:0.5];
}

#pragma mark 切换 拍照 视频
- (void)shouldExchangeCameraMode:(VideoCameraMode)mode{
    
    NSString *settingKey = kVideoSettingKey;
    
    if(mode == kVideoCameraModeStillImage){
        
        settingKey = kPhotoSettingKey;
        
        if(self.cameraPreviewView.flashMode == kVideoCameraViewFlashModeEnabled && self.cameraPreviewView.cameraMode == kVideoCameraModeVideo){
            self.cameraPreviewView.mediaCaptor.flashMode = OIMediaCaptorFlashModeOff;
        }
    }
    
    NSDictionary *settingDic = [[NSUserDefaults standardUserDefaults] objectForKey:settingKey];
    
    NSString *flashString = settingDic[kCameraFreshSetting];
    NSString *scaleString = settingDic[kCameraScaleSetting];
    NSString *timerString = settingDic[kCameraTimerSetting];
    
    if (timerString.integerValue == 0) {
        timerString = @"10";
    }
    
    self.cameraPreviewView.cameraMode = mode;
    self.cameraPreviewView.previewCrop = [self viewScaleWithString:scaleString];
    self.cameraOverlayView.recordTime = timerString.integerValue;
    
    
//    if(flashString.integerValue == kVideoCameraViewFlashModeEnabled && mode == kVideoCameraModeVideo){
//        // 之所以用延时，是因为这里不用延时会卡住摄像头，不知道为何
//        [self performSelector:@selector(changeFlashMode:) withObject:@(kVideoCameraViewFlashModeEnabled) afterDelay:0.5];
//    }
#warning 秋总说这句代码可能有问题
    [self performSelector:@selector(changeFlashMode:) withObject:@(flashString.integerValue) afterDelay:0.5];
    
    // chentao: 切换模式时不禁止音量键监听，所以此处代码暂时注释
//    [self performSelector:@selector(enableVolumeObserver) withObject:nil afterDelay:0.5];
}

#pragma mark - 选择滤镜效果
- (void)selectFilterID:(NSInteger)idNumber{
    
}

- (void)didChooseINPFilter:(OIFilter *)filter {
    self.cameraFilter = filter;
    [self.cameraPreviewView setFilter:filter];
}

- (void)didPanFilterWithPercent:(CGFloat)percent {
    [self.cameraPreviewView setSwitchFilterWithPercent:percent];
}

- (void)didEndFilterChoosingWithPercent:(CGFloat)percent resume:(BOOL)isResume {
    [self.cameraPreviewView didEndFilterChoosingWithPercent:percent resume:isResume];
    if (!isResume) {
        [self.cameraOverlayView changeFilterCoverImageToNextFilter];
    }
}

#pragma mark - 切换滤镜动画

- (void)didChooseNextINPFilter:(OIFilter *)filter withOrder:(BOOL)nextOrder {
    if (nextOrder) {
        [self.cameraPreviewView setRightFilter:filter];
    } else {
        [self.cameraPreviewView setLeftFilter:filter];
    }
}

#pragma mark 使用教程

- (void)videoCameraUesCourseView {
    self.cameraPreviewView.previewCrop = kVideoCameraPreviewCrop4To3;
}

#pragma mark 控制镜头缩放

- (void)cameraRampToVideoZoomFactor:(CGFloat)factor withRate:(float)rate {
    [self.cameraPreviewView cameraRampToVideoZoomFactor:factor withRate:rate];
}

#pragma mark 按下快门
- (void)pressedShutterWithMode:(VideoCameraMode)mode{
    
    if(mode == kVideoCameraModeVideo) {
        if(self.isRecordingVideo){
            [self stopRecordVideo];
        } else {
            [self startRecordVideo];
        }
    } else {
        self.isSaveImgFinish = NO;
        if(self.shutTimeCount == 0) {
            [self.cameraOverlayView takePhotoAnimation];
            __weak VideoCameraViewController *weakSelf = self;
            [self.cameraPreviewView takeStillImagePhotoWithCompletion:^(UIImage *processImage, NSDictionary *metadata) {
                [weakSelf saveImage:processImage metedata:metadata];
            }];
        } else {
            if (self.countDounView) {
                [self.countDounView cancelCountDown];
            } else {
                [self createCountDownView];
            }
        }
    }
}

- (void)startRecordVideo {
    self.isRecordingVideo = YES;
    [self.cameraOverlayView startRecordVideo];
    [self.cameraPreviewView startRecordVideo];
}

- (void)stopRecordVideo {
    self.isRecordingVideo = NO;
    [self.cameraOverlayView stopRecordVideo];
    [self.cameraPreviewView finishRecordVideo];
}

#pragma mark 保存照片到系统相册
- (void)saveImage:(UIImage *)image metedata:(NSDictionary *)metedata{
    
    NSString *backURL = [BSObject shareInstant].currentModel.backURL;
    self.cameraOverlayView.albumImageView.userInteractionEnabled = NO;
    
    
    if(![AlbumOperationFunction isAlbumAuthorization]){
        dispatch_async(dispatch_get_main_queue(), ^{
            NSString *tips = LocalString(@"应用相机权限受限,请在设置中启用");
            
            BeautyAlertView *alert = [[BeautyAlertView alloc]initWithTitle:nil message:tips delegate:self cancelButtonTitle:LocalString(@"确定") otherButtonTitles:LocalString(@"设置"), nil];
            alert.tag = _albumAlertTag;
            [alert show];
        });
        return;
        
    }
    
    if(backURL){
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [ProgressControll showProgressNormal];
        });
        
        
    }
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        
        UIImage *thumbImg = [image resizeImage:CGSizeMake(image.size.width * 0.4, image.size.height * 0.4)];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.cameraOverlayView.albumImageView.transform = CGAffineTransformMakeScale(0.1, 0.1);
            self.cameraOverlayView.albumImageView.image = thumbImg;
            [UIView animateWithDuration:0.3 delay:0 usingSpringWithDamping:0.4 initialSpringVelocity:1 options:UIViewAnimationOptionTransitionNone animations:^{
                self.cameraOverlayView.albumImageView.transform = CGAffineTransformIdentity;
            } completion:nil];
            
        });
        
    });
    
    [AlbumOperationFunction cameraSaveImage:image exifInfo:metedata finish:^(BOOL isFinish, NSDictionary *info, NSError *error) {
        
       
        if([info isKindOfClass:[NSDictionary class]] && error == nil){
            
            self.isSaveImgFinish = YES;
            
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                self.cameraOverlayView.albumImageView.userInteractionEnabled = YES;
                NSLog(@"已写入相册");
                
                if(backURL){
                    NSString *localIdentifier = info[@"AssetPath"];
                    
                    if([backURL containsString:@"circle20160324"]){
                        
                        NSData *data = [backURL dataUsingEncoding:NSUTF8StringEncoding];
                        NSString *targetLink = [data base64EncodedStringWithOptions:0];
                        
                        NSString *linkString = [NSString stringWithFormat:@"circle20160324://?self_app=interCamera&target_url=%@&docType=0&imageId=%@",targetLink,localIdentifier];
                         [[UIApplication sharedApplication] openURL:[NSURL URLWithString:linkString]];
                    }else{
                        
                        NSString *backString = [backURL stringByAppendingString:localIdentifier];
                        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:backString]];
                    }
                    
                    
                }
                [ProgressControll dismissProgress];
            });
            
        }else if(error){
            
            [[NSNotificationCenter defaultCenter] postNotificationName:PhotoSaveFailNotify object:nil];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [ProgressControll dismissProgress];
                BeautyAlertView *alter = [[BeautyAlertView alloc] initWithTitle:@"提示" message:@"-_- 保存照片失败\n请检查系统的“设置-->隐私-->照片”里是否有开启权限，又或者是存储空间不足,请检查。" delegate:nil cancelButtonTitle:@"确认" otherButtonTitles: nil];
                [alter show];
            });
            
            self.isSaveImgFinish = NO;
        }
    }];
}

#pragma mark 跳转相册
- (void)shouldShouldAlbumViewWithMode:(VideoCameraMode)mode{
    
    self.cameraOverlayView.albumImageView.userInteractionEnabled = NO;
    
    if(mode == kVideoCameraModeStillImage){
        
        if(![AlbumOperationFunction isAlbumAuthorization]){
            
            NSString *tips = LocalString(@"应用相机权限受限,请在设置中启用");
            BeautyAlertView *alert = [[BeautyAlertView alloc]initWithTitle:nil message:tips delegate:self cancelButtonTitle:LocalString(@"确定") otherButtonTitles:LocalString(@"设置"), nil];
            alert.tag = _cameraAlertTag;
            [alert show];
            return;
            
        }
        
        if(self.isSaveImgFinish){
            
            [self.cameraPreviewView stopCameraRunning];
            AlbumMainViewController *albumViewCtrl = [[AlbumMainViewController alloc] initFromCamera];
            [self.navigationController pushViewController:albumViewCtrl animated:YES];
        }
        else{
        
            
            [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus status) {
                
                if (status == PHAuthorizationStatusAuthorized) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        
                        [self.cameraPreviewView stopCameraRunning];
                        [self.navigationController pushViewControllerWithName:@"AlbumMainViewController" animated:YES];
                        
                        
                    });
                }
            }];
            
        }
        
    }else{
        [self.cameraPreviewView stopCameraRunning];
        [self showVideoPickerView];
    }
    
}

#pragma mark 显示设置界面
- (void)shouldShowSettingViewWithMode:(VideoCameraMode)mode{
    
    _settingView = nil;
    _settingView = [[VideoCameraSettingView alloc] initWithFrame:self.view.bounds withDelegate:self];
//    _settingView.delegate = self;
    _settingView.shutterMode = mode;
    _settingView.alpha = 0.0;
    [_settingView setCameraSettingViewOrientation:_currentOrientationMode withAnimation:NO];
    [self.view addSubview:_settingView];
    [UIView animateWithDuration:0.2 animations:^{
        _settingView.alpha = 1.0;
    }];
    
}

//- (void)focusAndExprosureCenterPoint:(CGPoint)point{
//    
//    [self.cameraPreviewView panExposurePointerToPoint:point];
//}
//
//- (void)tapFocusAndExprosureCenterPoint:(CGPoint)point{
//    if (self.enableTouchScreenTakePhoto && self.cameraPreviewView.cameraMode == kVideoCameraModeStillImage) {
//        __weak VideoCameraViewController *weakSelf = self;
//        [self.cameraPreviewView moveExposurePointerToPoint:point andTakeStillImageWithCompletion:^(UIImage *processImage, NSDictionary *metadata) {
//            weakSelf.isSaveImgFinish = NO;
//            [weakSelf saveImage:processImage metedata:metadata];
//            weakSelf.enableTouchScreenTakePhoto = NO;
//        }];
//    } else {
//        [self.cameraPreviewView moveExposurePointerToPoint:point];
//    }
//}

- (void)changeScalePointWithOutputScale:(float)scale{
    
}

#pragma mark - 聚焦/曝光

// 改变聚焦点
- (void)changeFocusCenterPoint:(CGPoint)focusPoint {
    [self.cameraPreviewView changeFocusPointerToPoint:focusPoint];
}

// 改变曝光点
- (void)changeExposureCenterPoint:(CGPoint)exposurePoint {
    [self.cameraPreviewView changeExposurePointerToPoint:exposurePoint];
}

- (void)overlayViewTapFocosExposurePoint {
    if (self.enableTouchScreenTakePhoto && self.cameraPreviewView.cameraMode == kVideoCameraModeStillImage) {
//        __weak VideoCameraViewController *weakSelf = self;
        
//        [self pressedShutterWithMode:kVideoCameraModeStillImage];
        [self performSelector:@selector(pressedShutterWithMode:) withObject:kVideoCameraModeStillImage afterDelay:0.6];
        
//        [self.cameraPreviewView takeStillImagePhotoWithCompletion:^(UIImage *processImage, NSDictionary *metadata) {
//            weakSelf.isSaveImgFinish = NO;
//            [weakSelf saveImage:processImage metedata:metadata];
//        }];
    }
}

#pragma mark - setting delegate
#pragma mark 改变拍摄比例
- (void)shouldChangeScale:(VideoCameraPreviewCrop)scale{

    self.cameraPreviewView.previewCrop = scale;

}

#pragma mark 闪光灯
- (void)shouldChangeFlash:(VideoCameraViewFlashMode)flashMode{
    self.cameraPreviewView.flashMode = flashMode;
}

- (void)changeFlashMode:(NSNumber *)flashModeNumber{
    VideoCameraViewFlashMode flashMode = flashModeNumber.integerValue;
    self.cameraPreviewView.flashMode = flashMode;
}


// 是否有闪光灯
- (BOOL)videoSettingHasFlash {
    BOOL hasFlash = [self.cameraPreviewView.mediaCaptor hasFlash];
    if (self.cameraPreviewView.cameraPosition == kVideoCameraPositionFront) { 
        hasFlash = NO;
    }
    return hasFlash;
}

#pragma mark 时长
- (void)shouldChangeShutTime:(NSTimeInterval)time{

    if(self.cameraOverlayView.cameraMode == kVideoCameraModeStillImage){
        
        self.shutTimeCount = time;
    }
    
    self.cameraOverlayView.recordTime = time;
}

#pragma mark 触屏拍摄
- (void)shouldChangeTouchSceenEnable:(BOOL)enable{
    self.enableTouchScreenTakePhoto = enable;
}


#pragma mark  VideoCameraPreviewViewDelegate

- (void)videoCameraFinishRecordVideo:(NSURL *)finishURL{
    dispatch_async(dispatch_get_main_queue(), ^{
        NSString *backURL = [BSObject shareInstant].currentModel.backURL;
        if(backURL){
            [ProgressControll showProgressNormal];
            [self.cameraPreviewView saveRecordedVideo:^(bool isSaved) {
                PHFetchOptions *options = [[PHFetchOptions alloc] init];
                options.predicate = [NSPredicate predicateWithFormat:@"mediaType = %d", PHAssetMediaTypeVideo];
                PHFetchResult *assetsFetchResults = [PHAsset fetchAssetsWithOptions:options];
//                PHAsset *asset = [assetsFetchResults objectAtIndex:0];
                PHAsset *asset = [assetsFetchResults lastObject];
                NSString *createdAssetId = asset.localIdentifier;
                [self videoCameraSaveAlbumFinish:createdAssetId];
            }];
           // [self.cameraPreviewView saveRecordedVideo];
        }else{
            AVAsset *asset = [AVAsset assetWithURL:finishURL];
            VideoViewController *videoVC = [[VideoViewController alloc]init];
            videoVC.asset = asset;
            videoVC.defaultFilterColorId = self.cameraOverlayView.selectedColorId;
            self.cameraOverlayView.filterColorDic = nil;
            [videoVC deliverCameraFilter:self.cameraFilter];
            [self.cameraPreviewView stopCameraRunning];
            [self.navigationController pushViewController:videoVC animated:YES];
        }
    });
}

// 调节手势view
- (void)previewAdjustFrame:(CGRect)previewFrame {
    [self.cameraOverlayView adjustGestureViewFrameWithFrame:previewFrame];
}

- (void)previewStartRecordingVideo:(BOOL)finish {
//    [self.cameraOverlayView enableSwipeGesture:!finish];
}

#pragma mark

- (void)videoCameraSaveAlbumFinish:(NSString *)localIdentifier{
    
    NSString *backURL = [BSObject shareInstant].currentModel.backURL;
    
    if(backURL){
        
        [ProgressControll dismissProgress];
        
        if([backURL containsString:@"circle20160324"]){
            
            NSData *data = [backURL dataUsingEncoding:NSUTF8StringEncoding];
            NSString *targetLink = [data base64EncodedStringWithOptions:0];
            
            NSString *linkString = [NSString stringWithFormat:@"circle20160324://?self_app=interCamera&target_url=%@&docType=1&imageId=%@",targetLink,localIdentifier];
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:linkString]];
        }else{
            
            NSString *backString = [backURL stringByAppendingString:localIdentifier];
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:backString]];
        }
        
    }
}

- (VideoCameraPreviewCrop)viewScaleWithString:(NSString *)scaleString{
    
    VideoCameraPreviewCrop scaleType = kVideoCameraPreviewCrop4To3;
    if([scaleString isEqualToString:@"916"]){
        
        if(self.cameraOverlayView.cameraMode == kVideoCameraModeVideo){
            scaleType = kVideoCameraPreviewCrop16To9;
//            scaleType = kVideoCameraPreviewCrop235To1;
        } else {
            scaleType = kVideoCameraPreviewCrop16To9;
        }
        
    }else if([scaleString isEqualToString:@"11"]){
        scaleType = kVideoCameraPreviewCrop1To1;
    }
    else if([scaleString isEqualToString:@"43"]){
        if (self.cameraPreviewView.cameraMode == kVideoCameraModeVideo) {
            scaleType = kVideoCameraPreviewCrop235To1;
        } else {
            scaleType = kVideoCameraPreviewCrop4To3;
        }
    }
    else if([scaleString isEqualToString:@"169"]){
        if(self.cameraOverlayView.cameraMode == kVideoCameraModeVideo){
            scaleType = kVideoCameraPreviewCrop235To1;
            //            scaleType = kVideoCameraPreviewCrop235To1;
        } else {
            scaleType = kVideoCameraPreviewCrop16To9;
        }
    }
    
    return scaleType;
}


@end
