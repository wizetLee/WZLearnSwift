//
//  VideoCameraViewController.h
//  POCONewCamera
//
//  Created by 陈弢 on 2017/5/16.
//  Copyright © 2017年 Lzq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VideoCameraViewController : UIViewController

// 相机样式
typedef NS_ENUM(NSInteger, InterPhotoCameraType) {
    kInterPhotoCameraTypeNormal,   
    kInterPhotoCameraTypePhotoOnly,
    kInterPhotoCameraTypeVideoOnly,
};

@property (nonatomic, assign) InterPhotoCameraType cameraType;

@end
