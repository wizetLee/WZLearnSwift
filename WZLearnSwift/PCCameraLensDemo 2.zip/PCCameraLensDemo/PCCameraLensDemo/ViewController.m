//
//  ViewController.m
//  PCCameraLensDemo
//
//  Created by admin on 3/8/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "ViewController.h"
#import "PCCameraController.h"
#import "PCParameterManager.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = false;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    if ([[NSUserDefaults standardUserDefaults] valueForKey:@"wizet"]) {
        NSLog(@"%@", [[[NSUserDefaults standardUserDefaults] valueForKey:@"wizet"] class]);
    } else {
        NSMutableDictionary *dic = [NSMutableDictionary dictionary];
        dic[@"zhu"] = @"猪猪组合组织组织组或租住着组合组织组";
        [[NSUserDefaults standardUserDefaults] setValue:dic forKey:@"wizet"];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    if ([PCParameterManager lensPrecedence]) {
         [self.navigationController pushViewController:[PCCameraController new] animated:false];
    }
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
   
}

- (IBAction)touchInside:(UIButton *)sender {
    [self.navigationController pushViewController:[PCCameraController new] animated:true];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
