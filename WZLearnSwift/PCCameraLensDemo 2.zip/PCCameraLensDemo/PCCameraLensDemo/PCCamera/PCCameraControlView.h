//
//  PCCameraControlView.h
//  PCCameraLensDemo
//
//  Created by admin on 8/8/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import <UIKit/UIKit.h>

@class PCCamera;
@class PCCameraPreviewView;
#import "PCParameterManager.h"

@protocol PCCameraControlViewProtocol <NSObject>

//#define PCCCV_BTN_ACTIONNAME(name)  - (void)cameraControlViewDidClicked##name;

@optional

//切换镜头
- (void)cameraControlViewDidClickedLensButton;
//切换闪光灯
- (void)cameraControlViewDidClickedFlashButton;
//退出按钮
- (void)cameraControlViewDidClickedQuitButton;
//快门按钮
- (void)cameraControlViewDidClickedShutterButton;
//镜头参数
- (void)cameraControlViewDidClickedLensTypeButton;
//设置按钮
- (void)cameraControlViewDidClickedSettingButton;
//调整镜头比例
- (void)cameraControlViewDidClickedLensRate:(NSNumber *)lenRate;

//点击快速拍照图片的事件
- (void)cameraControlViewDidClickedSwiftImages;


//合成
- (void)mix;

@end


/**
 纯粹用于搭建功能性UI
 */
@interface PCCameraControlView : UIView

//辅助

@property (nonatomic, weak) PCCameraPreviewView *cameraPreviewView;
@property (nonatomic, weak) id<PCCameraControlViewProtocol> delegate;
@property (nonatomic, assign) VideoCameraViewOrientationMode currentOrientationMode;//当前设备方向 由陀螺仪的回调控制


- (void)swiftCount:(NSString *)str;

//更新UI显示状态

- (void)updateUIMemory;//仅在换镜头时候调用
- (void)updateFlashUI;
- (void)updateLensUI;
- (void)updateShutterUI;

- (void)activateShutteringWithTiming;
- (void)setGIFProgress:(CGFloat)progress;
- (void)timerClear;
@end
