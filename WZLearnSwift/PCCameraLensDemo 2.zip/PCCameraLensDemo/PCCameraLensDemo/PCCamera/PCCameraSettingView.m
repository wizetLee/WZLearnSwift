//
//  PCCameraSettingView.m
//  PCCameraLensDemo
//
//  Created by admin on 11/8/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "PCCameraSettingView.h"


#define PCCAMERASETTINGVIEWCELL_ID @"PCCameraSettingViewCell_ID"//cell ID

@interface PCCameraSettingViewCell : UICollectionViewCell

@property (nonatomic, strong) UIImageView *coverImageView;//封面
@property (nonatomic, strong) UILabel *headlineLabel;//标题
@property (nonatomic, strong) NSMutableDictionary *parameterDic;//数据配置

@end

@implementation PCCameraSettingViewCell

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self createViews];
    }
    return self;
}

- (void)createViews {
    CGFloat imageHW = 40.0;
    _coverImageView = [[UIImageView alloc] initWithFrame:CGRectMake((self.frame.size.width - imageHW) / 2.0, 0.0, imageHW, imageHW)];
    [self.contentView addSubview:_coverImageView];
    _coverImageView.backgroundColor = [UIColor redColor];
    
    _headlineLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0, imageHW, self.bounds.size.width, self.frame.size.height - imageHW)];
    [self.contentView addSubview:_headlineLabel];
    _headlineLabel.text = @"标题";
    _headlineLabel.textAlignment = NSTextAlignmentCenter;
    _headlineLabel.font = [UIFont systemFontOfSize:9];
}

- (void)prepareForReuse {
    _coverImageView.image = nil;
    _headlineLabel.text = @"";
}

- (void)setParameterDic:(NSMutableDictionary *)parameterDic {
    if ([parameterDic isKindOfClass:[NSMutableDictionary class]]) {
        _parameterDic = parameterDic;
        [self updateUI];
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self updateUI];
}

- (void)updateUI {
    if (self.parameterDic) {
        NSNumber *type      = self.parameterDic[PCCAMERASETTINGVIEW_SETTINGTYPE];
        NSString *headline  = self.parameterDic[PCCAMERASETTINGVIEW_SETTINGHEADLINE];
        NSArray *source     = self.parameterDic[PCCAMERASETTINGVIEW_SETTINGSOURCE];
        self.headlineLabel.text = headline;
        if (source.count) {
            if ([type integerValue] < source.count && [type integerValue] >= 0) {
            } else {
                type = @(0);
            }
            
            NSDictionary *dic = source[[type integerValue]];
            //无图片 暂时改title
            if ([dic[@"image"] isKindOfClass:[NSString class]]) {
                self.headlineLabel.text = dic[@"image"];
            }
        }
    }
}

- (void)switchType {
    if (self.parameterDic) {
        NSNumber *type      = self.parameterDic[PCCAMERASETTINGVIEW_SETTINGTYPE];
        NSArray *source     = self.parameterDic[PCCAMERASETTINGVIEW_SETTINGSOURCE];
        NSInteger tmp       = [type integerValue];
        //点击循环操作
        if (tmp < (source.count - 1)
            && tmp >= 0) {
            tmp++;
        } else {
            tmp = 0;
        }
        self.parameterDic[PCCAMERASETTINGVIEW_SETTINGTYPE] = @(tmp);
    }
}

@end

@interface PCCameraSettingView()<UICollectionViewDelegate,
                                UICollectionViewDataSource>

@property (nonatomic, strong) UICollectionView *collection;
@property (nonatomic, strong) NSMutableArray <NSMutableDictionary *>*dataSourceMArr;

@end

@implementation PCCameraSettingView

#pragma mark - Initialization

- (void)dealloc {
    NSLog(@"%s", __func__);
    [PCParameterManager saveConfiguration];
}


- (void)alertContent {
    [self createViews];
    self.clickedBackgroundToDismiss = true;
}


- (void)createViews {
    [self createData];//构建UI前先构建数据源
    
    CGFloat WH = 60.0;
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.itemSize = CGSizeMake(WH, WH);
    layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    
    _collection = [[UICollectionView alloc] initWithFrame:CGRectMake(0.0
                                                                     , [UIScreen mainScreen].bounds.size.height  - 80
                                                                     , [UIScreen mainScreen].bounds.size.width
                                                                     , 80.0)
                                     collectionViewLayout:layout];
    [self addSubview:_collection];
    _collection.backgroundColor = [UIColor yellowColor];
    _collection.showsHorizontalScrollIndicator = false;
    [_collection registerClass:[PCCameraSettingViewCell class] forCellWithReuseIdentifier:PCCAMERASETTINGVIEWCELL_ID];
    _collection.delegate = self;
    _collection.dataSource = self;
}

//数据源 根据memory返回
- (void)createData {
  
    //整个数字保存在Memony中
    @try {
        NSMutableDictionary *dic = [PCParameterManager currentLensParameters];
        //可变类型转化
        if ([dic[PCCAMERA_PARAMETER_SETTING] isKindOfClass:[NSArray class]]) {
            _dataSourceMArr = [NSMutableArray arrayWithArray:dic[PCCAMERA_PARAMETER_SETTING]];
            NSMutableArray *tmpMArr = [NSMutableArray array];
            for (int i = 0; i < _dataSourceMArr.count; i++) {
                [tmpMArr addObject:[NSMutableDictionary dictionaryWithDictionary:_dataSourceMArr[i]]];
            }
            _dataSourceMArr = tmpMArr;
        } else {
            [self defaultData];
        }
    } @catch (NSException *exception) {
         [self defaultData];
    } @finally {
       
    }
}

- (void)defaultData {
    /*
     0：相册
     1：比例
     2：构图线
     3：定时
     4：全屏快门
     5：更多
     and so on  滤镜：json下来的，key映射到filter 记忆功能本地检索这个json，如果没有上次的那个状态的化就origion状态，
     */
    _dataSourceMArr = [NSMutableArray array];
    [_dataSourceMArr addObject:[NSMutableDictionary dictionaryWithDictionary:
                                @{PCCAMERASETTINGVIEW_SETTINGTYPE:@(0),/*选中的类型为第一个！也就是选取默认类型*/
                                  PCCAMERASETTINGVIEW_SETTINGHEADLINE:@"相册",
                                  PCCAMERASETTINGVIEW_SETTINGSOURCE:@[@{@"image":/*素材名字*/@"相册.png",  @"source":@(0)}],
                                  }]];
    
    [_dataSourceMArr addObject:[NSMutableDictionary dictionaryWithDictionary:
                                @{PCCAMERASETTINGVIEW_SETTINGTYPE:@(0),
                                  PCCAMERASETTINGVIEW_SETTINGHEADLINE:@"比例",
                                  PCCAMERASETTINGVIEW_SETTINGSOURCE:@[@{@"image":/*素材名字*/@"1:1.png",  @"source":@(0)},/*1:1*/
                                                                      @{@"image":/*素材名字*/@"16:9.png",  @"source":@(1)},/*16:9*/
                                                                      @{@"image":/*素材名字*/@"4:3.png",  @"source":@(2)}/*4:3*/
                                                                      ],
                                  }]];
    [_dataSourceMArr addObject:[NSMutableDictionary dictionaryWithDictionary:
                                @{PCCAMERASETTINGVIEW_SETTINGTYPE:@(0),
                                  PCCAMERASETTINGVIEW_SETTINGHEADLINE:@"构图线",
                                  PCCAMERASETTINGVIEW_SETTINGSOURCE:@[@{@"image":/*素材名字*/@"无构图线.png",  @"source":@(0)},/*无构线*/
                                                                      @{@"image":/*素材名字*/@"01构图线.png",  @"source":@(1)},/*01号*/
                                                                      @{@"image":/*素材名字*/@"02构图线.png",  @"source":@(2)}/*02号*/
                                                                      ],
                                  }]];
    [_dataSourceMArr addObject:[NSMutableDictionary dictionaryWithDictionary:
                                @{PCCAMERASETTINGVIEW_SETTINGTYPE:@(0),
                                  PCCAMERASETTINGVIEW_SETTINGHEADLINE:@"定时",
                                  PCCAMERASETTINGVIEW_SETTINGSOURCE:@[@{@"image":/*素材名字*/@"无定时.png",  @"source":@(0)},/*无定时*/
                                                                      @{@"image":/*素材名字*/@"1sec.png",  @"source":@(1)},/*1sec*/
                                                                      @{@"image":/*素材名字*/@"2sec.png",  @"source":@(2)},/*2sec*/
                                                                      @{@"image":/*素材名字*/@"10sec.png",  @"source":@(3)},/*10sec*/
                                                                      ],
                                  }]];
    [_dataSourceMArr addObject:[NSMutableDictionary dictionaryWithDictionary:
                                @{PCCAMERASETTINGVIEW_SETTINGTYPE:@(0),
                                  PCCAMERASETTINGVIEW_SETTINGHEADLINE:@"全屏快门",
                                  PCCAMERASETTINGVIEW_SETTINGSOURCE:@[@{@"image":/*素材名字*/@"非全屏快门.png",  @"source":@(0)},/*非全屏快门*/
                                                                      @{@"image":/*素材名字*/@"全屏快门.png",  @"source":@(1)},/*全屏快门*/
                                                                      ],
                                  }]];
    [_dataSourceMArr addObject:[NSMutableDictionary dictionaryWithDictionary:
                                @{PCCAMERASETTINGVIEW_SETTINGTYPE:@(0),
                                  PCCAMERASETTINGVIEW_SETTINGHEADLINE:@"更多",
                                  PCCAMERASETTINGVIEW_SETTINGSOURCE:@[@{@"image":/*素材名字*/@"更多.png",  @"source":@(0)},/*更多*/
                                                                      ],
                                  }]];
    NSMutableDictionary *dic = [PCParameterManager currentLensParameters];
    dic[PCCAMERA_PARAMETER_SETTING] = [_dataSourceMArr copy];
}


#pragma mark - UICollectionViewDelegate
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    @try {
        if (self.dataSourceMArr[indexPath.row]
            && [((NSArray *)self.dataSourceMArr[indexPath.row][PCCAMERASETTINGVIEW_SETTINGSOURCE]) count]) {
            //切换到下一个类型
            //更新UI
            PCCameraSettingViewCell *cell = (PCCameraSettingViewCell *)[collectionView cellForItemAtIndexPath:indexPath];
            [cell switchType];
            [cell setNeedsLayout];
            NSNumber *type = cell.parameterDic[PCCAMERASETTINGVIEW_SETTINGTYPE];//默认类型提取
           
            SEL sel = nil;
            id obj = nil;
            if (indexPath.row == 0) {
                sel = @selector(cameraSettingViewClickedAlbum);
            } else if (indexPath.row == 1) {
                obj = type;
                sel = @selector(cameraSettingViewClickedScaleWithType:);
            } else if (indexPath.row == 2) {
                obj = type;
                sel = @selector(cameraSettingViewClickedConceptionWithType:);
            } else if (indexPath.row == 3) {
                obj = type;
                sel = @selector(cameraSettingViewClickedTimingWithType:);
            } else if (indexPath.row == 4) {
                obj = type;
                sel = @selector(cameraSettingViewClickedFullScreenShutterWithType:);
            } else if (indexPath.row == 5) {
                sel = @selector(cameraSettingViewClickedMore);
            }
            if (sel
                && [_delegate respondsToSelector:sel]) {
#pragma clang diagnostic push 
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
                [_delegate performSelector:sel withObject:obj];
#pragma clang diagnostic pop
            }
        }
        //保存属性
        NSMutableDictionary *dic = [PCParameterManager currentLensParameters];
        dic[PCCAMERA_PARAMETER_SETTING] = [_dataSourceMArr copy];
        
        //手动消失
//        if (indexPath.row == 0) {
//            [self alertDismissWithAnimated:false];
//        } else if (indexPath.row == 5) {
//            [self alertDismissWithAnimated:false];
//        }
        
    } @catch (NSException *exception) {
        
    }
}

#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return (_dataSourceMArr)?_dataSourceMArr.count:0;
}

- (__kindof PCCameraSettingViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    PCCameraSettingViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:PCCAMERASETTINGVIEWCELL_ID forIndexPath:indexPath];
    cell.backgroundColor = [UIColor orangeColor];
    
    if (self.dataSourceMArr.count > indexPath.row) {
        NSMutableDictionary *dic = self.dataSourceMArr[indexPath.row];
        
        if ([dic isKindOfClass:[NSMutableDictionary class]]) {
            cell.parameterDic = dic;
        }
    }
    
    return cell;
}

@end
