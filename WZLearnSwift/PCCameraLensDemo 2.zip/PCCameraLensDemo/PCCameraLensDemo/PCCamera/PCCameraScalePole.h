//
//  PCCameraScalePole.h
//  PCCameraLensDemo
//
//  Created by admin on 18/8/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol PCCameraScalePoleProtocol <NSObject>

- (void)beginSetSpeedRate;
- (void)commitSetSpeedRate;
- (void)currentSpeedRate:(CGFloat)speedRate;

@end

@interface PCCameraScalePole : UIView

@property (nonatomic, weak) id <PCCameraScalePoleProtocol> delegate;

@end
