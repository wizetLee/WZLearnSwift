//
//  PCCameraLensesView.h
//  PCCameraLensDemo
//
//  Created by admin on 11/8/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "PCCameraBaseAlert.h"
#import "PCCameraPreviewView.h"
#import "PCCameraControlView.h"


/**
 镜头选择
 */
@interface PCCameraLensesView : PCCameraBaseAlert

@property (nonatomic, weak) PCCameraPreviewView *cameraPreviewView;
@property (nonatomic, weak) PCCameraControlView *cameraControlView;

@end
