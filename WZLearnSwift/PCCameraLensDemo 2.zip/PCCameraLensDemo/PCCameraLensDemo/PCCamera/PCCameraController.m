//
//  PCCameraController.m
//  PCCameraLensDemo
//
//  Created by admin on 8/8/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "PCCameraController.h"
#import "PCCameraControlView.h"
#import "PCCameraPreviewView.h"
#import "PCCameraSettingView.h"
#import "PCCameraGIFSettingView.h"
#import "PCCameraLensesView.h"
#import "PCParameterManager.h"
#import "PCCaptureProductController.h"
#import "PCCameraGIFSettingView.h"
#import "PCCameraMoreSettingView.h"
#import "PCPickGIFImagesController.h"
#import "WZCollectionItemSorter.h"
#import "PCGIFTool.h"

#import "PCCamera.h"

#import "WZToast.h"

@interface PCCameraController ()

@property (nonatomic, strong) PCCameraControlView *cameraControlView;   //控制层
@property (nonatomic, strong) PCCameraPreviewView *cameraPreviewView;   //预览层

@property (nonatomic, strong) CMMotionManager *motionManager; // 手机方向检查

//@property (nonatomic, strong) PCCameraSettingView *cameraSettingView;   //设置层
//@property (nonatomic, strong) PCCameraGIFSettingView * cameraGIFSettingView; //GIF 设置层
//@property (nonatomic, strong) PCCameraLensesView *cameraLensesView;     //镜头类型层

@property (nonatomic, strong) NSMutableArray *swiftImagesMArr;//快捷拍图的图片组 或者而是图片信息组
@property (nonatomic, strong) NSMutableArray *JigsawImagesMArr;//拼图的图片组或者是信息组
@property (nonatomic, strong) NSMutableArray *fourfoldimagesMArr;//四格LOMO图片组或者是信息组

@property (nonatomic, assign) VideoCameraViewOrientationMode currentOrientationMode;//方向

@end

@implementation PCCameraController

#pragma mark - Life Cycle

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createViews];
    
    // 监测手机旋转方向
    [self addCMMotionToMobile];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.navigationController.navigationBarHidden = true;
}


- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    [PCParameterManager saveConfiguration];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(willResignActiveNotification:) name:UIApplicationWillResignActiveNotification object:nil];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    NSLog(@"%s", __FUNCTION__);
    //清除定时器 等缓存
    [self.cameraPreviewView GIFFinishedCapturing];
    [self.cameraControlView timerClear];
}

#pragma mark - Private Method

- (void)createViews {
    self.automaticallyAdjustsScrollViewInsets = false;
    self.view.backgroundColor = [UIColor whiteColor];
    
    _swiftImagesMArr = [NSMutableArray array];
    _JigsawImagesMArr = [NSMutableArray array];
    _fourfoldimagesMArr = [NSMutableArray array];
    
    _cameraPreviewView = [[PCCameraPreviewView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview:_cameraPreviewView];
    
    _cameraControlView = [[PCCameraControlView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview:_cameraControlView];
    _cameraControlView.delegate = (id<PCCameraControlViewProtocol>)self;
    _cameraControlView.cameraPreviewView = _cameraPreviewView;
    _cameraPreviewView.cameraControlView = _cameraControlView;
}

#pragma mark - UI代理 PCCameraControlViewProtocol
//切换镜头
- (void)cameraControlViewDidClickedLensButton {
    //更改配置  配置隐藏的Manager内部
    [PCParameterManager switchLensPosition];//切换镜头属性
    [self.cameraPreviewView.camera switchCameraPosition];//切换镜头动作
    [self.cameraControlView updateLensUI];//更新与镜头相关联的UI
}

//切换闪光灯
- (void)cameraControlViewDidClickedFlashButton {
    self.cameraPreviewView.camera.flashMode = [PCParameterManager switchFlashMode];//切换闪光灯mode
    [self.cameraControlView updateFlashUI];//更新与闪光灯相关联的UI
}
//退出按钮
- (void)cameraControlViewDidClickedQuitButton {
    [self.cameraPreviewView shutdown];//关闭镜头
    [self.navigationController popViewControllerAnimated:true];
}
//快门按钮
- (void)cameraControlViewDidClickedShutterButton {
    //判断快门的类型
    __weak typeof(self) weakSelf = self;
    switch (self.cameraPreviewView.lensesType) {
//传统镜头
        case PCCameraLensesTypeTradition: {
            //直接拍完进入到下一页 进行处理
            [self.cameraPreviewView takeStillImagePhotoWithCompletion:^(UIImage *image, NSDictionary *dic) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    PCCaptureProductController *VC = [[PCCaptureProductController alloc] init];
                    VC.imageView.image = image;
                    [weakSelf presentViewController:VC animated:true completion:^{}];
                });
            }];
        } break;
//快速拍照
        case PCCameraLensesTypeSwift: {
            //拍完继续拍 显示一个button
            [self.cameraPreviewView takeStillImagePhotoWithCompletion:^(UIImage *image, NSDictionary *dic) {
                //图片回调给另外的一个UI
                dispatch_async(dispatch_get_main_queue(), ^{
                    [weakSelf.swiftImagesMArr addObject:image];
                    [weakSelf.cameraControlView swiftCount:[NSString stringWithFormat:@"%ld", weakSelf.swiftImagesMArr.count]];
                    [WZToast toastWithContent:[NSString stringWithFormat:@"%@", image]];
                });
            }];
        } break;
//拼图
        case PCCameraLensesTypeJigsaw: {
             //拍制定的照片数目
             //图片回调给另外的一个UI

        } break;
//双重曝光
        case PCCameraLensesTypeDoubleExposure: {
            //双重曝光 2张重叠的图
             //图片回调给另外的一个UI
        } break;
//微距
        case PCCameraLensesTypeMicrospur:{
            
        } break;
//GIF
        case PCCameraLensesTypeGIF: {
            //显示GIF系列的UI
          
            if ([PCParameterManager GIFRecordMode] == 0) {
                //自动mode
                if (self.cameraPreviewView.GIFCaptureMode == PCCameraGIFCaptureModeCapturing
                    || self.cameraPreviewView.GIFCaptureMode == PCCameraGIFCaptureModePreheat) {
                    [self.cameraPreviewView GIFFinishedCapturing];
                    NSLog(@"暂停捕捉帧");
                } else {
                    
                    NSLog(@"开始捕捉帧");
                    [self.cameraPreviewView GIFStartCapturing];
                }
            } else {
                //手动mode
                self.cameraPreviewView.GIFCaptureMode = PCCameraGIFCaptureModeCapturing;
            }
           
        } break;
//4格LOMO
        case PCCameraLensesTypeFourfoldLOMO: {
            //显示四格LOMO系列的UI
#warning  更改滤镜
            NSLog(@"显示四格LOMO系列的UI");
        } break;
            
        case PCCameraLensesTypeNone:
        default:
            break;
    }
}

//镜头参数
- (void)cameraControlViewDidClickedLensTypeButton {
    PCCameraLensesView *cameraLensesView = [[PCCameraLensesView alloc] init];
    cameraLensesView.cameraPreviewView = self.cameraPreviewView;
    cameraLensesView.cameraControlView = self.cameraControlView;
    [cameraLensesView alertShow];
}

//设置按钮
- (void)cameraControlViewDidClickedSettingButton {
    switch (self.cameraPreviewView.lensesType) {
        case PCCameraLensesTypeTradition:
        case PCCameraLensesTypeSwift:
        case PCCameraLensesTypeJigsaw:
        case PCCameraLensesTypeDoubleExposure:
        case PCCameraLensesTypeMicrospur:{
            PCCameraSettingView *cameraSettingView = [[PCCameraSettingView alloc] init];
            cameraSettingView.delegate = (id<PCCameraSettingViewProtocol>)self;
            [cameraSettingView alertShow];
//            _cameraSettingView = cameraSettingView;
            if (self.cameraPreviewView.lensesType == PCCameraLensesTypeJigsaw) {
                //改UI
            }
            
        } break;
    
        case PCCameraLensesTypeGIF: {
            //显示GIF系列的UI
            NSLog(@"显示GIF系列的UI");
            PCCameraGIFSettingView *cameraGIFSettingView = [[PCCameraGIFSettingView alloc] init];
            cameraGIFSettingView.delegate = (id<PCCameraGIFSettingViewProtocol>)self;
            [cameraGIFSettingView alertShow];
        } break;
        case PCCameraLensesTypeFourfoldLOMO: {
            //显示四格LOMO系列的UI
            
            NSLog(@"显示四格LOMO系列的UI");
        } break;
            
        case PCCameraLensesTypeNone:
        default:
            break;
    }
}

//调整镜头比例
- (void)cameraControlViewDidClickedLensRate:(NSNumber *)lenRate {
    [self.cameraPreviewView adjustSizeWithClipScale:lenRate.floatValue];
}

//点击快速拍照图片的事件
- (void)cameraControlViewDidClickedSwiftImages {
    [WZToast toastWithContent:[NSString stringWithFormat:@"%@", self.swiftImagesMArr]];
}

- (void)mix {
    NSMutableArray *tmpMArr = [NSMutableArray array];
    if (self.cameraPreviewView.GIFImagesInfoMArr.count) {
        //        CGFloat interval = 8.0 / _imagesArr.count;//拍摄的时间/录到的图片数目;
        for (int i = 0; i < self.cameraPreviewView.GIFImagesInfoMArr.count; i++) {
            WZCollectionItem *item = [[WZCollectionItem alloc] init];
            item.clearImage = self.cameraPreviewView.GIFImagesInfoMArr[i];
            [tmpMArr addObject:item];
        }
    }
    PCPickGIFImagesController *VC =[PCPickGIFImagesController new];
    VC.dataMArr = tmpMArr;
    [self.navigationController setToolbarHidden:true];
    [self.navigationController pushViewController:VC animated:true];
   
}


#pragma mark - PCCameraSettingViewProtocol
//相册
- (void)cameraSettingViewClickedAlbum {
    [WZToast toastWithContent:@"album"];
}
//比例切换
- (void)cameraSettingViewClickedScaleWithType:(NSNumber *)type {
    NSLog(@"%s -----%@", __func__, type);
    if ([type integerValue] == 0) {
        self.cameraPreviewView.previewCrop = kVideoCameraPreviewPhotoCrop1To1;
    } else if ([type integerValue] == 1) {
        self.cameraPreviewView.previewCrop = kVideoCameraPreviewPhotoCrop9To16;
    } else if ([type integerValue] == 2) {
        self.cameraPreviewView.previewCrop = kVideoCameraPreviewPhotoCrop3To4;
    }
}
//构思图
- (void)cameraSettingViewClickedConceptionWithType:(NSNumber *)type {
    NSLog(@"%s -----%@", __func__, type);
}
//定时
- (void)cameraSettingViewClickedTimingWithType:(NSNumber *)type {
    NSLog(@"%s -----%@", __func__, type);
    [PCParameterManager setShutterWithTiming:type.integerValue];//切换定时的时候就更改这个输入这个状态
    
    //设置处 抛出是否需要定时的信息  cameraControlView 需要处理改信息
    [self.cameraControlView updateShutterUI];

    //更新UI
}
//全屏快门
- (void)cameraSettingViewClickedFullScreenShutterWithType:(NSNumber *)type {
    NSLog(@"%s -----%@", __func__, type);
    [PCParameterManager setFullScreenShutter:type.boolValue];//设置当前的镜头mode的状态
    //控制某个变量
}
//更多
- (void)cameraSettingViewClickedMore {
    PCCameraMoreSettingView *moreSettingView = [[PCCameraMoreSettingView alloc] init];
    moreSettingView.bgView.backgroundColor = [UIColor orangeColor];
    [moreSettingView alertShow];
}

#pragma mark - PCCameraGIFSettingViewProtocol
//构思图
- (void)cameraGIFSettingViewClickedConceptionWithType:(NSNumber *)type {
//勾线图
    [self cameraSettingViewClickedConceptionWithType:type];
}
//画幅
- (void)cameraGIFSettingViewClickedPictureWithType:(NSNumber *)type {
//0:小   1:大
    [PCParameterManager setGIFPictureMode:[type unsignedIntegerValue]];
    if ([type integerValue] == 0) {
        
    } else {
        
    }
}
//录制mode
- (void)cameraGIFSettingViewClickedRecordModeWithType:(NSNumber *)type {
//0:自动  1:手动
     [PCParameterManager setGIFRecordMode:[type integerValue]];
    if ([type integerValue] == 0) {
        
    } else {
        
    }
}
//GIF的张数
- (void)cameraGIFSettingViewClickedPictueCountWithType:(NSNumber *)type {
 //0：24  1：36  3：48
    if ([type integerValue] == 0) {
        [PCParameterManager setGIFPictureCount:24];
    } else if ([type integerValue] == 1) {
        [PCParameterManager setGIFPictureCount:36];
    } else {
        [PCParameterManager setGIFPictureCount:48];
    }
}

#pragma mark - And So On

//配置更新
- (void)updateConfig {
    
}

//相机配置初始化还原
- (void)cameraConfigInitialize {
    [PCParameterManager resetConfiguration];
    //reset camera 初始化UI的操作
}

- (void)addCMMotionToMobile {
    _motionManager = [[CMMotionManager alloc] init];
    if (_motionManager.isAccelerometerAvailable) {
        _motionManager.accelerometerUpdateInterval = 1.0/3.0; // 1秒钟采样5次
        //得到一个检查方向的回调
        
        __weak typeof(self) weakSelf = self;
        [ _motionManager startAccelerometerUpdatesToQueue:[NSOperationQueue mainQueue] withHandler:^(CMAccelerometerData *accelerometerData, NSError *error) {
            CMAcceleration acceleration = weakSelf.motionManager.accelerometerData.acceleration;
            if (acceleration.x < -0.8 && (0.5>acceleration.y >-0.8)) {
                weakSelf.currentOrientationMode = kVideoCameraViewOrientationModeLeft;
                //左边
            }else if (acceleration.x > 0.8 && (0.5>acceleration.y >-0.2)) {
                weakSelf.currentOrientationMode = kVideoCameraViewOrientationModeRight;
                //右边
            }else if((0.7>=acceleration.x >=-0.7) && acceleration.y > 0.9) {
                weakSelf.currentOrientationMode = kVideoCameraViewOrientationModeUpSideDown;
                //颠倒
            }else if((0.3>=acceleration.x >=-0.3) && acceleration.y < -0.7) {
                weakSelf.currentOrientationMode = kVideoCameraViewOrientationModePortrait;
                //正面
            }
        }];
    }
}

#pragma mark - Accesssor
//根据当前设备方向设置UI
- (void)setCurrentOrientationMode:(VideoCameraViewOrientationMode)currentOrientationMode {
    if (_currentOrientationMode == currentOrientationMode) {
        return;
    }
    _currentOrientationMode = currentOrientationMode;
#warning 更新各个UI的方向
    self.cameraPreviewView.currentOrientationMode = _currentOrientationMode;
    self.cameraControlView.currentOrientationMode = _currentOrientationMode;
}



#pragma mark - 通知
- (void)willResignActiveNotification:(NSNotification *)notification {
    NSLog(@"%s", __func__);
    
    [PCParameterManager saveConfiguration];
}
@end
