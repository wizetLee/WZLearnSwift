//
//  PCCameraGIFSettingView.h
//  PCCameraLensDemo
//
//  Created by admin on 11/8/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "PCCameraBaseAlert.h"
#import "PCParameterManager.h"

@protocol PCCameraGIFSettingViewProtocol <NSObject>

//构思图
- (void)cameraGIFSettingViewClickedConceptionWithType:(NSNumber *)type;
//画幅
- (void)cameraGIFSettingViewClickedPictureWithType:(NSNumber *)type;
//录制mode
- (void)cameraGIFSettingViewClickedRecordModeWithType:(NSNumber *)type;
//GIF的张数
- (void)cameraGIFSettingViewClickedPictueCountWithType:(NSNumber *)type;

@end

/**
 GIF的设置view
 */
@interface PCCameraGIFSettingView : PCCameraBaseAlert

@property (nonatomic, weak) id <PCCameraGIFSettingViewProtocol> delegate;


@end
