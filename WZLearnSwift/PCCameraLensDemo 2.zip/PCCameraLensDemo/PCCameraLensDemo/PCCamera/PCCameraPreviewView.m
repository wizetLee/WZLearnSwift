//
//  PCCameraPreviewView.m
//  PCCameraLensDemo
//
//  Created by admin on 8/8/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "PCCameraPreviewView.h"
#import <Photos/Photos.h>
#import "OIView.h"
#import "OIFilter.h"
#import "OIMediaCaptor.h"
#import "OISwitchFilter.h"
#import "WZToast.h"
#import "PCCameraControlView.h"
#import "OIGIFWriter.h"


@interface PCCameraPreviewView()<OIMediaCaptorDelegate>

@property (nonatomic, strong) OIView *previewView;          // 预览界面(尺寸为界面大小)
@property (nonatomic, strong) OIFilter *emptyCropFilter;    // 只负责裁剪，不负责缩放，好处是这个可以直接输出给writer，不需要调整(注意：拍摄视频用这个filter来作为writer的输入)
@property (nonatomic, strong) OIFilter *emptyScaleFilter;   // 负责缩放
@property (nonatomic, strong) OIFilter *currentFilter;      // 当前滤镜
//@property (nonatomic, strong) OISwitchFilter *switchFilter; // 切换滤镜类

@property (nonatomic, assign) BOOL isCapturingStillImage;   //是否正在捕捉图片

////GIF  only
@property (nonatomic, strong) NSMutableArray *GIFImagesInfoMArr;//GIF捕捉到的图片实体
@property (nonatomic, assign) CGFloat GIFCaptureTime;//捕捉时间
@property (nonatomic, strong) NSTimer *GIFTimer;//捕捉计时器
////GIF




//切换更改滤镜是一个同步操作
/*************************************/
#define IsIPAD false

#define SCREEN_WIDTH  [UIScreen mainScreen].bounds.size.width
#define SCREEN_HEIGHT  [UIScreen mainScreen].bounds.size.height

#define PreviewViewWidth (SCREEN_WIDTH * Adjust_ScreenScale)
#define PreviewViewHeight (SCREEN_HEIGHT * Adjust_ScreenScale)
#define PreviewViewScale (SCREEN_HEIGHT / SCREEN_WIDTH)

#define Adjust_ScreenScale 2
@property (nonatomic, assign) CGFloat captorWidth;
@property (nonatomic, assign) CGFloat captorHeight;
/*************************************/

@end

@implementation PCCameraPreviewView

@synthesize lensesType = _lensesType;

#pragma mark - Initialization
- (instancetype)init {
    if (self = [super init]) {
        [self createViews];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self createViews];
    }
    return self;
}

- (void)dealloc {
    NSLog(@"%s", __func__);
    [self GIFTimerClear];
}

#pragma mark - Private Method

- (void)createViews {
   
    //配置完滤镜之后启动镜头
    [self configCamera];
    [self configFilters];

    //切换镜头的类
//    self.switchFilter = [[OISwitchFilter alloc] init];
    
    //镜头开启
    [self.camera startRunning];
    //状态矫正
    [self updateStatus];
}

- (void)updateStatus {
//调尺寸
    if ([PCParameterManager imageOutputSizeMode] == OIMediaCaptorOutputSizeMode4To3) {
        [self setPreviewCrop:kVideoCameraPreviewPhotoCrop3To4];
    } else if ([PCParameterManager imageOutputSizeMode] == OIMediaCaptorOutputSizeMode1To1) {
        [self setPreviewCrop:kVideoCameraPreviewPhotoCrop1To1];
    } else if ([PCParameterManager imageOutputSizeMode] == OIMediaCaptorOutputSizeMode16To9) {
        [self setPreviewCrop:kVideoCameraPreviewPhotoCrop9To16];
    }
    
#warning 还有镜头方向需要调整  暂无接口
//获取默认镜头方向
    AVCaptureDevicePosition positioin = [PCParameterManager lensPosition];
//闪光灯mode
    self.camera.flashMode = [PCParameterManager flashMode];
//定时拍照
   
    self.GIFCaptureMode = PCCameraGIFCaptureModePause;//一开始是空闲
    
    //当前的镜头mode
    PCCameraLensesType lensType = [PCParameterManager currentLensType];
    
//根据镜头取改UI
    switch (lensType) {
        case PCCameraLensesTypeTradition: {
            
        } break;
        case PCCameraLensesTypeSwift: {
            
        } break;
        case PCCameraLensesTypeJigsaw: {
            
        } break;
        case PCCameraLensesTypeGIF: {
            
        } break;
        case PCCameraLensesTypeDoubleExposure: {
            
        } break;
        case PCCameraLensesTypeFourfoldLOMO: {
            
        } break;
        case PCCameraLensesTypeMicrospur: {
            
        } break;
        
        case PCCameraLensesTypeNone:
        default:
            break;
    }
}

- (void)configFilters {
    //分别是 裁剪尺寸的滤镜  缩放的动画  当前画面使用的滤镜
    self.emptyCropFilter    = [[OIFilter alloc] init];   //剪裁滤镜只是负责剪裁
    self.emptyScaleFilter   = [[OIFilter alloc] init];
    self.currentFilter      = [[OIFilter alloc] init];
    
    //先换掉滤镜
    
    //色调滤镜
//    self.currentFilter      = [[OIToneFilter alloc] initWithRed:0.1 green:0.5 blue:0.1 percentage:0.5];
  
    self.previewView        = [[OIView alloc] initWithFrame:self.bounds];
    self.previewView.enabled = true;//输入mode  true
    
    [self addSubview:self.previewView];
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(pan:)];//镜头缩放手势
    [self.previewView addGestureRecognizer:pan];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap:)];//控制焦点手势
    [self.previewView addGestureRecognizer:tap];
    
    //镜头 -> 裁剪filter -> 缩放filter -> OIView
    //输出累计过程...
    [self.camera addConsumer:self.emptyCropFilter];
    [self.emptyCropFilter addConsumer:self.currentFilter];
    [self.currentFilter addConsumer:self.emptyScaleFilter];
//    [self.emptyCropFilter addConsumer:self.previewView];
    [self.emptyScaleFilter addConsumer:self.previewView];//最后输出到这里
//    [self.emptyCropFilter addConsumer:self.previewView];
    
    
    
//    ((OIToneFilter *)self.currentFilter).anchorPoint = CGPointMake(0.5, 0.5);
//    ((OIToneFilter *)self.currentFilter).degrees = M_PI /2.0;
    
    
}

- (void)configCamera {

    AVCaptureDevicePosition positioin = [PCParameterManager lensPosition];//获取默认镜头参数
    self.camera = [[PCCamera alloc] initWithCameraMode:OIMediaCaptorCameraModeStillImage
                                        cameraPosition:positioin
                                         sessionPreset:AVCaptureSessionPresetPhoto];
    self.camera.delegate = self;
    //base parameters
    self.camera.enableSmoothAutoFocus = true;
    self.camera.enableVideoStabilization = true;//判断can
    self.camera.frameRate = 25;
    self.camera.exposureMode = AVCaptureExposureModeContinuousAutoExposure;
    self.camera.focusMode = AVCaptureFocusModeContinuousAutoFocus;
    self.camera.flashMode = [PCParameterManager flashMode];
    
//    [self.camera switchCameraPosition];//换镜头
//    self.camera.exposurePoint
//    self.camera.focusPoint
    //转换比例
//    self.cameraMode = kVideoCameraModeVideo;
}

- (void)shutdown {
    [self.camera stopRunning];
}

//控制焦点 控制 大量的逻辑计算 and so on
#pragma mark - 尺寸矫正 根据<<高宽比>>矫正所有滤镜的尺寸
/**
 iPhone  
        stillImage  : 1:1   \16:9   \4:3
        video       : 1:1   \16:9   \9:16   \1:2.35
 
 iPad 
        stillImage  : 1:1   \16:9   \4:3
        video       : 1:1   \16:9   \9:16   \1:2.35
 */
//设置剪裁格式
- (void)setPreviewCrop:(VideoCameraPreviewCrop)previewCrop {
    _previewCrop = previewCrop;
    switch (previewCrop) {
        case kVideoCameraPreviewCrop1To1:
            [self adjustSizeWithClipScale:1.0/1.0];
            break;
        case kVideoCameraPreviewCrop4To3:
            [self adjustSizeWithClipScale:3.0/4.0];
            break;
        case kVideoCameraPreviewCrop16To9:
            [self adjustSizeWithClipScale:9.0/16.0];
            break;
        case kVideoCameraPreviewCrop235To1:
            // 取消2.35
            //            if (self.currentOrientationMode == kVideoCameraViewOrientationModeLeft || self.currentOrientationMode == kVideoCameraViewOrientationModeRight) {
            //                [self adjustSizeWithClipScale:9.0/16.0];
            //            } else {
            [self adjustSizeWithClipScale:16.0/9.0];
            //            }
            break;
        case kVideoCameraPreviewCrop9To16:
            [self adjustSizeWithClipScale:16.0/9.0];
            break;
            
            // TODO
        case kVideoCameraPreviewPhotoCrop1To1:
            [self adjustSizeWithClipScale:1.0/1.0];
            break;
        case kVideoCameraPreviewPhotoCrop3To4:
            [self adjustSizeWithClipScale:3.0/4.0];
            break;
        case kVideoCameraPreviewPhotoCrop9To16:
            [self adjustSizeWithClipScale:9.0/16.0];
            break;
            
        case kVideoCameraPreviewVideoCrop1To1:
            [self adjustSizeWithClipScale:1.0/1.0];
            break;
        case kVideoCameraPreviewVideoCrop9To16:
            [self adjustSizeWithClipScale:9.0/16.0];
            break;
            
            ///视频的录制方向的设定
        case kVideoCameraPreviewVideoCrop16To9:
            if (self.currentOrientationMode == kVideoCameraViewOrientationModeLeft
                || self.currentOrientationMode == kVideoCameraViewOrientationModeRight) {
                [self adjustSizeWithClipScale:9.0/16.0];
            } else {
                [self adjustSizeWithClipScale:16.0/9.0];
            }
            break;
            
            ///视频的录制方向  iPad
        case kVideoCameraPreviewVideoCrop235To1:
            if (self.currentOrientationMode == kVideoCameraViewOrientationModeLeft
                || self.currentOrientationMode == kVideoCameraViewOrientationModeRight) {
                [self adjustSizeWithClipScale:1.0/2.35];
            } else {
                [self adjustSizeWithClipScale:2.35/1.0];
            }
            break;
    }
}

#pragma mark - 注意  下面这一套逻辑似乎只能用在AVCaptureSessionPresetPhoto（或者是3：4画质预设）的类型中
/*
 contenSize 控制帧输出内容的范围
 outputFrame 控制帧输出到屏幕的位置
 */
//算这个裁剪的比例必须要 清楚outputFrame 和 contentSize 的位置
- (void)adjustSizeWithClipScale:(CGFloat)clipScale {
    //基础比例    如果是图片 3：4   如果是video 9：16    width / height
    CGFloat basicScale = self.cameraMode == kVideoCameraModeStillImage ? 3.0/4.0 : 9.0/16.0;
//基础比例 和 当前的剪裁比例对比
    if ((basicScale - clipScale) > 0) {
// 始终为9 ： 16 即： 全屏
        // ---调整x(目前仅适用于静态图下的9:16)---
        // 裁剪

        
#warning -(basicScale - clipScale)/2.0;//个人猜测 因为 9：16 中的height 比width大  在进行3：4到9：16的转换过程高是不变的宽度有余，因此outputframe需要向中靠拢
        self.camera.outputFrame = CGRectMake(-(basicScale - clipScale)/2.0*self.captorHeight//调整X是为了调整9：16修剪的位置
                                             , 0
                                             , self.captorWidth
                                             , self.captorHeight);
        
        
        //由于buffer 中输出的帧的比例总是  w/h = 3: 4  因此 self.captorWidth/self.captorHeight = 3/4
        
        
        CGFloat contentSizeW = self.captorHeight*clipScale;
        CGFloat contentSizeH = self.captorHeight;
        self.emptyCropFilter.contentSize = CGSizeMake(contentSizeW , contentSizeH);
        self.emptyCropFilter.outputFrame = CGRectMake(0
                                                      , 0
                                                      , contentSizeW
                                                      , contentSizeH);
        
        //调整缩放比例视图大小
        self.emptyScaleFilter.contentSize = CGSizeMake(contentSizeW
                                                       , contentSizeH);
        
        //处理缩放的比例
        if (PreviewViewWidth > PreviewViewHeight*clipScale/*用于判断当前的...*/
            && self.cameraMode == kVideoCameraModeVideo) {
//录像mode
            // 这个临时加给横向2.35：1的
            self.emptyScaleFilter.outputFrame = CGRectMake((PreviewViewWidth - PreviewViewHeight*clipScale)/2.0
                                                           , 0
                                                           , integerSingleDigits(PreviewViewHeight*clipScale)
                                                           , integerSingleDigits(PreviewViewHeight));
        } else {
//静态图mode
            if (IsIPAD) {
            //iPad
                self.emptyScaleFilter.outputFrame = CGRectMake((basicScale - clipScale)/2.0*self.captorHeight
                                                               , 0
                                                               , self.emptyCropFilter.contentSize.width
                                                               , self.emptyCropFilter.contentSize.height);
            } else {
            //iPhone
                self.emptyScaleFilter.outputFrame = CGRectMake(0
                                                               , 0
                                                               , PreviewViewWidth
                                                               , PreviewViewHeight);
            }
        }
    } else {
//情况可能为 1:1  3: 4  16:9 and so on
        // ---调整y---
        // 裁剪
        //更改输出范围
  

        //y值上移动
        //最顶上的比例中多余的部分去掉
        self.camera.outputFrame = CGRectMake(0
                                             , integerSingleDigits(-(1.0/basicScale - 1.0/clipScale)/2.0/(1.0/basicScale)*self.captorHeight)
                                             //修改Y就是为了调整输入的内容的位置
                                             , self.captorWidth
                                             , self.captorHeight);
        
        //去掉个位的值得作用是？
        CGFloat contentSizeW = integerSingleDigits(self.captorWidth);
        CGFloat contentSizeH = integerSingleDigits(self.captorWidth/clipScale);
        self.emptyCropFilter.contentSize = CGSizeMake(contentSizeW
                                                      //注意height的大小
                                                      , contentSizeH);
        self.emptyCropFilter.outputFrame = CGRectMake(0
                                                      , 0
                                                      , contentSizeW
                                                      , contentSizeH);
        // 调整视图大小
        self.emptyScaleFilter.contentSize = CGSizeMake(contentSizeW
                                                       , contentSizeH);
        //输出的始终为满屏的效果
        self.emptyScaleFilter.outputFrame = CGRectMake(0
                                                       , (PreviewViewScale - 1.0/clipScale)/2.0/PreviewViewScale*PreviewViewHeight
                                                       , integerSingleDigits(PreviewViewWidth)
                                                       , integerSingleDigits(PreviewViewWidth/clipScale));
    }
    

//当前滤镜输入和输出都与剪裁的滤镜一致
    self.currentFilter.contentSize = self.emptyCropFilter.contentSize;
    self.currentFilter.outputFrame = self.emptyCropFilter.outputFrame;
    
    // 调整switchFilter
//    self.switchFilter.contentSize = self.emptyCropFilter.contentSize;
//    self.switchFilter.outputFrame = CGRectMake(0
//                                               , 0
//                                               , self.emptyCropFilter.outputFrame.size.width
//                                               , self.emptyCropFilter.outputFrame.size.height);
    

//    self.videoOutputSize = self.emptyCropFilter.contentSize;
    
//    if (!IsIPAD) {
//        if (ABS(self.emptyScaleFilter.outputFrame.origin.y) > 1.0 ){//&& self.cameraMode == kVideoCameraModeStillImage) {
//            // 向上移动preView的y值
//            CGFloat ScaleFilterOriginY3To4 = (PreviewViewScale - 1.0/(3.0/4.0))/2.0/PreviewViewScale*PreviewViewHeight;
//            CGFloat movePosition = ScaleFilterOriginY3To4/Adjust_ScreenScale - 50.0; // 50是topbar高度
//            //向上移动
//            self.previewView.frame = CGRectMake(0
//                                                , -movePosition
//                                                , self.previewView.frame.size.width
//                                                , self.previewView.frame.size.height);
//        } else {
//            self.previewView.frame = self.bounds;
//        }
//    }
    
    //    self.previewView.enabled = YES;
//    if ([self.delegate respondsToSelector:@selector(previewAdjustFrame:)]) {
//        CGRect previewAdjustFrame = CGRectMake(self.emptyScaleFilter.outputFrame.origin.x/Adjust_ScreenScale, self.emptyScaleFilter.outputFrame.origin.y/Adjust_ScreenScale + self.previewView.frame.origin.y, self.emptyScaleFilter.outputFrame.size.width/Adjust_ScreenScale, self.emptyScaleFilter.outputFrame.size.height/Adjust_ScreenScale);
//        [self.delegate previewAdjustFrame:previewAdjustFrame];
//    }
    NSLog(@"=============================================================================================");
    NSLog(@"self.camera.outputFrame : %@", NSStringFromCGRect(self.camera.outputFrame));
    NSLog(@"self.emptyCropFilter.contentSize : %@", NSStringFromCGSize(self.emptyCropFilter.contentSize));
    NSLog(@"self.emptyCropFilter.outputFrame : %@", NSStringFromCGRect(self.emptyCropFilter.outputFrame));
    NSLog(@"self.currentFilter.contentSize : %@", NSStringFromCGSize(self.currentFilter.contentSize));
    NSLog(@"self.currentFilter.outputFrame : %@", NSStringFromCGRect(self.currentFilter.outputFrame));
    NSLog(@"self.emptyScaleFilter.contentSize : %@", NSStringFromCGSize(self.emptyScaleFilter.contentSize));
    NSLog(@"self.emptyScaleFilter.outputFrame : %@", NSStringFromCGRect(self.emptyScaleFilter.outputFrame));//仅仅是为了移动View
}

#pragma mark - OIMediaCaptorDelegate
// 返回捕捉的sampleBuffer
- (void)captorWillOutputVideoSampleBuffer:(CMSampleBufferRef)sampleBuffer {
    //判断当前是video还是stillImage 的 capture

    if (self.lensesType == PCCameraLensesTypeGIF
        && self.GIFCaptureMode == PCCameraGIFCaptureModeCapturing) {
        @synchronized (self) {
            
//            OIGIFWriter *GIFWriter = [[OIGIFWriter alloc] init];
//            CVImageBufferRef imageRef = CMSampleBufferGetImageBuffer(sampleBuffer);
//            CIImage *ciImage = [[CIImage alloc] initWithCVImageBuffer:imageRef];
//            
//            UIImage *image = [UIImage imageWithCIImage:ciImage];
            
            CFDictionaryRef exifAttachments = (CFDictionaryRef)CMGetAttachment(sampleBuffer
                                                                               , kCGImagePropertyExifDictionary
                                                                               , NULL);
            NSDictionary *dic = (__bridge NSDictionary *)exifAttachments;
            if (self.GIFImagesInfoMArr.count >= [PCParameterManager GIFPictureCount]) {
                
            } else {
                [self.GIFImagesInfoMArr addObject:dic];
                NSLog(@"%ld", self.GIFImagesInfoMArr.count);
                
                //进度回调至UI
                [self.cameraControlView setGIFProgress:((self.GIFImagesInfoMArr.count * 1.0) / [PCParameterManager GIFPictureCount])];
                
                if ([PCParameterManager GIFRecordMode] == 0) {
                    //自动
                    self.GIFCaptureMode = PCCameraGIFCaptureModePreheat;//状态为《准备下一个状态》
                } else {
                    //手动
                    self.GIFCaptureMode = PCCameraGIFCaptureModePause;//状态为《暂停》
                }
            }
        }
    }
}
- (void)captorWillOutputAudioSampleBuffer:(CMSampleBufferRef)sampleBuffer {
    //判断当前是否要使用音频buffer
}

- (void)captorConfigurationError:(NSError *)error {
    NSLog(@"%@", error.description);
}
- (void)mediaCaptorShouldProcessCapturedStillImageUsingOpenGL {
    NSLog(@"%s", __func__);
}

//根据滤镜的拍照接口
- (void)takeStillImagePhotoWithCompletion:(void (^)(UIImage *, NSDictionary *))completion {
    if (self.cameraMode != kVideoCameraModeStillImage) {
        return;
    }
    if (self.isCapturingStillImage) {
        return;
    }
    self.isCapturingStillImage = YES;//拍摄状态
    
    OIMediaCaptorOutputSizeMode sizeMode;//比例控制
    switch (self.previewCrop) {
        case kVideoCameraPreviewPhotoCrop1To1:
            sizeMode = OIMediaCaptorOutputSizeMode1To1;
            break;
        case kVideoCameraPreviewPhotoCrop3To4:
            sizeMode = OIMediaCaptorOutputSizeMode4To3;
            break;
        case kVideoCameraPreviewPhotoCrop9To16:
            sizeMode = OIMediaCaptorOutputSizeMode16To9;
            break;
        default:
            sizeMode = OIMediaCaptorOutputSizeMode4To3;
            break;
    }
    
    self.previewView.enabled = NO;//不可点击
    
    
    //加入滤镜就可以了
    NSMutableArray *filtersMArr = [NSMutableArray array];
    [filtersMArr addObject:self.emptyCropFilter];
    [filtersMArr addObject:self.currentFilter];
  
    if ([PCParameterManager currentLensType] == PCCameraLensesTypeFourfoldLOMO) {
//     [filtersMArr addObject:self.currentFilter];
        //滤镜加入一个切线的滤镜
    }
    [self.camera captureProcessedImageWithFinalFilter:filtersMArr cropRect:sizeMode AsynchronouslyWithCompletionHandler:^(UIImage *processedImage, NSError *error) {
        
        [self setPreviewCrop:self.previewCrop];//拍完照片：恢复当前的outputFrame 和 contensize
        
    
        self.previewView.enabled = YES;//revocer 点击
        
        self.isCapturingStillImage = NO;
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            completion(processedImage, self.camera.currentCaptureMetaData);
        });
        
        if ([PCParameterManager savePictureAuto]) {
            [PCParameterManager savePhotoWithImage:processedImage handler:^(BOOL success, NSError *error) {
                if (success) {
                    [WZToast toastWithContent:@"图片自动保存到相册成功" position:WZToastPositionTypeBottom];
                }
            }];
        }
    }];
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
//负责全屏快门
   
    if ([PCParameterManager fullScreenShutter]) {
        [self.cameraControlView activateShutteringWithTiming];
    }
}

//手势
- (void)pan:(UIPanGestureRecognizer *)pan {
//    CGPoint point = [pan locationInView:self.previewView];
    //    [self.camera rampToVideoZoomFactor:0.5 withRate:0.5];//
 
    if (pan.state == UIGestureRecognizerStateBegan) {
        
    } else if (pan.state == UIGestureRecognizerStateChanged) {
        
    } else if (pan.state == UIGestureRecognizerStateEnded) {
        
    }
}

- (void)tap:(UITapGestureRecognizer *)tap {
    
}

/********************************************/


/**
 捕捉宽度为《分辨率》而不是屏幕点大小
 @return 捕捉宽度
 */
- (CGFloat)captorWidth {
    return self.camera.outputFrame.size.width == 0 ? PreviewViewWidth : self.camera.outputFrame.size.width;
}

/**
 捕捉高度为《分辨率》而不是屏幕点大小、初始的高度为捕捉宽度的4/3
 @return 捕捉高度
 */
- (CGFloat)captorHeight {
    return self.camera.outputFrame.size.height == 0 ? PreviewViewWidth*(4.0/3.0) : self.camera.outputFrame.size.height;
}


//获得相对点击的点
- (CGPoint)getRelativePoint:(CGPoint)point {
    CGSize captorSize = self.cameraMode == kVideoCameraModeVideo ? CGSizeMake(SCREEN_WIDTH, SCREEN_HEIGHT) : CGSizeMake(SCREEN_WIDTH, SCREEN_WIDTH/3*4);
    CGPoint truePosition = CGPointZero;
    CGPoint relativePoint = CGPointZero;
    switch (self.previewCrop) {
        case kVideoCameraPreviewCrop1To1:{
            truePosition = CGPointMake(point.x, (SCREEN_HEIGHT - SCREEN_WIDTH)/2 + point.y);
            relativePoint = CGPointMake(truePosition.x / captorSize.width, truePosition.y / captorSize.height);
        }
            break;
        case kVideoCameraPreviewCrop4To3:{
            relativePoint = CGPointMake(point.x / captorSize.width, point.y / captorSize.height);
        }
            
            break;
        case kVideoCameraPreviewCrop16To9:{
            // 竖
            relativePoint = CGPointMake(point.x / captorSize.width, point.y / captorSize.height);
        }
            
            break;
        case kVideoCameraPreviewCrop235To1:{
            // 横 9:16
            truePosition = CGPointMake(point.x, (SCREEN_HEIGHT - (SCREEN_WIDTH/16*9))/2 + point.y);
            relativePoint = CGPointMake(truePosition.x / captorSize.width, truePosition.y / captorSize.height);
        }
            
            break;
        case kVideoCameraPreviewCrop9To16:{
            // 横 9:16
            truePosition = CGPointMake(point.x, (SCREEN_HEIGHT - (SCREEN_WIDTH/16*9))/2 + point.y);
            relativePoint = CGPointMake(truePosition.x / captorSize.width, truePosition.y / captorSize.height);
        }
            
            break;
        default:
            break;
    }
    //    NSLog(@"relative = %@",NSStringFromCGPoint(relativePoint));
    return relativePoint;
}

//移除个位的值   有何用意
int integerSingleDigits(float digit) {
    int tmpDigit = digit / 10;
    return tmpDigit * 10;
}

#pragma mark - Accessor
//根据当前设备方向设置UI
- (void)setCurrentOrientationMode:(VideoCameraViewOrientationMode)currentOrientationMode {
    if (_currentOrientationMode == currentOrientationMode) {
        return;
    }
    _currentOrientationMode = currentOrientationMode;
    //四格LOMOmode 需要转换mode
    if ([PCParameterManager currentLensType] == PCCameraLensesTypeFourfoldLOMO) {
        if ([PCParameterManager imageOutputSizeMode] == OIMediaCaptorOutputSizeMode4To3) {
            [self setPreviewCrop:kVideoCameraPreviewPhotoCrop3To4];
        } else if ([PCParameterManager imageOutputSizeMode] == OIMediaCaptorOutputSizeMode1To1) {
            [self setPreviewCrop:kVideoCameraPreviewPhotoCrop1To1];
        } else if ([PCParameterManager imageOutputSizeMode] == OIMediaCaptorOutputSizeMode16To9) {
            [self setPreviewCrop:kVideoCameraPreviewPhotoCrop9To16];
        }
    }
#warning 更新各个UI的方向
    
}

//根据镜头类型切换 UI 和 功能

//每更改一次 就更换一次UI和镜头
- (void)setLensesType:(PCCameraLensesType)lensesType {
    _lensesType = lensesType;
    
    
    if (_lensesType == PCCameraLensesTypeFourfoldLOMO) {
        //如果是四格LOMO  更换滤镜链(外增加一个四格LEMO滤镜)
        
    }
    [PCParameterManager pickLensWithType:_lensesType];//更换镜头的同时也要进行切换
    
    [self updateStatus];
}

- (PCCameraLensesType)lensesType {
    return [PCParameterManager currentLensType];
}

- (NSMutableArray *)GIFImagesInfoMArr {
    if (!_GIFImagesInfoMArr) {
        _GIFImagesInfoMArr = [NSMutableArray arrayWithCapacity:100];
    }
    return _GIFImagesInfoMArr;
}

/********************************************/

#pragma mark - Public  

#pragma mark - GIF Part GIF 操作部分
//开始
- (void)GIFStartCapturing {
    [self GIFTimerFire];
}

//结束
- (void)GIFFinishedCapturing {
    self.GIFCaptureMode = PCCameraGIFCaptureModePause;
    [self GIFTimerClear];
}
//清理缓存
- (void)clearGIFImagesInfo {
    self.GIFImagesInfoMArr = nil;
    self.GIFImagesInfoMArr = [NSMutableArray array];
}
//清理计时器
- (void)GIFTimerClear {
    [_GIFTimer invalidate];
    _GIFTimer = nil;
}

//启动计时器
- (void)GIFTimerFire {
    _GIFCaptureTime = 15.0;//自定义的照片时间
    CGFloat captureInterval = (_GIFCaptureTime * 1.0) / [PCParameterManager GIFPictureCount];//捕捉间隔
    _GIFTimer = [NSTimer scheduledTimerWithTimeInterval:captureInterval target:self selector:@selector(GIFTimer:) userInfo:nil repeats:true];
    [[NSRunLoop mainRunLoop] addTimer:_GIFTimer forMode:NSRunLoopCommonModes];
    [_GIFTimer fire];
}

- (void)GIFTimer:(NSTimer *)timer {
    //从buffer装一个帧到这里 获取图片装载权限
    
    if ([PCParameterManager GIFRecordMode] == 0) {
        if (self.GIFImagesInfoMArr.count >= [PCParameterManager GIFPictureCount]) {
            [self GIFFinishedCapturing];
            [WZToast toastWithContent:[NSString stringWithFormat:@"一共 %ld 张图 点击合成跳转到GIF合成页面", self.GIFImagesInfoMArr.count]];
            //回调
        } else {
            self.GIFCaptureMode = PCCameraGIFCaptureModeCapturing;//转为捕捉状态
        }
    } else {
        [self GIFFinishedCapturing];
    }
}

#pragma mark - 更换滤镜

- (void)setFilter:(OIFilter *)inpFilter {
    [self currentFilterCancelChain];
    self.currentFilter = inpFilter;
    [self currentFilterRebuildChain];
}

// 断开滤镜单链
- (void)currentFilterCancelChain {
    //    [self.emptyCropFilter removeConsumer:self.INPFilter];
    //    [self.INPFilter removeConsumer:self.emptyScaleFilter];
    [self.emptyCropFilter removeAllConsumers];//剪裁链移除所有消费者
    [self.currentFilter removeAllConsumers];//当前链链移除所有消费者
}

// 恢复滤镜单链
- (void)currentFilterRebuildChain {
    [self.emptyCropFilter addConsumer:self.currentFilter];
    [self.currentFilter addConsumer:self.emptyScaleFilter];
}



@end
