//
//  PCCaptureProductController.m
//  PCCameraLensDemo
//
//  Created by admin on 14/8/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "PCCaptureProductController.h"

@interface PCCaptureProductController ()

@end

@implementation PCCaptureProductController

#pragma mark - Life Cycle

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createViews];
}

- (void)dealloc {
    NSLog(@"%s", __func__);
}

#pragma mark - Private Method

- (void)createViews {
    self.view.backgroundColor = [UIColor whiteColor];
    self.automaticallyAdjustsScrollViewInsets = false;
    
    
    [self.view addSubview:self.imageView];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self dismissViewControllerAnimated:true completion:^{
        
    }];
}


#pragma mark - Accessor

- (UIImageView *)imageView {
    if (!_imageView) {
        _imageView = [UIImageView new];
        _imageView.frame = self.view.bounds;
        _imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _imageView;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}


@end
