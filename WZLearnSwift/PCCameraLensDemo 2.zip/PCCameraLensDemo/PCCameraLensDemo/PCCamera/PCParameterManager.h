//
//  PCParameterManager.h
//  PCCameraLensDemo
//
//  Created by admin on 9/8/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "OpenGLESImage.h"


#define PCCAMERA_PARAMETER_SETTING @"PCCamera_parameter_setting"
//设置参数
/*
 0：相册
 1：比例
 2：构图线
 3：定时
 4：全屏快门
 5：更多
 */
//PCCameraSettingView //PCCameraGIFSettingView
    #define PCCAMERASETTINGVIEW_SETTINGTYPE @"PCCameraSettingView_settingType"          //设置类型无符号整形 Number
    #define PCCAMERASETTINGVIEW_SETTINGHEADLINE @"PCCameraSettingView_settingHeadline"  //设置类型标题 STR
    #define PCCAMERASETTINGVIEW_SETTINGSOURCE @"PCCameraSettingView_settingSource"      //设置数据源 DIC
    #define PCCAMERASETTINGVIEW_SETTINGFULLSCREENSHUTTER @"PCCameraSettingView_settingFullScreenShutter"      //设置全屏快门 BOOL
    #define PCCAMERASETTINGVIEW_SETTINGSHUTTERWITHTIMING @"PCCameraSettingView_settingShutterWithTiming"      //定时拍摄 0 3 5
    #define PCCAMERASETTINGVIEW_SETTINGRECORDMODE @"PCCameraSettingView_settingRedcordMode" //GIF 的录制mode
    #define PCCAMERASETTINGVIEW_SETTINGRPICTURE @"PCCameraSettingView_settingPicture" //GIF 的画幅
    #define PCCAMERASETTINGVIEW_SETTINGRPICTURECOUNT @"PCCameraSettingView_settingPictureCount" //GIF 图片数目

//设置镜头
#define PCCAMERA_PARAMETER_LENS @"PCCamera_parameter_lens"

//启动的时候马上开启镜头  :   就是开机直接就跳转到拍照页面
#define PCCAMERA_PARAMETER_LENSPRECEDENCE @"PCCamera_parameter_lensPrecedence"

//定时  延迟读取声音  计时器调用时有声音
#define PCCAMERA_PARAMETER_READDURINGTIMING @"PCCamera_parameter_readDuringTiming"

//照片加上日期   建议在处理图片的时候加  当然也可以自己加
#define PCCameraAAAAAAA  @"弢哥要配合啊"

//拍图自动保存
#define PCCAMERA_PARAMETER_SAVEPICTUREAUTO @"PCCamera_parameter_savePictureAuto"

// 方向
typedef NS_ENUM(NSInteger, VideoCameraViewOrientationMode) {
    kVideoCameraViewOrientationModePortrait,    //
    kVideoCameraViewOrientationModeUpSideDown,
    kVideoCameraViewOrientationModeLeft,
    kVideoCameraViewOrientationModeRight
};

typedef NS_ENUM(NSUInteger, PCCameraLensesType) {
    PCCameraLensesTypeNone                  = 0,
    PCCameraLensesTypeTradition             ,
    PCCameraLensesTypeSwift                 ,
    PCCameraLensesTypeJigsaw                ,
    PCCameraLensesTypeGIF                   ,
    //    PCCameraLensesTypeInteresting           ,
    PCCameraLensesTypeDoubleExposure        ,
    PCCameraLensesTypeFourfoldLOMO          ,
    PCCameraLensesTypeMicrospur             ,
    
};


@import AVFoundation.AVCaptureDevice;
@class PCCameraPreviewView;
/**
 参数保存器
 */
@interface PCParameterManager : NSObject

@property (nonatomic, weak) PCCameraPreviewView *cameraPreviewView;
@property (nonatomic, strong) NSMutableDictionary *parameter;

+ (PCParameterManager *)shareParameter;//配置单例
+ (void)saveConfiguration;//默认配置保存
+ (void)resetConfiguration;//所有配置重设

//选镜头时 更改当前镜头的类型
+ (void)pickLensWithType:(PCCameraLensesType)type;//仅在换镜头时被代用

//当前镜头类型
+ (PCCameraLensesType)currentLensType ;
//当前镜头类型的配置
+ (NSMutableDictionary *)currentLensParameters;

////获取参数 根据key 先从单例中获取， 再从默认配置项获取
//+ (NSInteger)enumParameterWithKey:(NSString *)key;
//+ (NSString *)stringParameterWithKey:(NSString *)key;

#pragma mark - 参数获取接口  要求：保证返回值是的正确性、有效性
+ (AVCaptureDevicePosition)lensPosition;//配置项当前的方向
+ (AVCaptureDevicePosition)switchLensPosition;//得到转换后的方向 如：后->前   前->后  这个借口不太好

+ (OIMediaCaptorFlashMode)flashMode;//配置项当前闪光灯的mode
+ (OIMediaCaptorFlashMode)switchFlashMode;//得到切换闪光灯之后的mode

+ (OIMediaCaptorOutputSizeMode)imageOutputSizeMode;//得到拍照尺寸的model

////全屏快门配置项
+ (BOOL)fullScreenShutter;
+ (void)setFullScreenShutter:(BOOL)boolean;//只允许在ControlView的回调中调用
////定时拍摄配置
+ (NSUInteger)shutterWithTiming;
+ (void)setShutterWithTiming:(NSUInteger)value;//只允许在ControlView的回调中调用
//GIF 图片数目
+ (NSUInteger)GIFPictureCount;
+ (void)setGIFPictureCount:(NSUInteger)count;//只允许在ControlView的回调中调用
//GIF 画幅
+ (NSUInteger)GIFPictureMode;
+ (void)setGIFPictureMode:(NSUInteger)mode;//只允许在ControlView的回调中调用
//GIF 录制模式
+ (NSUInteger)GIFRecordMode;
+ (void)setGIFRecordMode:(NSUInteger)mode;//只允许在ControlView的回调中调用

//自动保存拍照的图片
+ (BOOL)savePictureAuto;
+ (void)setSavePictureAuto:(BOOL)boolean;
//开启APP直接打开镜头
+ (BOOL)lensPrecedence;
+ (void)setLensPrecedence:(BOOL)boolean;

//保存图片
+ (void)savePhotoWithImage:(UIImage *)image handler:(void (^)(BOOL success, NSError * error))handler;
@end
