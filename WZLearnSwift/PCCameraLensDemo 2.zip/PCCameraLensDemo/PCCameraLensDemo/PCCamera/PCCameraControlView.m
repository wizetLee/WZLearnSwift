//
//  PCCameraControlView.m
//  PCCameraLensDemo
//
//  Created by admin on 8/8/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "PCCameraControlView.h"
#import "PCCamera.h"
#import "PCParameterManager.h"
#import "PCCameraPreviewView.h"
#import "PCCameraScalePole.h"
#import "WZToast.h"

@interface PCCameraControlView()

//顶部
@property (nonatomic, strong) UIButton *flashBtn;           //闪光等切换
@property (nonatomic, strong) UIButton *lensBtn;            //镜头切换
@property (nonatomic, strong) UIButton *quitBtn;            //退出相机
//底部
@property (nonatomic, strong) UIButton *shutterBtn;         //快门 拍照or录像
@property (nonatomic, strong) UIButton *captureTypeBtn;     //更换拍照or录像
@property (nonatomic, strong) UIButton *lensTypeBtn;        //配置镜头类型
@property (nonatomic, strong) UIButton *settingBtn;         //配置镜头参数
@property (nonatomic, strong) PCCameraScalePole *scalePoleView;


@property (nonatomic, strong) UIView *uselessMaskView1;     //位于镜头边缘 为了观察切换的滤镜的线段
@property (nonatomic, strong) UIView *uselessMaskView2;     //位于镜头边缘 为了观察切换的滤镜的线段

//////定时拍照only
@property (nonatomic, strong) NSTimer *timer;//计时器
@property (nonatomic, assign) NSUInteger time;//计时器的时间
//////定时拍照

//////快速拍照only
@property (nonatomic, strong) UIButton *swiftCountButton;
//////快速拍照

//////GIF only
@property (nonatomic, strong) UIView *GIFProgressView;
//////GIF

//////双重曝光only
@property (nonatomic, strong) UIImageView *ghostView;
//////双重曝光


@end

@implementation PCCameraControlView

#pragma mark - Initialization
- (instancetype)init {
    if (self = [super init]) {
        [self createViews];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self createViews];
    }
    return self;
}

- (void)dealloc {
    NSLog(@"%s", __func__);
    if (_timer) {
        [_timer timeInterval];
        _timer = nil;
    }
}

- (id)hitTest:(CGPoint)point withEvent:(UIEvent *)event
{
    UIView *hitView = [super hitTest:point withEvent:event];
    if (hitView == self) {
        return nil;
    } else {
        return hitView;
    }
}

#pragma mark - Private Method

- (void)createViews {
    CGFloat screenW = [UIScreen mainScreen].bounds.size.width;
    CGFloat screenH = [UIScreen mainScreen].bounds.size.height;
    
    _uselessMaskView1 = [[UIView alloc] initWithFrame:CGRectMake(0.0, 0.0, screenW, 0.0)];
    [self addSubview:_uselessMaskView1];
    _uselessMaskView2 = [[UIView alloc] initWithFrame:CGRectMake(0.0, screenH, screenW, 0.0)];
    [self addSubview:_uselessMaskView2];
    _uselessMaskView2.backgroundColor = [[UIColor blueColor] colorWithAlphaComponent:0.5];
    _uselessMaskView1.backgroundColor = [[UIColor blueColor] colorWithAlphaComponent:0.5];
    _uselessMaskView2.hidden = true;
    _uselessMaskView1.hidden = true;
    
    _flashBtn = [[UIButton alloc] initWithFrame:CGRectMake(0.0, 20.0, 44.0* 2.0, 44.0)];
    _flashBtn.backgroundColor = [UIColor orangeColor];
    [self addSubview:_flashBtn];
    [_flashBtn setTitle:@"闪光灯关" forState:UIControlStateNormal];
    [_flashBtn addTarget:self action:@selector(clickedBtn:) forControlEvents:UIControlEventTouchUpInside];
    
    _lensBtn = [[UIButton alloc] initWithFrame:CGRectMake(CGRectGetMaxX(_flashBtn.frame), 20.0, 44.0* 2.0, 44.0)];
    _lensBtn.backgroundColor = [UIColor greenColor];
    [self addSubview:_lensBtn];
    [_lensBtn setTitle:@"镜头" forState:UIControlStateNormal];
    [_lensBtn addTarget:self action:@selector(clickedBtn:) forControlEvents:UIControlEventTouchUpInside];
    
    _quitBtn = [[UIButton alloc] initWithFrame:CGRectMake(CGRectGetMaxX(_lensBtn.frame), 20.0, 44.0* 2.0, 44.0)];
    _quitBtn.backgroundColor = [UIColor blackColor];
    [self addSubview:_quitBtn];
    [_quitBtn setTitle:@"退出镜头" forState:UIControlStateNormal];
    [_quitBtn addTarget:self action:@selector(clickedBtn:) forControlEvents:UIControlEventTouchUpInside];
    
    CGFloat capturingBtnHW = 88.0;
    _shutterBtn = [[UIButton alloc] initWithFrame:CGRectMake((screenW - capturingBtnHW) / 2.0, screenH - capturingBtnHW, capturingBtnHW, capturingBtnHW)];
    _shutterBtn.backgroundColor = [UIColor redColor];
    [self addSubview:_shutterBtn];
    [_shutterBtn setTitle:@"拍照" forState:UIControlStateNormal];
    [_shutterBtn addTarget:self action:@selector(clickedBtn:) forControlEvents:UIControlEventTouchUpInside];
    
    _lensTypeBtn = [[UIButton alloc] initWithFrame:CGRectMake(0.0, screenH - 44.0, 44.0 * 2.0, 44.0)];
    _lensTypeBtn.backgroundColor = [UIColor redColor];
    [self addSubview:_lensTypeBtn];
    [_lensTypeBtn setTitle:@"切镜头" forState:UIControlStateNormal];
    [_lensTypeBtn addTarget:self action:@selector(clickedBtn:) forControlEvents:UIControlEventTouchUpInside];
    
    _settingBtn = [[UIButton alloc] initWithFrame:CGRectMake(screenW - 88.0, screenH - 44.0, 44.0* 2.0, 44.0)];
    _settingBtn.backgroundColor = [UIColor redColor];
    [self addSubview:_settingBtn];
    [_settingBtn setTitle:@"配置" forState:UIControlStateNormal];
    [_settingBtn addTarget:self action:@selector(clickedBtn:) forControlEvents:UIControlEventTouchUpInside];
    
    _swiftCountButton = [[UIButton alloc] init];
    _swiftCountButton.frame = CGRectMake(0.0, 64.0, [UIScreen mainScreen].bounds.size.width, 50.0);
    
    [_swiftCountButton setTitle:@"0张图" forState:UIControlStateNormal];
    [_swiftCountButton setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [_swiftCountButton addTarget:self action:@selector(clickedBtn:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_swiftCountButton];
    _swiftCountButton.hidden = true;
    
    [self addSubview:self.GIFProgressView];
    
    _ghostView = [[UIImageView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    [self addSubview:_ghostView];
    _ghostView.hidden = true;
    
    _scalePoleView = [[PCCameraScalePole alloc] initWithFrame:CGRectMake(0.0,20 + 44, screenW, 70)];
    [self addSubview:_scalePoleView];
    _scalePoleView.delegate = (id<PCCameraScalePoleProtocol>)self;
    
    [self updateUIMemory];
}

#pragma mark - Buttons Event
- (void)clickedBtn:(UIButton *)sender {
    SEL sel = nil;
    id obj = nil;
    if (sender == _flashBtn) {
        sel = @selector(cameraControlViewDidClickedFlashButton);
    } else if (sender == _lensBtn) {
        sel = @selector(cameraControlViewDidClickedLensButton);
    } else if (sender == _quitBtn) {
        sel = @selector(cameraControlViewDidClickedQuitButton);
    } else if (sender == _shutterBtn) {
    
        //逻辑写在这里（内部）的原因  :  减少了在VC处再作区分
        //需要判断是什么镜头  有没有限制拍多少张图片
        if ([PCParameterManager shutterWithTiming] == 0) {
            sel = @selector(cameraControlViewDidClickedShutterButton);
        } else {
          dispatch_async(dispatch_get_main_queue(), ^{
              if (_timer) {
                  [self timerClear];
              } else {
                  [self timerFire];
              }
          });
        }
    } else if (sender == _lensTypeBtn) {
        sel = @selector(cameraControlViewDidClickedLensTypeButton);
    } else if (sender == _settingBtn) {
        sel = @selector(cameraControlViewDidClickedSettingButton);
    } else if (sender == _swiftCountButton) {
        sel = @selector(cameraControlViewDidClickedSwiftImages);
    }
    
    
    if (sel
        && [_delegate respondsToSelector:sel]) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
         [_delegate performSelector:sel withObject:obj];
#pragma clang diagnostic pop
    }
}



#pragma mark - Accessor
//根据当前设备方向设置UI
- (void)setCurrentOrientationMode:(VideoCameraViewOrientationMode)currentOrientationMode {
    if (_currentOrientationMode == currentOrientationMode) {
        return;
    }
    
    _currentOrientationMode = currentOrientationMode;
#warning 更新各个UI的方向
    [self fourfoldLOMOMaskLayoutWithAnimated:true];
}

- (void)fourfoldLOMOMaskLayoutWithAnimated:(BOOL)boolean {
    if ([PCParameterManager currentLensType] == PCCameraLensesTypeFourfoldLOMO) {
        //根据比例 改写动画的比例
        if (_currentOrientationMode == kVideoCameraViewOrientationModePortrait
            || _currentOrientationMode == kVideoCameraViewOrientationModeUpSideDown) {
            if (boolean) {
                [UIView animateWithDuration:0.25 animations:^{
                    _uselessMaskView1.frame =CGRectMake(0.0, 0.0, 100, [UIScreen mainScreen].bounds.size.height);
                    _uselessMaskView2.frame =CGRectMake([UIScreen mainScreen].bounds.size.width - 100, 0.0, 100, [UIScreen mainScreen].bounds.size.height);
                }];
            } else {
                _uselessMaskView1.frame =CGRectMake(0.0, 0.0, 100, [UIScreen mainScreen].bounds.size.height);
                _uselessMaskView2.frame =CGRectMake([UIScreen mainScreen].bounds.size.width - 100, 0.0, 100, [UIScreen mainScreen].bounds.size.height);
            }
            
        } else {
            
            if (boolean) {
                [UIView animateWithDuration:0.25 animations:^{
                    _uselessMaskView1.frame =CGRectMake(0.0, 0.0, [UIScreen mainScreen].bounds.size.width, 200);
                    _uselessMaskView2.frame =CGRectMake(0.0, [UIScreen mainScreen].bounds.size.height - 200, [UIScreen mainScreen].bounds.size.width, 200);
                }];
            } else {
                _uselessMaskView1.frame =CGRectMake(0.0, 0.0, [UIScreen mainScreen].bounds.size.width, 200);
                _uselessMaskView2.frame =CGRectMake(0.0, [UIScreen mainScreen].bounds.size.height - 200, [UIScreen mainScreen].bounds.size.width, 200);
            }
        }
    }
}

#pragma mark - 恢复UI状态记忆
- (void)updateUIMemory {
    [self timerClear];
    _swiftCountButton.hidden = true;
    PCCameraLensesType currentLensType = [PCParameterManager currentLensType];
    //获取记忆中的镜头的类型
    self.GIFProgressView.hidden = true;
    _uselessMaskView1.hidden = true;
    _uselessMaskView2.hidden = true;
    switch (currentLensType) {
            
        case PCCameraLensesTypeTradition: {
            
        } break;
        case PCCameraLensesTypeSwift: {
            //显示一个与之有关的UI
            _swiftCountButton.hidden = false;
            
        } break;
        case PCCameraLensesTypeJigsaw: {
            //显示一个与之有关的UI
            
        } break;
        case PCCameraLensesTypeGIF: {
            //显示一个与之有关的UI
            self.GIFProgressView.hidden = false;
            
        } break;
        case PCCameraLensesTypeDoubleExposure: {
            //显示一个与之有关的UI
            
        } break;
        case PCCameraLensesTypeFourfoldLOMO: {
            //显示一个与之有关的UI
            _uselessMaskView1.hidden = false;
            _uselessMaskView2.hidden = false;
            [self fourfoldLOMOMaskLayoutWithAnimated:false];
        } break;
        case PCCameraLensesTypeMicrospur: {
            //改一个滤镜 由preview处理
            
        } break;
            
        case PCCameraLensesTypeNone:
        default:
            break;
    }
   
    [self updateShutterUI];
    [self updateLensUI];
    [self updateFlashUI];
}

- (UIView *)GIFProgressView {
    if (!_GIFProgressView) {
        _GIFProgressView = [[UIView alloc] init];
        _GIFProgressView.frame = CGRectMake(10.0, [UIScreen mainScreen].bounds.size.height - 80 - 50, [UIScreen mainScreen].bounds.size.width - 20, 50);
        _GIFProgressView.hidden = true;
        _GIFProgressView.clipsToBounds = true;
        _GIFProgressView.backgroundColor = [UIColor greenColor];
        CALayer *layer = [CALayer layer];
        layer.frame = CGRectMake(0.0, 0.0, _GIFProgressView.frame.size.width / 2.0, 50.0);
        layer.backgroundColor = [UIColor purpleColor].CGColor;
        [_GIFProgressView.layer addSublayer:layer];
        
        UIView *subview = [[UIView alloc] initWithFrame:CGRectMake(0.0, 0.0, 0.0, _GIFProgressView.frame.size.height)];
        subview.backgroundColor = [UIColor yellowColor];
        [_GIFProgressView addSubview:subview];
        
        UIButton *mix = [[UIButton alloc] init];
        mix.frame = CGRectMake(_GIFProgressView.frame.size.width / 2.0, 0.0, _GIFProgressView.frame.size.width / 2.0, 50);
        [mix setTitle:@"合成" forState:UIControlStateNormal];
        [mix setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        [_GIFProgressView addSubview:mix];
        [mix addTarget:self action:@selector(mix:) forControlEvents:UIControlEventTouchUpInside];
        
        
    }
    return _GIFProgressView;
}

/**
 设置进度
 @param progress  比例  范围：0.0~1.0
 */
- (void)setGIFProgress:(CGFloat)progress {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIView *subview = self.GIFProgressView.subviews[0];
        CGFloat tmpProgress = progress;
        if (tmpProgress > 1.0) {
            tmpProgress = 1.0;
        }
        subview.frame = CGRectMake(0.0
                                   , 0.0
                                   , (self.GIFProgressView.frame.size.width) / 2.0 * tmpProgress
                                   , subview.frame.size.height);
    });
}

- (void)mix:(UIButton *)sender {
    
#warning   貌似是SDK出现了问题
//    if ([self.delegate respondsToSelector:@selector(mix)]) {
//        [self.delegate mix];
//    }
    
    [self.cameraPreviewView clearGIFImagesInfo];//清理缓存
    [self setGIFProgress:0.0];

}

#pragma mark - PCCameraScalePoleProtocol
- (void)beginSetSpeedRate {
    
}

- (void)commitSetSpeedRate {
    
}

- (void)currentSpeedRate:(CGFloat)speedRate {
//    self.cameraPreviewView.camera.exposureTargetBias = tmp;
    CGFloat tmp = 1 + 2 * speedRate;
    [self.cameraPreviewView.camera rampToVideoZoomFactor:tmp withRate:1.0];
}

#pragma mark - Public Method
- (void)activateShutteringWithTiming {
    [self clickedBtn:self.shutterBtn];
}

- (void)updateFlashUI {
    OIMediaCaptorFlashMode tmp = [PCParameterManager flashMode];
//   0关 1开 2自动 3手电筒
    if (tmp == OIMediaCaptorFlashModeOff) {
        [self.flashBtn setTitle:@"闪光灯关" forState:UIControlStateNormal];
    } else if (tmp == OIMediaCaptorFlashModeOn) {
        [self.flashBtn setTitle:@"闪光灯开" forState:UIControlStateNormal];
    } else if (tmp == OIMediaCaptorFlashModeAuto) {
        [self.flashBtn setTitle:@"自动" forState:UIControlStateNormal];
    } else if (tmp == OIMediaCaptorFlashModeTorch) {
        [self.flashBtn setTitle:@"手电筒" forState:UIControlStateNormal];
    }
}

- (void)updateLensUI {
    AVCaptureDevicePosition tmp = [PCParameterManager lensPosition];
    if (tmp == AVCaptureDevicePositionUnspecified) {
        [self.lensBtn setTitle:@"设备硬件出错" forState:UIControlStateNormal];
    } else if (tmp == AVCaptureDevicePositionBack) {
        [self.lensBtn setTitle:@"后摄像头" forState:UIControlStateNormal];
    } else if (tmp == AVCaptureDevicePositionFront) {
        [self.lensBtn setTitle:@"前摄像头" forState:UIControlStateNormal];
    }
}

- (void)updateShutterUI {
    //定时器
    if ([PCParameterManager shutterWithTiming] == 0) {
        //无计时
        [_shutterBtn setTitle:@"拍照" forState:UIControlStateNormal];
    } else {
        //计时
        [_shutterBtn setTitle:[NSString stringWithFormat:@"%ld", [PCParameterManager shutterWithTiming]] forState:UIControlStateNormal];
    }
    
    PCCameraLensesType currentLensType = [PCParameterManager currentLensType];
    if (currentLensType == PCCameraLensesTypeGIF) {
        [_shutterBtn setTitle:@"开始录制" forState:UIControlStateNormal];
    }
}

- (void)swiftCount:(NSString *)str {
    [_swiftCountButton setTitle:[NSString stringWithFormat:@"%@张图", str] forState:UIControlStateNormal];
}

//GIF的捕捉进度
- (void)GIFCapturingProgress:(NSMutableArray *)progress {
    
}

- (void)timer:(NSTimer *)timer {
    NSLog(@"%ld", _time);
    dispatch_async(dispatch_get_main_queue(), ^{
        if (([PCParameterManager shutterWithTiming] - _time) <= 0) {
            [WZToast toastWithContent:@"_____0_____拍照" duration:0.5];
        } else {
           [WZToast toastWithContent:[NSString stringWithFormat:@"_____%d_____", (int)([PCParameterManager shutterWithTiming] - _time)] duration:0.5];
        }
        
        
        if ([PCParameterManager shutterWithTiming] - _time <= 0) {/*拍照参数*/
            [self timerClear];
            //拍照
            if ([_delegate respondsToSelector:@selector(cameraControlViewDidClickedShutterButton)]) {
                [_delegate cameraControlViewDidClickedShutterButton];
            }
        } else {
            _time = _time + 1;
        }
    });
}

- (void)timerClear {
    [_timer invalidate];
    _timer = nil;
    _time = 0;
}

- (void)timerFire {
    _timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(timer:) userInfo:nil repeats:true];
    [[NSRunLoop mainRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];
    [_timer fire];
}

@end
