//
//  PCCameraLensesView.m
//  PCCameraLensDemo
//
//  Created by admin on 11/8/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "PCCameraLensesView.h"
#import "PCCameraPreviewView.h"
#import "PCParameterManager.h"



#define PCCAMERALENSVIEW_LENS_HEADLINE @"PCCameraLensesView_lens_headline"//标题
//#define PCCAMERALENSVIEW_LENS_VARIETY @"PCCameraLensesView_lens_variety"//镜头样式多样化
//#define PCCAMERALENSVIEW_LENS_VARIETYTYPE @"PCCameraLensesView_lens_varietyType"//镜头样式多样化类型
//#define PCCAMERALENSVIEW_LENS_FLAG @"PCCameraLensesView_lens_flag"//镜头位置标志



@interface PCCameraLensesView()

@property (nonatomic, copy) NSMutableArray <NSMutableDictionary *>*dataSourceMArr;
@property (nonatomic, strong) NSMutableDictionary *flagDic;
@property (nonatomic, strong) UIButton *currentButtonP;

@end

@implementation PCCameraLensesView

- (void)dealloc {
    if (_dataSourceMArr) {
        [PCParameterManager shareParameter].parameter[PCCAMERA_PARAMETER_LENS] = [_dataSourceMArr copy];
    }

        NSLog(@"%s", __func__);

}

- (void)alertContent {
    self.clickedBackgroundToDismiss = true;
    [self createViews];
}

- (void)createViews {
    [self createData];
    
    if (_dataSourceMArr.count) {
        NSInteger count = _dataSourceMArr.count;
        CGFloat btnW = 100;
        CGFloat btnH = 44;
       
        for (int i = 1; i <= _dataSourceMArr.count; i++) {
            NSMutableDictionary *mDic = _dataSourceMArr[i-1];
            NSString *headline      = mDic[PCCAMERALENSVIEW_LENS_HEADLINE];
//            NSArray *varietyArr     = mDic[PCCAMERALENSVIEW_LENS_VARIETY];
//            NSNumber *varietyType   = mDic[PCCAMERALENSVIEW_LENS_VARIETYTYPE];
//            NSNumber *flag          = mDic[PCCAMERALENSVIEW_LENS_FLAG];
            UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(0.0, [UIScreen mainScreen].bounds.size.height - (count - i) * btnH - 100, btnW, btnH)];
            [self addSubview:button];
            [button setTitle:headline forState:UIControlStateNormal];
            [button setBackgroundColor:[[UIColor yellowColor] colorWithAlphaComponent:0.5]];
            [button addTarget:self action:@selector(clickedBtn:) forControlEvents:UIControlEventTouchUpInside];
            button.tag = i;
          
            if (_cameraPreviewView) {
                if (_cameraPreviewView.lensesType == i) {
                    _currentButtonP = button;
                    [_currentButtonP setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
                }
            } else {
                if (i == 0) {
                _currentButtonP = button;
                [_currentButtonP setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
                }
            }
        }
    }
    
}

- (void)createData {
    @try {
        NSMutableDictionary *dic = [PCParameterManager currentLensParameters];
        if ([dic[PCCAMERA_PARAMETER_LENS] isKindOfClass:[NSArray class]]) {
            _dataSourceMArr = [NSMutableArray arrayWithArray:dic[PCCAMERA_PARAMETER_LENS]];
            for (int i = 0; i < _dataSourceMArr.count; i++) {
                _dataSourceMArr[i] = [NSMutableDictionary dictionaryWithDictionary:_dataSourceMArr[i]];
            }
        } else {
            [self defaultData];
        }
    } @catch (NSException *exception) {
        [self defaultData];
    } @finally {
        
    }
}

- (void)defaultData {
    _dataSourceMArr = [NSMutableArray array];
    
    /**
     
     PCCameraLensesTypeNone                  = 0,
     PCCameraLensesTypeTradition             ,
     PCCameraLensesTypeSwift                 ,
     PCCameraLensesTypeJigsaw                ,
     PCCameraLensesTypeGIF                   ,
     //    PCCameraLensesTypeInteresting           ,
     PCCameraLensesTypeDoubleExposure        ,
     PCCameraLensesTypeFourfoldLOMO          ,
     PCCameraLensesTypeMicrospur             ,
     */
    NSArray <NSString *>*tmpHeadline = @[@"传统镜头", @"快速拍照", @"拼图镜头", @"GIF短视频", @"双重曝光", @"四格LOMO", @"移轴/微距",];
//    NSArray <NSArray *>*tmpVariety = @[@[], @[], @[], @[], @[], @[], @[]]; //@[[NSMutableDictionary dictionaryWithDictionary:@{}]]
//    NSArray <NSArray *>*tmpVarietyType = @[@(0), @(0), @(0), @(0), @(0), @(0), @(0),];
//    NSArray <NSArray *>*tmpFlag = @[@(true), @(false), @(false), @(false), @(false), @(false), @(false),];//如果没有选中默认会选中第一种镜头
    
    for (int i = 0; i < tmpHeadline.count; i++) {
        [_dataSourceMArr addObject:[NSMutableDictionary dictionaryWithDictionary:
                                 @{PCCAMERALENSVIEW_LENS_HEADLINE:tmpHeadline[i],
//                                   PCCAMERALENSVIEW_LENS_VARIETY:tmpVariety[i],
//                                   PCCAMERALENSVIEW_LENS_VARIETYTYPE:tmpVarietyType[i],
//                                   PCCAMERALENSVIEW_LENS_FLAG:tmpFlag[i],
                                   }]];
    }
    //保存镜头参数
    NSMutableDictionary *dic = [PCParameterManager currentLensParameters];
    dic[PCCAMERA_PARAMETER_LENS] = [_dataSourceMArr copy];
}

- (void)clickedBtn:(UIButton *)sender {
    //更新preview  更新control
    switch (sender.tag) {
        case 1: {
            _cameraPreviewView.lensesType = PCCameraLensesTypeTradition;
        } break;
        case 2: {
            _cameraPreviewView.lensesType = PCCameraLensesTypeSwift;
        } break;
        case 3: {
            _cameraPreviewView.lensesType = PCCameraLensesTypeJigsaw;
        } break;
        case 4: {
            _cameraPreviewView.lensesType = PCCameraLensesTypeGIF;
        } break;
        case 5: {
            _cameraPreviewView.lensesType = PCCameraLensesTypeDoubleExposure;
        } break;
        case 6: {
            _cameraPreviewView.lensesType = PCCameraLensesTypeFourfoldLOMO;
        } break;
        case 7: {
            _cameraPreviewView.lensesType = PCCameraLensesTypeMicrospur;
        } break;
    
        default:
            break;
    }
   
    [_currentButtonP setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    _currentButtonP = sender;
    [_currentButtonP setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [_cameraControlView updateUIMemory];
    
//    [self alertDismissWithAnimated:true];
}


@end
