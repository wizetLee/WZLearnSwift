//
//  PCCameraMoreSettingView.h
//  PCCameraLensDemo
//
//  Created by admin on 18/8/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "PCCameraBaseAlert.h"

/**
 更多设置
 */
@interface PCCameraMoreSettingView : PCCameraBaseAlert

@end
