//
//  PCCameraMoreSettingView.m
//  PCCameraLensDemo
//
//  Created by admin on 18/8/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "PCCameraMoreSettingView.h"
#import "PCParameterManager.h"


@interface PCCameraMoreSettingView()

@property (nonatomic, strong) UIButton *savePhotoBtn;
@property (nonatomic, strong) UIButton *lensPrecedenceBtn;

@end

@implementation PCCameraMoreSettingView

- (void)alertContent {
    self.clickedBackgroundToDismiss = true;
    self.displayType = PCAlertDipalyDismissTypeFromBottomToTop;
    UIButton *decorateView = [[UIButton alloc] initWithFrame:[UIScreen mainScreen].bounds];
    [self addSubview:decorateView];
    decorateView.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.6];
    
    _savePhotoBtn = [[UIButton alloc] init];
    [self addSubview:_savePhotoBtn];
    _savePhotoBtn.frame = CGRectMake(0.0, 100, 200, 44.0);
    [_savePhotoBtn setTitle:@"自动保存拍照的图片" forState:UIControlStateSelected];
    [_savePhotoBtn setTitle:@"手动保存拍照的图片" forState:UIControlStateNormal];
    [_savePhotoBtn setTitleColor:[UIColor yellowColor] forState:UIControlStateNormal];
    [_savePhotoBtn setTitleColor:[UIColor orangeColor] forState:UIControlStateNormal];
    _savePhotoBtn.backgroundColor = [UIColor redColor];
    
    _lensPrecedenceBtn = [[UIButton alloc] init];
    [self addSubview:_lensPrecedenceBtn];
    _lensPrecedenceBtn.frame = CGRectMake(0.0, 188, 200, 44.0);
    [_lensPrecedenceBtn setTitle:@"启动时马上开启镜头" forState:UIControlStateSelected];
    [_lensPrecedenceBtn setTitle:@"手动开启镜头" forState:UIControlStateNormal ];
    [_lensPrecedenceBtn setTitleColor:[UIColor yellowColor] forState:UIControlStateNormal];
    [_lensPrecedenceBtn setTitleColor:[UIColor orangeColor] forState:UIControlStateNormal];
    _lensPrecedenceBtn.backgroundColor = [UIColor redColor];
    
    _savePhotoBtn.selected = [PCParameterManager savePictureAuto];
    _lensPrecedenceBtn.selected = [PCParameterManager lensPrecedence];
    
    [decorateView addTarget:self action:@selector(dismiss) forControlEvents:UIControlEventTouchUpInside];
    [_savePhotoBtn addTarget:self action:@selector(clickedBtn:) forControlEvents:UIControlEventTouchUpInside];
    [_lensPrecedenceBtn addTarget:self action:@selector(clickedBtn:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)clickedBtn:(UIButton *)sender {
    if (sender == _savePhotoBtn) {
        _savePhotoBtn.selected = ! _savePhotoBtn.selected;
        [PCParameterManager setSavePictureAuto:_savePhotoBtn.selected];
    } else if (sender == _lensPrecedenceBtn) {
        _lensPrecedenceBtn.selected = ! _lensPrecedenceBtn.selected;
        [PCParameterManager setLensPrecedence:_lensPrecedenceBtn.selected];
    }
}

- (void)dismiss {
    [self alertDismissWithAnimated:true];
    [PCParameterManager saveConfiguration];
}

@end
