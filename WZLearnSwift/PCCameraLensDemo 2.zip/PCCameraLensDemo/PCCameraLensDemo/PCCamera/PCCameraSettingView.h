//
//  PCCameraSettingView.h
//  PCCameraLensDemo
//
//  Created by admin on 11/8/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "PCCameraBaseAlert.h"
#import "PCParameterManager.h"

@protocol PCCameraSettingViewProtocol <NSObject>


//相册
- (void)cameraSettingViewClickedAlbum;
//比例切换
- (void)cameraSettingViewClickedScaleWithType:(NSNumber *)type;
//构思图
- (void)cameraSettingViewClickedConceptionWithType:(NSNumber *)type;
//定时
- (void)cameraSettingViewClickedTimingWithType:(NSNumber *)type;
//全屏快门
- (void)cameraSettingViewClickedFullScreenShutterWithType:(NSNumber *)type;
//更多
- (void)cameraSettingViewClickedMore;

@end


/**
 拍照参数配置
 */
@interface PCCameraSettingView : PCCameraBaseAlert

@property (nonatomic, weak) id<PCCameraSettingViewProtocol> delegate;

@end
