//
//  PCParameterManager.m
//  PCCameraLensDemo
//
//  Created by admin on 9/8/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "PCParameterManager.h"
#import <Photos/Photos.h>
#import "PCCameraPreviewView.h"


/***********************************/

#pragma mark - 镜头映射
#define LENS(number) [NSString stringWithFormat:@"PCCamera_%d_sequence", number]
#define CURRENT_LENS_TYPE @"current_lens_type"//默认为传统镜头

//#pragma mark - PCCAMERA_0_TRAIDTION_LENS
//
//#define POSITION(number) [NSString stringWithFormat:@"PCCamera_%d_lens_position", number]
//#define FLASH_MODE(number) [NSString stringWithFormat:@"PCCamera_%d_flash_mode", number]
//#define SIZE_MODE(number) [NSString stringWithFormat:@"PCCamera_%d_outputSize_mode", number]
//
//#define PCCAMERA_0_LENS_POSITION @"PCCamera_0_lens_position"
//#define PCCAMERA_0_FLASH_MODE @"PCCamera_0_flash_mode"
//#define PCCAMERA_0_OUTPUTSIZE_MODE @"PCCamera_0_outputSize_mode"
//
//#pragma mark - PCCAMERA_1_SWIFT_LENS
//#define PCCAMERA_1_LENS_POSITION @"PCCamera_1_lens_position"
//#define PCCAMERA_1_FLASH_MODE @"PCCamera_1_flash_mode"
//#define PCCAMERA_1_OUTPUTSIZE_MODE @"PCCamera_1_outputSize_mode"
//
//
//#pragma mark - PCCAMERA_2_JIGSAW_LENS
//
//#pragma mark - PCCAMERA_3_GIF_LENS
//
//#pragma mark - PCCAMERA_4_DOUBLEEXPOSURE_LENS
//
//#pragma mark - PCCAMERA_5_FOURFOLDLOMO_LENS
//
//#pragma mark - PCCAMERA_6_MICROSPUR_LENS


#pragma mark - 共有部分
//镜头方向  0设备位置不明 1后  2前
#define PCCAMERA_PARAMETER_LENS_POSITION @"PCCamera_parameter_lens_position"

//闪光灯mode 0关 1开 2自动 3手电筒
#define PCCAMERA_PARAMETER_FLASH_MODE @"PCCamera_parameter_flash_mode"

//拍摄尺寸 0、4:3 1、1:1 2、16:9  录视频的尺寸  4格lemo尺寸
#define PCCAMERA_PARAMETER_OUTPUTSIZE_MODE @"PCCamera_parameter_outputSize_mode"


////聚焦mode 0固定在镜头前 1自动对焦一次然后锁上 2自动持续更改焦点
//#define PCCAMERA_PARAMETER_FOUCE_MODE @"PCCamera_parameter_fouce_mode"
//
////曝光模式 0锁定当前曝光值 1改变一次曝光值再锁定 2自动持续更改曝光值 3根据用户的提供的ISO,exposureDuration values修改曝光值
//#define PCCAMERA_PARAMETER_EXPOSURE_MODE @"PCCamera_parameter_exposure_mode"

//方向需求？

//白平衡mode 0锁定当前白平衡值 1自动修改一次白平衡再锁上 2自动持续修改白平衡值
//#define PCCAMERA_PARAMETER_WHITEBALANCE_MODE @"PCCamera_parameter_whiteBalance_mode"

//相机mode 0静态图 1录像
//#define PCCAMERA_PARAMETER_CMAERA_MODE @"PCCamera_parameter_camera_mode"

//镜头分辨率 直接设置对应的NSString
//#define PCCAMERA_PARAMETER_LENS_PRESET @"PCCamera_parameter_lens_preset"

//帧率
//#define PCCAMERA_PARAMETER_RATE_FRAME @"PCCamera_parameter_frame_rate"


#define PCCAMERA_CENTRAL_PIVOT @"PCCamera_central_pivot"//配置中枢(可变字典、存放以上key)
/***********************************/
/*
 每个镜头类型都增加
 
 */
/***********************************/


//#define PCGETPARA_ENUM(key) [PCParameterManager enumParameterWithKey:key]
//#define PCGETPARA_STRING(key) [PCParameterManager stringParameterWithKey:key]

@implementation PCParameterManager

static PCParameterManager *manager = nil;

+ (PCParameterManager *)shareParameter {
    static dispatch_once_t onceToken;

    dispatch_once(&onceToken, ^{
        if (!manager) {
            manager = [[PCParameterManager alloc] init];
            //获取上次相机配置记录
            NSDictionary *parameters = [[NSUserDefaults standardUserDefaults] valueForKey:PCCAMERA_CENTRAL_PIVOT];
            //这个大字典里面有对应镜头的小字典
            if ([parameters isKindOfClass:[NSDictionary class]]) {
                //可变类型转化， 因为在获取的时候 所有类型都变为不可变类型
                manager.parameter = [NSMutableDictionary dictionaryWithDictionary:parameters];
                NSMutableDictionary *tmpMDic = [NSMutableDictionary dictionary];
                for (NSString *key in manager.parameter.allKeys) {
                    if ([[manager.parameter valueForKey:key] isKindOfClass:[NSDictionary class]]) {
                        tmpMDic[key] = [NSMutableDictionary dictionaryWithDictionary:[manager.parameter valueForKey:key]];
                    } else {
                        tmpMDic[key] = [manager.parameter valueForKey:key];
                    }
                }
                manager.parameter = tmpMDic;
            } else {
                manager.parameter = [self defaultParameter];
            }
        }
    });
    return manager;
}

+ (NSMutableDictionary *)defaultParameter {
    NSMutableDictionary *defaultParameterMDic = [NSMutableDictionary dictionary];
    
    NSUInteger lensCount = 10;//镜头数目  可以写多 不可写少，少了就没有记忆能力
    for (int i = 0; i <= lensCount; i++) {
        NSMutableDictionary *tmpDic = [NSMutableDictionary dictionary];
        defaultParameterMDic[LENS(i)] = tmpDic;
    }
    
    //配置默认参数
    defaultParameterMDic[PCCAMERA_PARAMETER_LENS_POSITION] = @(1);
    defaultParameterMDic[PCCAMERA_PARAMETER_FLASH_MODE] = @(0);
    
    [[NSUserDefaults standardUserDefaults] setValue:defaultParameterMDic forKey:PCCAMERA_CENTRAL_PIVOT];
    [[NSUserDefaults standardUserDefaults] synchronize];
    return defaultParameterMDic;
}

+ (void)saveConfiguration {
    [[NSUserDefaults standardUserDefaults] setValue:[self shareParameter].parameter forKey:PCCAMERA_CENTRAL_PIVOT];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+ (void)resetConfiguration {
    manager.parameter = [self defaultParameter];
}

//查找出错返回 -1
//+ (NSInteger)enumParameterWithKey:(NSString *)key {
//    if ([key isKindOfClass:[NSString class]]
//        && key.length) {
//        if ([[PCParameterManager shareParameter].parameter[key] isKindOfClass:[NSNumber class]]) {
//            return [[PCParameterManager shareParameter].parameter[key] integerValue];
//        } else if ([self defaultParameter][key]) {
//            return [[self defaultParameter][key] integerValue];
//        }
//    }
//    return -1;
//}

//查找出错返回 nil
//+ (NSString *)stringParameterWithKey:(NSString *)key {
//    if ([key isKindOfClass:[NSString class]]
//        && key.length) {
//        
//        if ([PCParameterManager shareParameter].parameter) {
//            
//        }
//        
//        if ([[PCParameterManager shareParameter].parameter[key] isKindOfClass:[NSString class]]) {
//            return [PCParameterManager shareParameter].parameter[key];
//        } else if ([self defaultParameter][key]) {
//            return [self defaultParameter][key];
//        }
//    }
//    return nil;
//}

//选镜头时 更改当前镜头的类型
+ (void)pickLensWithType:(PCCameraLensesType)type {
    [self shareParameter].parameter[CURRENT_LENS_TYPE] = @(type);
}

//当前镜头类型
+ (PCCameraLensesType)currentLensType {
    if ([self shareParameter].parameter[CURRENT_LENS_TYPE]) {
        return [[self shareParameter].parameter[CURRENT_LENS_TYPE] integerValue];
    }
    return PCCameraLensesTypeTradition;//默认是传统镜头
}

+ (NSMutableDictionary *)currentLensParameters {
    PCCameraLensesType currentLensType = [PCParameterManager currentLensType];
    NSMutableDictionary *dic = [PCParameterManager shareParameter].parameter[LENS((int)currentLensType)];
    return dic;
}



#pragma mark - 参数获取 Public
//获取镜头方向  默认的后面镜头方向
+ (AVCaptureDevicePosition)lensPosition {
    AVCaptureDevicePosition positioin = AVCaptureDevicePositionBack;
    NSDictionary *dic = [PCParameterManager currentLensParameters];
    
    if (dic[PCCAMERA_PARAMETER_LENS_POSITION]) {
         positioin = [dic[PCCAMERA_PARAMETER_LENS_POSITION] integerValue];
    }
    return positioin;
}

+ (AVCaptureDevicePosition)switchLensPosition {
    NSMutableDictionary *dic = [PCParameterManager currentLensParameters];
    NSInteger positioin = [dic[PCCAMERA_PARAMETER_LENS_POSITION] integerValue];
    
    if (positioin < 2
        && positioin > -1 ) {
        positioin++;
    } else if (positioin == 2) {
        positioin = 1;
    } else {
        //匹配出错
        positioin = 0;
    }
    
    dic[PCCAMERA_PARAMETER_LENS_POSITION] = @(positioin);
    
    return (AVCaptureDevicePosition)positioin;
}

+ (OIMediaCaptorFlashMode)flashMode {
    OIMediaCaptorFlashMode flashMode = OIMediaCaptorFlashModeOff;
    NSMutableDictionary *dic = [PCParameterManager currentLensParameters];
    if (dic[PCCAMERA_PARAMETER_FLASH_MODE]) {
        flashMode = [dic[PCCAMERA_PARAMETER_FLASH_MODE] integerValue];
    }    return flashMode;
}

+ (OIMediaCaptorFlashMode)switchFlashMode {
    NSMutableDictionary *dic = [PCParameterManager currentLensParameters];
    NSInteger flashMode = [dic[PCCAMERA_PARAMETER_FLASH_MODE] integerValue];
    //不能切换到手电筒
    if (flashMode < 2
        && flashMode > -1 ) {
        flashMode++;
    } else if (flashMode == 2) {
        flashMode = 0;
    } else {
        //匹配出错
        flashMode = 0;
    }
    
    dic[PCCAMERA_PARAMETER_FLASH_MODE] = @(flashMode);
    return (OIMediaCaptorFlashMode)flashMode;
}

+ (NSInteger)stillImageLensMode {
    OIMediaCaptorOutputSizeMode stillImageLensMode = OIMediaCaptorOutputSizeMode4To3;
    NSMutableDictionary *dic = [PCParameterManager currentLensParameters];
    if (dic[PCCAMERA_PARAMETER_OUTPUTSIZE_MODE]) {
        stillImageLensMode = [dic[PCCAMERA_PARAMETER_OUTPUTSIZE_MODE] integerValue];
    }
    return stillImageLensMode;
}

+ (OIMediaCaptorOutputSizeMode)imageOutputSizeMode {
    OIMediaCaptorOutputSizeMode sizeMode = OIMediaCaptorOutputSizeMode1To1;
    
    PCCameraLensesType currentLensType = [self currentLensType];
#warning  GIF And The Fourfold Type Using The Appoint Format  写死了四格和GIF的尺寸
    if (currentLensType == PCCameraLensesTypeGIF) {
          return sizeMode;
    }
    if (currentLensType == PCCameraLensesTypeFourfoldLOMO) {
        return OIMediaCaptorOutputSizeMode16To9;
    }
    
    
    NSMutableDictionary *dic = [PCParameterManager currentLensParameters];
    
    NSArray *tmp = dic[PCCAMERA_PARAMETER_SETTING];
    if ([tmp isKindOfClass:[NSArray class]]
        && tmp.count > 2 ) {
        NSDictionary *dic = tmp[1];//指定了第2个为size 详细请见 PCCameraSettingView
        if ([dic isKindOfClass:[NSDictionary class]]) {
            sizeMode = [dic[PCCAMERASETTINGVIEW_SETTINGTYPE] integerValue];
            if (sizeMode == 0) {
                sizeMode = OIMediaCaptorOutputSizeMode1To1;
            } else if (sizeMode == 1) {
                sizeMode = OIMediaCaptorOutputSizeMode16To9;
            } else if (sizeMode == 2) {
                sizeMode = OIMediaCaptorOutputSizeMode4To3;
            }
        }
    }
    return sizeMode;
}



+ (BOOL)fullScreenShutter {
//    BOOL mode = false;
//    PCCameraLensesType currentLensType = [self currentLensType];
//    if (currentLensType == PCCameraLensesTypeGIF) {
//        return mode;
//    }
//    
//    NSMutableDictionary *dic = [PCParameterManager shareParameter].parameter[LENS((int)currentLensType)];
//    
//    NSArray *tmp = dic[PCCAMERA_PARAMETER_SETTING];
//    if ([tmp isKindOfClass:[NSArray class]]
//        && tmp.count > 2 ) {
//        NSDictionary *dic = tmp[4];//指定了第4个为快门 详细请见 PCCameraSettingView
//        if ([dic isKindOfClass:[NSDictionary class]]) {
//            mode = [dic[PCCAMERASETTINGVIEW_SETTINGTYPE] integerValue];
//        }
//    }
    if ([PCParameterManager currentLensParameters][PCCAMERASETTINGVIEW_SETTINGFULLSCREENSHUTTER]) {
        return [[PCParameterManager currentLensParameters][PCCAMERASETTINGVIEW_SETTINGFULLSCREENSHUTTER] boolValue];
    } else return false;
//    return mode;
}

+ (void)setFullScreenShutter:(BOOL)boolean {
    [PCParameterManager currentLensParameters][PCCAMERASETTINGVIEW_SETTINGFULLSCREENSHUTTER] = @(boolean);
    
}

//定时拍摄配置
+ (NSUInteger)shutterWithTiming {
    if ([PCParameterManager currentLensParameters][PCCAMERASETTINGVIEW_SETTINGSHUTTERWITHTIMING]) {
        return [[PCParameterManager currentLensParameters][PCCAMERASETTINGVIEW_SETTINGSHUTTERWITHTIMING] integerValue];
    } else return 0;
}
//配置定时拍摄时间
+ (void)setShutterWithTiming:(NSUInteger)value {
    [PCParameterManager currentLensParameters][PCCAMERASETTINGVIEW_SETTINGSHUTTERWITHTIMING] = @(value);
}

#pragma mark - GIF Only
//For GIF Setting View   0:小   1:大

+ (NSUInteger)GIFPictureCount {
    if ([PCParameterManager currentLensParameters][PCCAMERASETTINGVIEW_SETTINGRPICTURECOUNT]) {
        return [[PCParameterManager currentLensParameters][PCCAMERASETTINGVIEW_SETTINGRPICTURECOUNT] integerValue];
    } else return 24;
}

+ (void)setGIFPictureCount:(NSUInteger)count {
    [PCParameterManager currentLensParameters][PCCAMERASETTINGVIEW_SETTINGRPICTURECOUNT] = @(count);
}

+ (NSUInteger)GIFPictureMode {//画幅模式  详见
//    NSUInteger mode = 0;//默认类型
//    PCCameraLensesType currentLensType = [self currentLensType];
//    if (currentLensType == PCCameraLensesTypeGIF) {
//       //第二个元素
//        NSMutableDictionary *dic = [PCParameterManager currentLensParameters];
//        NSArray *tmp = dic[PCCAMERA_PARAMETER_SETTING];
//      
//        if ([tmp isKindOfClass:[NSArray class]]
//            && tmp.count > 2) {
//            NSDictionary *dic = tmp[1];//指定了第2个为size 详细请见 PCCameraSettingView
//            if ([dic isKindOfClass:[NSDictionary class]]) {
//                mode = [dic[PCCAMERASETTINGVIEW_SETTINGTYPE] integerValue];
//            }
//        }
//    }
//    return mode;
    if ([PCParameterManager currentLensParameters][PCCAMERASETTINGVIEW_SETTINGRPICTURE]) {
        return [[PCParameterManager currentLensParameters][PCCAMERASETTINGVIEW_SETTINGRPICTURE] integerValue];
    } else return 0;
}

+ (void)setGIFPictureMode:(NSUInteger)mode {
    [PCParameterManager currentLensParameters][PCCAMERASETTINGVIEW_SETTINGRPICTURE] = @(mode);
}

// 0:自动 1:手动
+ (NSUInteger)GIFRecordMode {//录制mode
//    NSUInteger mode = 0;//默认类型
//    PCCameraLensesType currentLensType = [self currentLensType];
//    if (currentLensType == PCCameraLensesTypeGIF) {
//        //第三个元素
//        NSMutableDictionary *dic = [PCParameterManager currentLensParameters];
//        NSArray *tmp = dic[PCCAMERA_PARAMETER_SETTING];
//        
//        if ([tmp isKindOfClass:[NSArray class]]
//            && tmp.count > 3) {
//            NSDictionary *dic = tmp[2];//指定了第2个为size 详细请见 PCCameraSettingView
//            if ([dic isKindOfClass:[NSDictionary class]]) {
//                mode = [dic[PCCAMERASETTINGVIEW_SETTINGTYPE] integerValue];
//            }
//        }
//    }
//    return mode;
    
    if ([PCParameterManager currentLensParameters][PCCAMERASETTINGVIEW_SETTINGRECORDMODE]) {
        return [[PCParameterManager currentLensParameters][PCCAMERASETTINGVIEW_SETTINGRECORDMODE] integerValue];
    } else return 0;
}

+ (void)setGIFRecordMode:(NSUInteger)mode {
    [PCParameterManager currentLensParameters][PCCAMERASETTINGVIEW_SETTINGRECORDMODE] = @(mode);
}

//自动保存拍照的图片
+ (BOOL)savePictureAuto {
    NSNumber *obj = [PCParameterManager shareParameter].parameter[PCCAMERA_PARAMETER_SAVEPICTUREAUTO];
    if ([obj isKindOfClass:[NSNumber class]]) {
        return [obj boolValue];
    }
    return false;
}
+ (void)setSavePictureAuto:(BOOL)boolean {
    [PCParameterManager shareParameter].parameter[PCCAMERA_PARAMETER_SAVEPICTUREAUTO] = @(boolean);
}
//开启APP直接打开镜头
+ (BOOL)lensPrecedence {
    NSNumber *obj = [PCParameterManager shareParameter].parameter[PCCAMERA_PARAMETER_LENSPRECEDENCE];
    if ([obj isKindOfClass:[NSNumber class]]) {
        return [obj boolValue];
    }
    return false;
}
+ (void)setLensPrecedence:(BOOL)boolean {
    [PCParameterManager shareParameter].parameter[PCCAMERA_PARAMETER_LENSPRECEDENCE] = @(boolean);
}


- (void)template {
   
    switch (self.cameraPreviewView.lensesType) {
      
        case PCCameraLensesTypeTradition: {
            
        } break;
        case PCCameraLensesTypeSwift: {
            
        } break;
        case PCCameraLensesTypeJigsaw: {
            
        } break;
        case PCCameraLensesTypeGIF: {
            
        } break;
        case PCCameraLensesTypeDoubleExposure: {
            
        } break;
        case PCCameraLensesTypeFourfoldLOMO: {
            
        } break;
        case PCCameraLensesTypeMicrospur: {
            
        } break;
            
        case PCCameraLensesTypeNone:
        default:
            break;
    }
}

+ (void)savePhotoWithImage:(UIImage *)image handler:(void (^)(BOOL success, NSError * error))handler {
    if ([image isKindOfClass:[UIImage class]]) {
        [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{
            [PHAssetChangeRequest creationRequestForAssetFromImage:image];
        } completionHandler:handler];
    } else {
        if (handler) {
            handler(false, [NSError errorWithDomain:@"保存非图片类型" code:-1 userInfo:nil]);
        }
    }
}
@end
