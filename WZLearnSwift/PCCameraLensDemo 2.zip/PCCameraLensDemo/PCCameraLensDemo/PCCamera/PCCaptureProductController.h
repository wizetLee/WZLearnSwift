//
//  PCCaptureProductController.h
//  PCCameraLensDemo
//
//  Created by admin on 14/8/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PCCaptureProductController : UIViewController

@property (nonatomic, strong) UIImageView *imageView;

@end
