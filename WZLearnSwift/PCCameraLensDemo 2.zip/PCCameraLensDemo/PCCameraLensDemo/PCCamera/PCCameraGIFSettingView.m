//
//  PCCameraGIFSettingView.m
//  PCCameraLensDemo
//
//  Created by admin on 11/8/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import "PCCameraGIFSettingView.h"
#import "PCParameterManager.h"

#define PCCAMERAGIFSETTINGVIEWCELL_ID @"PCCameraGIFSettingViewCell_ID"//cell ID

@interface PCCameraGIFSettingViewCell : UICollectionViewCell

@property (nonatomic, strong) UIImageView *coverImageView;//封面
@property (nonatomic, strong) UILabel *headlineLabel;//标题
@property (nonatomic, strong) NSMutableDictionary *parameterDic;//数据配置

@end

@implementation PCCameraGIFSettingViewCell

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self createViews];
    }
    return self;
}


- (void)createViews {
    CGFloat imageHW = 40.0;
    _coverImageView = [[UIImageView alloc] initWithFrame:CGRectMake((self.frame.size.width - imageHW) / 2.0, 0.0, imageHW, imageHW)];
    [self.contentView addSubview:_coverImageView];
    _coverImageView.backgroundColor = [UIColor redColor];
    
    _headlineLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0, imageHW, self.bounds.size.width, self.frame.size.height - imageHW)];
    [self.contentView addSubview:_headlineLabel];
    _headlineLabel.text = @"标题";
    _headlineLabel.textAlignment = NSTextAlignmentCenter;
    _headlineLabel.font = [UIFont systemFontOfSize:9];
}

- (void)prepareForReuse {
    _coverImageView.image = nil;
    _headlineLabel.text = @"";
}

- (void)setParameterDic:(NSMutableDictionary *)parameterDic {
    if ([parameterDic isKindOfClass:[NSMutableDictionary class]]) {
        _parameterDic = parameterDic;
        [self updateUI];
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self updateUI];
}

- (void)updateUI {
    if (self.parameterDic) {
        NSNumber *type      = self.parameterDic[PCCAMERASETTINGVIEW_SETTINGTYPE];
        NSString *headline  = self.parameterDic[PCCAMERASETTINGVIEW_SETTINGHEADLINE];
        NSArray *source     = self.parameterDic[PCCAMERASETTINGVIEW_SETTINGSOURCE];
        self.headlineLabel.text = headline;
        if (source.count) {
            if ([type integerValue] < source.count && [type integerValue] >= 0) {
            } else {
                type = @(0);
            }
            
            NSDictionary *dic = source[[type integerValue]];
            //无图片 暂时改title
            if ([dic[@"image"] isKindOfClass:[NSString class]]) {
                self.headlineLabel.text = dic[@"image"];
            }
        }
    }
}

- (void)switchType {
    if (self.parameterDic) {
        NSNumber *type      = self.parameterDic[PCCAMERASETTINGVIEW_SETTINGTYPE];
        NSArray *source     = self.parameterDic[PCCAMERASETTINGVIEW_SETTINGSOURCE];
        NSInteger tmp       = [type integerValue];
        //点击循环操作
        if (tmp < (source.count - 1)
            && tmp >= 0) {
            tmp++;
        } else {
            tmp = 0;
        }
        self.parameterDic[PCCAMERASETTINGVIEW_SETTINGTYPE] = @(tmp);
    }
}

@end
@interface PCCameraGIFSettingView()<UICollectionViewDelegate,
UICollectionViewDataSource>

@property (nonatomic, strong) UICollectionView *collection;
@property (nonatomic, strong) NSMutableArray <NSMutableDictionary *>*dataSourceMArr;

@end

@implementation PCCameraGIFSettingView

- (void)dealloc {
    NSLog(@"%s", __func__);
    [PCParameterManager saveConfiguration];
}


- (void)alertContent {
    [self createViews];
     self.clickedBackgroundToDismiss = true;
}

- (void)createViews {
    
     [self createData];//构建UI前先构建数据源
//    CGFloat btnW = [UIScreen mainScreen].bounds.size.width;

    CGFloat WH = 60.0;
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.itemSize = CGSizeMake(WH, WH);
    layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    
    _collection = [[UICollectionView alloc] initWithFrame:CGRectMake(0.0
                                                                     , [UIScreen mainScreen].bounds.size.height - 80 - 80
                                                                     , [UIScreen mainScreen].bounds.size.width
                                                                     , 80.0)
                                     collectionViewLayout:layout];
    [self addSubview:_collection];
    _collection.backgroundColor = [UIColor yellowColor];
    _collection.showsHorizontalScrollIndicator = false;
    [_collection registerClass:[PCCameraGIFSettingViewCell class] forCellWithReuseIdentifier:PCCAMERAGIFSETTINGVIEWCELL_ID];
    _collection.delegate = self;
    _collection.dataSource = self;

    //下面有一个操纵时间的控制杆
}

- (void)createData {
    
    //整个数字保存在Memony中
    @try {
        //可变类型转化
        NSMutableDictionary *dic =  [PCParameterManager currentLensParameters];//gif的镜头
        if ([dic[PCCAMERA_PARAMETER_SETTING] isKindOfClass:[NSArray class]]) {
            _dataSourceMArr = [NSMutableArray arrayWithArray:dic[PCCAMERA_PARAMETER_SETTING]];
            NSMutableArray *tmpMArr = [NSMutableArray array];
            for (int i = 0; i < _dataSourceMArr.count; i++) {
                [tmpMArr addObject:[NSMutableDictionary dictionaryWithDictionary:_dataSourceMArr[i]]];
            }
            _dataSourceMArr = tmpMArr;
        } else {
            [self defaultData];
        }
    } @catch (NSException *exception) {
        [self defaultData];
    } @finally {
    }
}

- (void)defaultData {
    /*
     0：构图线
     1：画幅
     2：录制的模式
     3：GIF张数
     */
    _dataSourceMArr = [NSMutableArray array];
    [_dataSourceMArr addObject:[NSMutableDictionary dictionaryWithDictionary:
                                @{PCCAMERASETTINGVIEW_SETTINGTYPE:@(0),
                                  PCCAMERASETTINGVIEW_SETTINGHEADLINE:@"构图线",
                                  PCCAMERASETTINGVIEW_SETTINGSOURCE:@[@{@"image":/*素材名字*/@"无构图线.png",  @"source":@(0)},/*无构线*/
                                                                      @{@"image":/*素材名字*/@"01构图线.png",  @"source":@(1)},/*01号*/
                                                                      @{@"image":/*素材名字*/@"02构图线.png",  @"source":@(2)}/*02号*/
                                                                      ],
                                  }]];
    [_dataSourceMArr addObject:[NSMutableDictionary dictionaryWithDictionary:
                                @{PCCAMERASETTINGVIEW_SETTINGTYPE:@(0),
                                  PCCAMERASETTINGVIEW_SETTINGHEADLINE:@"画幅",
                                  PCCAMERASETTINGVIEW_SETTINGSOURCE:@[@{@"image":/*素材名字*/@"画幅01.png",  @"source":@(0)},/*无构线*/
                                                                      @{@"image":/*素材名字*/@"画幅02.png",  @"source":@(1)},/*01号*/
                                                                      ],
                                  }]];
    [_dataSourceMArr addObject:[NSMutableDictionary dictionaryWithDictionary:
                                @{PCCAMERASETTINGVIEW_SETTINGTYPE:@(0),
                                  PCCAMERASETTINGVIEW_SETTINGHEADLINE:@"录制模式",
                                  PCCAMERASETTINGVIEW_SETTINGSOURCE:@[@{@"image":/*素材名字*/@"自动.png",  @"source":@(0)},/*无构线*/
                                                                      @{@"image":/*素材名字*/@"手动.png",  @"source":@(1)},/*01号*/
                                                                      ],
                                  }]];
    [_dataSourceMArr addObject:[NSMutableDictionary dictionaryWithDictionary:
                                @{PCCAMERASETTINGVIEW_SETTINGTYPE:@(0),
                                  PCCAMERASETTINGVIEW_SETTINGHEADLINE:@"张数",
                                  PCCAMERASETTINGVIEW_SETTINGSOURCE:@[@{@"image":/*素材名字*/@"24.png",  @"source":@(0)},/*无构线*/
                                                                      @{@"image":/*素材名字*/@"36.png",  @"source":@(1)},/*01号*/
                                                                      @{@"image":/*素材名字*/@"48.png",  @"source":@(2)},/*01号*/
                                                                      ],
                                  }]];
    //PS: 外部控制时间  //GIF配置保存
    NSMutableDictionary *dic = [PCParameterManager currentLensParameters];
    dic[PCCAMERA_PARAMETER_SETTING] = [_dataSourceMArr copy];
}

#pragma mark - UICollectionViewDelegate
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    @try {
        if (self.dataSourceMArr[indexPath.row]
            && [((NSArray *)self.dataSourceMArr[indexPath.row][PCCAMERASETTINGVIEW_SETTINGSOURCE]) count]) {
            //切换到下一个类型
            //更新UI
            PCCameraGIFSettingViewCell *cell = (PCCameraGIFSettingViewCell *)[collectionView cellForItemAtIndexPath:indexPath];
            [cell switchType];
            [cell setNeedsLayout];
            NSNumber *type = cell.parameterDic[PCCAMERASETTINGVIEW_SETTINGTYPE];//默认类型提取
            
            SEL sel = nil;
            id obj = nil;
            if (indexPath.row == 0) {
                obj = type;
                sel = @selector(cameraGIFSettingViewClickedConceptionWithType:);
            } else if (indexPath.row == 1) {
                obj = type;
                sel = @selector(cameraGIFSettingViewClickedPictureWithType:);
            } else if (indexPath.row == 2) {
                obj = type;
                sel = @selector(cameraGIFSettingViewClickedRecordModeWithType:);
            } else if (indexPath.row == 3) {
                obj = type;
                sel = @selector(cameraGIFSettingViewClickedPictueCountWithType:);
            }
            if (sel
                && [_delegate respondsToSelector:sel]) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
                [_delegate performSelector:sel withObject:obj];
#pragma clang diagnostic pop
            }
        }
        //保存属性
        NSMutableDictionary *dic = [PCParameterManager currentLensParameters];
        dic[PCCAMERA_PARAMETER_SETTING] = [_dataSourceMArr copy];
    } @catch (NSException *exception) {
        
    }
}

#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return (_dataSourceMArr)?_dataSourceMArr.count:0;
}

- (__kindof PCCameraGIFSettingViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    PCCameraGIFSettingViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:PCCAMERAGIFSETTINGVIEWCELL_ID forIndexPath:indexPath];
    cell.backgroundColor = [UIColor orangeColor];
    @try {
        NSMutableDictionary *dic = self.dataSourceMArr[indexPath.row];
        
        if ([dic isKindOfClass:[NSMutableDictionary class]]) {
            cell.parameterDic = dic;
        }
    } @catch (NSException *exception) {
        
    } @finally {
        
    }
    return cell;
}


@end
