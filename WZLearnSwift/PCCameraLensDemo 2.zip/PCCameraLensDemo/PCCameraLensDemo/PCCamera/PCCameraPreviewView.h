//
//  PCCameraPreviewView.h
//  PCCameraLensDemo
//
//  Created by admin on 8/8/17.
//  Copyright © 2017年 wizet. All rights reserved.
//

#import <UIKit/UIKit.h>

@class PCCamera;
@class PCCameraControlView;
@protocol PCCameraControlViewProtocol;

#import "PCParameterManager.h"
#import "OIFilter.h"
#import "PCCamera.h"
#import "OIStillImageCamera.h"
/**
 相机配置层 buffer filter预览层 用于观察当前录制的content
 */

// 比例 : 宽高比
typedef NS_ENUM(NSInteger, VideoCameraPreviewCrop) {
    // photo
    kVideoCameraPreviewPhotoCrop1To1,
    kVideoCameraPreviewPhotoCrop3To4,
    kVideoCameraPreviewPhotoCrop9To16,
    
    // video
    kVideoCameraPreviewVideoCrop1To1,
    kVideoCameraPreviewVideoCrop9To16,
    kVideoCameraPreviewVideoCrop16To9,
    kVideoCameraPreviewVideoCrop235To1,
    
    kVideoCameraPreviewCrop1To1,   // 1:1,    静态与录像
    kVideoCameraPreviewCrop16To9,  // 16:9,   静态与录像
    kVideoCameraPreviewCrop4To3,   // 4:3,    静态only
    kVideoCameraPreviewCrop235To1, // 2.35:1, 视频only
    kVideoCameraPreviewCrop9To16   // 9:16,   视频only
};

typedef NS_ENUM(NSInteger, VideoCameraMode) {
    kVideoCameraModeStillImage, // 静态图
    kVideoCameraModeVideo,      // 录像
};

typedef NS_ENUM(NSUInteger, PCCameraGIFCaptureMode) {
    PCCameraGIFCaptureModeLeisure                 = 0,
    PCCameraGIFCaptureModePreheat                 = 1,//准备
    PCCameraGIFCaptureModePause                   = 2,//暂停
    PCCameraGIFCaptureModeCapturing               = 3,//捕捉ing
   
};

@interface PCCameraPreviewView : UIView

@property (nonatomic,   weak) PCCameraControlView *cameraControlView;
@property (nonatomic, assign) PCCameraLensesType lensesType;//镜头类型
@property (nonatomic, strong) PCCamera *camera;// 镜头

//状态变量
@property (nonatomic, assign) VideoCameraMode cameraMode;//拍摄模式
@property (nonatomic, assign) PCCameraGIFCaptureMode GIFCaptureMode;//GIF mode 
@property (nonatomic, assign) VideoCameraPreviewCrop previewCrop;//设置裁剪尺寸
@property (nonatomic, strong, readonly) NSMutableArray *GIFImagesInfoMArr;//GIF捕捉到的图片实体
@property (nonatomic, assign) VideoCameraViewOrientationMode currentOrientationMode;//当前设备方向 由陀螺仪的回调控制
- (void)shutdown;//关机
- (void)takeStillImagePhotoWithCompletion:(void (^)(UIImage *, NSDictionary *))completion;//根据滤镜的拍照接口
- (void)adjustSizeWithClipScale:(CGFloat)clipScale;//改镜头尺寸

- (void)GIFStartCapturing;//开始捕捉GIF
- (void)GIFFinishedCapturing;//停止or暂停捕捉GIF
- (void)clearGIFImagesInfo;//清理缓存



@end
