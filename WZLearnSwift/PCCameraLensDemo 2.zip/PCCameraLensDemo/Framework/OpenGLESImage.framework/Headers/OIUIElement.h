//
//  OIUIElement.h
//  OpenGLESImage
//
//  Created by Kwan Yiuleung on 14-3-31.
//  Copyright (c) 2014年 Kwan Yiuleung. All rights reserved.
//

#import "OIProducer.h"


@class UIView;

@interface OIUIElement : OIProducer
{
    UIView *sourceView_;
    CALayer *sourceLayer_;
}

- (instancetype)initWithUIView:(UIView *)uiView;
- (instancetype)initWithCALayer:(CALayer *)caLayer;


/**
 @method refresh
 @abstract 输出一帧view / layer画面的数据。
 */
- (void)refreshWithTime:(CMTime)time;

@end
