//
//  OIMediaCaptor.h
//  OpenGLESImage
//
//  Created by 陈弢 on 2017/6/3.
//  Copyright © 2017年 Kwan Yiuleung. All rights reserved.
//

#import <OpenGLESImage/OpenGLESImage.h>

/*
 与之前的OIVideoCaptor相比
 一、内部解决Buffer数据的尺寸、方向问题(即外部上层不需要再对拍到的图片额外进行旋转与裁剪)
 二、添加了图片数据的元数据信息
 三、添加了视频数据的元数据信息
 二、一个类整合了静态图片以及视频音频的拍摄
 三、更方便的使用OIFilter链输出Processed图片
 四、加入功能如人脸检测、白平衡等(TODO)
 六、更新了视频CMSampleBuffer数据快速写入OpenGL的texture中的方法(没有)
 */

@protocol OIMediaCaptorDelegate <NSObject>
@optional

// 相机在配置过程中出现的任何错误都会回调此方法 (方法错误例如:获取镜头设备失败，获取设备功能失败等等)
- (void)captorConfigurationError:(NSError *)error;

// 返回捕捉的sampleBuffer
- (void)captorWillOutputVideoSampleBuffer:(CMSampleBufferRef)sampleBuffer;
- (void)captorWillOutputAudioSampleBuffer:(CMSampleBufferRef)sampleBuffer;

- (void)mediaCaptorShouldProcessCapturedStillImageUsingOpenGL;

@end




// 基本功能——枚举

// 聚焦模式
typedef NS_ENUM(NSUInteger, OIMediaCaptorFocusMode){
    OIMediaCaptorFocusModeLocked            = AVCaptureFocusModeLocked,
    OIMediaCaptorFocusModeAuto              = AVCaptureFocusModeAutoFocus,
    OIMediaCaptorFocusModeContinuousAuto    = AVCaptureFocusModeContinuousAutoFocus,
};

// 闪光灯模式
typedef NS_ENUM(NSUInteger, OIMediaCaptorFlashMode){
    OIMediaCaptorFlashModeOff    = 0,
    OIMediaCaptorFlashModeOn     = 1,
    OIMediaCaptorFlashModeAuto   = 2,
    OIMediaCaptorFlashModeTorch  = 3
};

// 曝光模式
typedef NS_ENUM(NSInteger, OIMediaCaptorExposureMode) {
    OIMediaCaptorExposureModeLocked            = AVCaptureExposureModeLocked,
    OIMediaCaptorExposureModeAuto              = AVCaptureExposureModeAutoExpose,
    OIMediaCaptorExposureModeContinuousAuto    = AVCaptureExposureModeContinuousAutoExposure,
    OIMediaCaptorExposureModeCustom            = AVCaptureExposureModeCustom,
};

// 方向
typedef NS_ENUM(NSInteger, OIMediaCaptorOrientation) {
    OIMediaCaptorOrientationUnknown            = UIDeviceOrientationUnknown,
    OIMediaCaptorOrientationPortrait           = UIDeviceOrientationPortrait,
    OIMediaCaptorOrientationPortraitUpsideDown = UIDeviceOrientationPortraitUpsideDown,
    OIMediaCaptorOrientationLandscapeLeft      = UIDeviceOrientationLandscapeLeft,
    OIMediaCaptorOrientationLandscapeRight     = UIDeviceOrientationLandscapeRight
};

// 白平衡模式
typedef NS_ENUM(NSInteger, OIMediaCaptorWhiteBalanceMode) {
    OIMediaCaptorWhiteBalanceModeLocked           = AVCaptureWhiteBalanceModeLocked,
    OIMediaCaptorWhiteBalanceModeAuto             = AVCaptureWhiteBalanceModeAutoWhiteBalance,
    OIMediaCaptorWhiteBalanceModeContinuousAuto   = AVCaptureWhiteBalanceModeContinuousAutoWhiteBalance,
};

// 相机模式，可直接切换
typedef NS_ENUM(NSInteger, OIMediaCaptorCameraMode) {
    OIMediaCaptorCameraModeStillImage, // 静态图
    OIMediaCaptorCameraModeVideo,      // 录像
};


/*
 类似于OIVideoCaptor的媒体捕捉抽象类，在OIVideoCaptor的基础上，修改了部分逻辑以及添加新的api和功能
 base on ARC
 */
@interface OIMediaCaptor : OIProducer

@property (nonatomic, weak) id <OIMediaCaptorDelegate> delegate;


// 初始方法 - 相机模式、前置后置、分辨率预设
- (instancetype)init;
- (instancetype)initStillImageCamera;
- (instancetype)init720pVideoCamera;
// 若相机模式为静态图，分辨率将被固定为
- (instancetype)initWithCameraMode:(OIMediaCaptorCameraMode)cameraMode cameraPosition:(AVCaptureDevicePosition)cameraPosition sessionPreset:(NSString *)sessionPreset;

- (instancetype)initHighPresetVideoCamera;

- (void)startRunning;
- (void)stopRunning;

- (void)switchCameraPosition; // 前置/后置 切换
- (void)switchCameraMode;     // 视频/静态 切换

@property (nonatomic, copy) NSString *sessionPreset; // 镜头分辨率

@property (nonatomic, assign) CGPoint focusPoint;
@property (nonatomic, assign) AVCaptureFocusMode focusMode;

@property (nonatomic, assign) CGPoint exposurePoint;
@property (nonatomic, assign) AVCaptureExposureMode exposureMode;
@property (nonatomic, assign) CGFloat exposureTargetBias;

@property (nonatomic, assign) OIMediaCaptorFlashMode flashMode;
@property (nonatomic, strong) CMMotionManager *videoCaptorMotionManager;

@property (nonatomic, assign) int frameRate; // 帧率

@property (nonatomic, strong, readonly) NSDictionary *currentCaptureMetaData; // 当前捕捉的图片信息

@property (nonatomic, strong) NSURL *uniqueURL; // 获取唯一URL

@property (nonatomic, assign) BOOL enableSmoothAutoFocus; // 开启视频平滑对焦(减慢对焦速度，从而使录制画面更自然)
@property (nonatomic, assign) BOOL enableVideoStabilization; // 开启视频防抖(注意开启防抖需要消耗较多配置时间)

- (BOOL)hasFlash;

// 画面大小
- (CGFloat)videoZoomFactor;
- (void)rampToVideoZoomFactor:(CGFloat)factor withRate:(CGFloat)rate;

@end



// 拍摄尺寸
typedef NS_ENUM(NSUInteger, OIMediaCaptorOutputSizeMode){
    OIMediaCaptorOutputSizeMode4To3,
    OIMediaCaptorOutputSizeMode1To1,
    OIMediaCaptorOutputSizeMode16To9
};


// =================================静态图拍摄======================================= //
@interface OIMediaCaptor (OIMediaCaptorStillImageOutput)

// 原始api获取sampleBuffer(BGRA格式)
- (void)captureImageSampleBufferAsynchronouslyWithCompletionHandler:(void (^)(CMSampleBufferRef imageSampleBuffer, NSError *error))handler;
// 返回原始图片(这个接口有问题哦~~~我没有时间去改哦~~~不要用这个接口哦~~~要用下面那个，带滤镜带裁剪带旋转方向的哦)
- (void)captureOriginalImageAsynchronouslyWithCompletionHandler:(void (^)(UIImage *originalImage, NSError *error))handler;

/*
 此方法将直接获得图片方向正确、且图片方向属性、MetaData方向属性均为Up的图片，可直接写入相册
 @param filters: 镜头生成图片需要使用到的滤镜
 @param sizeMode: 
 */
- (void)captureProcessedImageWithFinalFilter:(NSArray *)filters cropRect:(OIMediaCaptorOutputSizeMode)sizeMode AsynchronouslyWithCompletionHandler:(void (^)(UIImage *processedImage, NSError *error))handler;

// 设置镜头的曝光时间以及ISO，注意该选项与StillImageOutput的防抖功能冲突
- (void)setExposureModeCustomWithDuration:(CMTime)duration ISO:(float)ISO completionHandler:(void (^)(CMTime syncTime))handler;

@end
// =================================静态图拍摄======================================= //



// =================================视频拍摄======================================= //

// 视频输出
@interface OIMediaCaptor (OIMediaCaptorVideoOutput)

@end

// =================================视频拍摄======================================= //




// ======================================================================== //


// 尺寸及方向
@interface OIMediaCaptor (OIMediaCaptorOrientationAndSizeFit)

// 用于设置镜头拍摄输出的尺寸
@property (nonatomic, assign) OIMediaCaptorOutputSizeMode outputSizeMode;

@end



// ======================================================================== //



// 人脸检测
@interface OIMediaCaptor (OIMediaCaptorFaceDetection)

@end



// ======================================================================== //



// 拍摄RAW
@interface OIMediaCaptor (OIMediaCaptorRawData)

@end



// ======================================================================== //



// OpenGL内容
@interface OIMediaCaptor (OIMediaCaptorOpenGL)

@end



// ======================================================================== //



// 高帧率捕捉功能(慢动作拍摄等)
@interface OIMediaCaptor (OIMediaCaptorFrameRate)

@end


