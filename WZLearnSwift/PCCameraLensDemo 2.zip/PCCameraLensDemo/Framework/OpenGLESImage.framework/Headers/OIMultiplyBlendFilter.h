//
//  OIMultiplyBlendFilter.h
//  OpenGLESImage
//
//  Created by Kwan Yiuleung on 14-12-19.
//  Copyright (c) 2014年 Kwan Yiuleung. All rights reserved.
//

#import <OpenGLESImage/OITwoInputsFilter.h>

@interface OIMultiplyBlendFilter : OITwoInputsFilter

@end
