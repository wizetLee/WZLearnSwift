//
//  OITwoInputsFilter.h
//  OpenGLESImage
//
//  Created by Kwan Yiuleung on 14-4-16.
//  Copyright (c) 2014年 Kwan Yiuleung. All rights reserved.
//

#import "OIFilter.h"

@interface OITwoInputsFilter : OIFilter
{
    OITexture *secondInputTexture_;
}

@end
