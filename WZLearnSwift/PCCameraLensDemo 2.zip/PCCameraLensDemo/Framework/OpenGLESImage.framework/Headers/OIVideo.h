//
//  OIVideo.h
//  OpenGLESImage
//
//  Created by Kwan Yiuleung on 14-10-20.
//  Copyright (c) 2014年 Kwan Yiuleung. All rights reserved.
//

#import "OIProducer.h"
#import <AVFoundation/AVFoundation.h>
@class AVAsset;
@class UIImage;
@class AVMutableComposition;
@class AVMutableAudioMix;
@class AVMutableVideoComposition;

enum OIVideoStatus_ {
    OIVideoStatusWaiting,
    OIVideoStatusPlaying,
    OIVideoStatusPaused
};

typedef enum OIVideoStatus_ OIVideoStatus;

typedef enum OIVideoOrientation_ {
    OIVideoOrientationUnknown            ,
    OIVideoOrientationPortrait           ,
    OIVideoOrientationPortraitUpsideDown ,
    OIVideoOrientationLandscapeLeft      ,
    OIVideoOrientationLandscapeRight
} OIVideoOrientation;

@class OIVideo;

@protocol OIVideoDelegate <NSObject>

@optional
- (void)video:(OIVideo *)video willOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer;
- (void)videoDidEnd:(OIVideo *)video;

@end

@interface OIVideo : OIProducer
{
    dispatch_queue_t videoControlQueue_; //用于调用信号量阻塞视频播放队列（在play函数中）的队列，采用自建队列的原因是防止调用pause方法的队列被阻塞。
    dispatch_semaphore_t videoControlSemaphore_; //用于控制视频暂停或者播放的信号量。
    AVAssetReader *assetReader_;
    AVAssetReaderTrackOutput *videoTrackOutput_;
    AVAssetReaderTrackOutput *audioTrackOutput_;
    AVAssetReaderAudioMixOutput *mixAudioTrackOutput_;
    AVAsset *AVAsset_;
    AVAsset *originalAsset_;
    NSURL *URL_;
    id<OIVideoDelegate> delegate_;
    OIVideoStatus status_;
    BOOL playAtActualSpeed_;
    CMTime previousFrameTime_;
    NSTimeInterval previousFrameActualTime_;
    AVMutableComposition *mainComposition_;
    AVMutableAudioMix *videoAudioMixTools_;
    AVMutableVideoComposition *selectVideoComposition_;
    CADisplayLink *videoDisplayLink_;
    NSThread *videoProcessingThread_;
    BOOL didMixAudio;
    
    CFAbsoluteTime processingStartTime;
    CFAbsoluteTime pausedTime_;
    BOOL shouldKeepRunning_;
    BOOL shouldStopPlaying_;
    NSCondition *stopCondition_;
    
    NSDictionary *mixingAudioParameters;
    
    // playerItem
    AVPlayerItemVideoOutput *playerItemVideoOutput;
    AVPlayerItem *playerItem;
    CADisplayLink *playerItemDisplayLink;
    dispatch_queue_t videoProcessingQueue;
}

- (instancetype)initWithAVAsset:(AVAsset *)asset;
- (instancetype)initWithURL:(NSURL *)URL;

// 根据设备方向来设置AVAsset，内部会根据机身方向设置出视频帧的正确方向
// 该初始方法用于InterPhoto摄像头录像后的视频方向调整
//- (instancetype)initWithAVAsset:(AVAsset *)asset andDeviceOrientation:(OIVideoOrientation)videoOrientation;

@property (assign, nonatomic) id<OIVideoDelegate> delegate;

@property (retain, nonatomic) AVAsset *AVAsset;  //To set the AVAsset which be play by receiver.
@property (retain, nonatomic) NSURL *URL;  //If receiver do not init by (initWithURL:) and this property never be set, return nil. You can set the source video's URL by this, which be play by receiver.

@property (readonly, nonatomic) OIVideoStatus status;

@property (readonly, nonatomic) double duration; //返回视频的总长度，单位为秒。

/**
 @property progress
 @abstract 当前视频输出帧的时间在整段视频时长中的百分比。
 @return 一个0.0到1.0之间的数值。
 @discussion 如果此前调用过clipWithRange:方法，则此属性的返回值是以剪裁后的视频长度为基础计算的。0.0代表视频还没输出。
 */
@property(readonly, nonatomic) double progress;

/**
 @property size
 @abstract 该视频的原始分辨率。
 @discussion 不同于AVAssetTrack里读到的naturalSize，此属性的宽高数值已经根据视频的方向调整。
 */
@property (readonly, nonatomic) CGSize size;

/**
 @property orientation
 @abstract 视频帧旋转的方向。
 @discussion 主要是针对iOS设备拍摄的视频文件而设。由于iOS设备拍摄的视频画面是固定方向的，不会根据拍摄时的机身方向旋转，此属性是标示出视频帧的正确方向。在通常情况下，外部是不需要关心此属性的，OIVideo自身已经设置好输出的纹理方向，不需要自行判断此参数。
 */
@property (readonly, nonatomic) OIVideoOrientation orientation;

@property (readwrite, nonatomic) BOOL playAtActualSpeed;  //Default is YES.

@property (nonatomic, retain) AVMutableComposition *mainComposition;   //总的音视频轨道组
@property (nonatomic, retain) AVMutableAudioMix *videoAudioMixTools;   //混音组
@property (nonatomic, retain) AVMutableVideoComposition *selectVideoComposition;

- (BOOL)play;
- (void)stop;
- (void)replay;

/**
 @method pause
 @abstract 暂停播放中的视频。
 @discussion 此方法需要在status属性的值为OIVideoStatusPlaying的时候调用才有效果，其它状态下调用无效。调用此方法后，status属性的返回值马上会变为OIVideoStatusPaused，但输出中的视频流可能会在一小段时间后才会暂停输出，但此方法是马上返回的，调用此方法的线程不会被阻塞。被暂停的视频可通过play方法从暂停的地方继续播放，而不会从头开始。
 */
- (void)pause;

@property (nonatomic, assign, readonly) BOOL isPause;

- (CMSampleBufferRef)copyNextAudioSampleBuffer;

/**
 生成对应时间的缩略图

 @param seconds 传入第几秒. 当传入时间超过视频最大时间则会返回空.如果传入小于0的数也会返回空.
 @return 返回UIImage类型.返回图片的size等于视频的分辨率.如果返回空,则时间传入不正确.
 */
- (UIImage *)thumbnailImageAtTime:(float)seconds;

/**
 @method clipWithRange:
 @abstract 对该OIVideo实例进行指定时间段的剪裁。
 @param range 剪切视频的时间范围。可多次调用此方法修改需要截取的时间范围，每次调用传入的时间范围参数都应该基于最初原视频的时间轴，而不是某次剪裁后得出的新时间轴。如果 range.length 和 range.location 均为 0，则会取消之前所有的剪裁操作，还原为最初的视频长度。
 @discussion 此方法需要在status属性的值为OIVideoStatusWaiting的时候调用才有效果，其它状态下调用无效。使用此方法进行裁剪后，AVAsset属性和duration属性的返回值均是描述修改后的视频数据。
 */
- (void)clipWithRange:(NSRange)range;

/**
 @method seekToTime:
 @abstract 输出指定时间点的帧数据。
 @param time 需要输出的帧的时间。该时间是以原始视频的时间轴为基础，不是clipWithRange:方法剪裁后的视频时间轴。注意该时间不要超过整段视频的时长。
 @discussion 此方法需要在status属性的值为OIVideoStatusWaiting的时候调用才有效果，其它状态下调用无效。
 */
- (void)seekToTime:(CMTime)time;

/**
 混音
 
 @param audioAssetURL        混音URL 当输入空值则会将之前的混音全部恢复为原来的音视频资料.
 @param videoVolume          视频音量   取值范围在 (0 - 1)
 @param audioVolume          背景音量    取值范围在 (0 - 1)
 @param startTime            背景音频第一次开始时间    该值是相对音频时间.而且取得值在音频范围内
 @param audioRangeTime       背景音频时间     该值是在音频资料上掘取的.不允许超过音频资料的时间范围
 @return                     返回BOOL类型.数据输入有误会返回NO并不做任何处理.错误信息会被LOG
 */
- (BOOL)mixAudioAssetAtURL:(NSURL *)audioAssetURL
               videoVolume:(float)videoVolume
               audioVolume:(float)audioVolume
            audioStartTime:(CMTime)startTime
            audioRangeTime:(CMTimeRange)audioRangeTime;


@end
