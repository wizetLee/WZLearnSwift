//
//  OIMultiImagesSplicingFilter.h
//  OpenGLESImage
//
//  Created by Kwan Yiuleung on 14-11-5.
//  Copyright (c) 2014年 Kwan Yiuleung. All rights reserved.
//

#import "OIMultiInputsFilter.h"

@interface OIMultiImagesSplicingFilter : OIMultiInputsFilter

@end
