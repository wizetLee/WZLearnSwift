//
//  OIAlphaPreMultiplyBlendFilter.h
//  OpenGLESImage
//
//  Created by Kwan Yiuleung on 14-10-28.
//  Copyright (c) 2014年 Kwan Yiuleung. All rights reserved.
//

#import <OpenGLESImage/OIBlendFilter.h>

@interface OIAlphaPreMultiplyBlendFilter : OITwoInputsFilter

@end
