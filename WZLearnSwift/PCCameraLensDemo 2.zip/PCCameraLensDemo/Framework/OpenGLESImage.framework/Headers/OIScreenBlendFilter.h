//
//  OIScreenBlendFilter.h
//  OpenGLESImage
//
//  Created by Kwan Yiuleung on 14-10-23.
//  Copyright (c) 2014年 Kwan Yiuleung. All rights reserved.
//

#import "OITwoInputsFilter.h"

@interface OIScreenBlendFilter : OITwoInputsFilter

@end
