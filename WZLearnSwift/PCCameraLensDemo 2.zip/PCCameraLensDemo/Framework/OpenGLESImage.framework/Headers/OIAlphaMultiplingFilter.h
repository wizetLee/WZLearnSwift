//
//  OIAlphaMultiplingFilter.h
//  OpenGLESImage
//
//  Created by Kwan Yiuleung on 14-11-6.
//  Copyright (c) 2014年 Kwan Yiuleung. All rights reserved.
//

#import "OITwoInputsFilter.h"

@interface OIAlphaMultiplingFilter : OITwoInputsFilter

@end
